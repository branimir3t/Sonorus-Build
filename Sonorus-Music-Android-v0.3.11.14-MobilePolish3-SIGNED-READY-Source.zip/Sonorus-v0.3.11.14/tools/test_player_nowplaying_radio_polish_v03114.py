from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
queue = (root / 'app/src/main/java/com/brane/sonora/QueueAdapter.java').read_text(encoding='utf-8')
layout = (root / 'app/src/main/res/layout/activity_main.xml').read_text(encoding='utf-8')

checks = []

def check(name, cond):
    checks.append((name, bool(cond)))

# PLAYER active row: both title and artist use accent; active row gets extra weight.
check('active player artist uses accent', 'h.artist.setTextColor(active ? ThemeSupport.accent(context) : ThemeSupport.text2(context));' in queue)
check('active player title gets extra bold', 'h.title.getPaint().setFakeBoldText(active);' in queue)
check('active player artist gets extra bold', 'h.artist.getPaint().setFakeBoldText(active);' in queue)

# Hero Now Playing card: preview uses the hero play button as Stop and never resumes PLAYER.
check('hero preview stop intercept exists', re.search(r'playButton\.setOnClickListener\(v -> \{\s*if \(activeCatalogPreviewTrackId >= 0L && playbackService != null\)', main) is not None)
check('hero preview stop pauses engine', 'engine.pause();' in main[main.find('playButton.setOnClickListener'):main.find('prevButton.setOnClickListener')])
check('hero preview stop calls preview stop', 'playbackService.stopCatalogPreview();' in main[main.find('playButton.setOnClickListener'):main.find('prevButton.setOnClickListener')])
check('preview active shows stop in hero', 'playButton.setText("■");' in main[main.find('onCatalogPreviewChanged'):main.find('onCatalogPreviewProgress')])

# Hero right side gets only a modest expansion: 180 -> 200dp, controls only slightly larger.
hero = layout[layout.find('android:id="@+id/heroPanel"'):layout.find('</com.brane.sonora.NowPlayingGlowLayout>')]
check('hero controls area modestly wider', 'android:layout_width="200dp"' in hero)
check('hero prev next modestly larger', hero.count('android:layout_width="38dp"') >= 2)
check('hero play modestly larger', 'android:layout_width="50dp"' in hero and 'android:layout_height="50dp"' in hero)
check('hero title still supports two lines', 'android:id="@+id/heroTitle"' in hero and 'android:maxLines="2"' in hero)

# Radio: only station label font is reduced from 12sp to 11sp.
radio = layout[layout.find('android:id="@+id/oldSchoolRadioCard"'):layout.find('android:id="@+id/leftClockText"')]
station = radio[radio.find('android:text="OLD SCHOOL RADIO"')-450:radio.find('android:text="OLD SCHOOL RADIO"')+350]
check('radio station label reduced to 11sp', 'android:textSize="11sp"' in station)
check('radio station text still single line', 'android:singleLine="true"' in station and 'android:maxLines="1"' in station)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    raise SystemExit(1)
