from pathlib import Path

root = Path(__file__).resolve().parents[1]
layout = (root/'app/src/main/res/layout/view_mobile_fullscreen_content.xml').read_text(encoding='utf-8')
main = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
gradle = (root/'app/build.gradle').read_text(encoding='utf-8')
action_bg = root/'app/src/main/res/drawable/bg_mobile_fullscreen_action.xml'
collapse_icon = root/'app/src/main/res/drawable/ic_mobile_collapse.xml'
queue_icon = root/'app/src/main/res/drawable/ic_mobile_player_queue.xml'

def block(view_id: str) -> str:
    marker = f'android:id="@+id/{view_id}"'
    start = layout.find(marker)
    if start < 0:
        return ''
    left = layout.rfind('<', 0, start)
    end = layout.find('/>', start)
    if end < 0:
        end = layout.find('>', start)
    return layout[left:end+2]

checks = {
    'version_code_35': 'versionCode 35' in gradle,
    'version_name_031113': "versionName '0.3.11.13-mobile-polish2'" in gradle,
    'action_bg_exists': action_bg.exists(),
    'favorite_compact': 'android:layout_height="46dp"' in block('mobileFullscreenFavoriteButton'),
    'playlist_compact': 'android:layout_height="46dp"' in block('mobileFullscreenAddPlaylistButton'),
    'lyrics_compact': 'android:layout_height="46dp"' in block('mobileFullscreenLyricsButton'),
    'action_bg_used': all('@drawable/bg_mobile_fullscreen_action' in block(x) for x in [
        'mobileFullscreenFavoriteButton','mobileFullscreenAddPlaylistButton','mobileFullscreenLyricsButton']),
    'collapse_icon_exists': collapse_icon.exists(),
    'queue_icon_exists': queue_icon.exists(),
    'top_close_image_button': '<ImageButton' in layout and '@drawable/ic_mobile_collapse' in block('mobileFullscreenCloseButton'),
    'top_queue_image_button': '<ImageButton' in layout and '@drawable/ic_mobile_player_queue' in block('mobileFullscreenQueueButton'),
    'top_close_centered': 'android:padding="0dp"' in block('mobileFullscreenCloseButton') and 'android:scaleType="centerInside"' in block('mobileFullscreenCloseButton'),
    'top_queue_centered': 'android:padding="0dp"' in block('mobileFullscreenQueueButton') and 'android:scaleType="centerInside"' in block('mobileFullscreenQueueButton'),
    'brighter_progress_track': 'android:progressBackgroundTint="#66FFFFFF"' in block('mobileFullscreenProgress'),
    'catalog_play_refreshes_mini': 'engine.playTrackNow(entry.track);' in main and 'updateMobileMiniPlayerVisibility();' in main[main.find('engine.playTrackNow(entry.track);'):main.find('engine.playTrackNow(entry.track);')+180],
    'playback_change_refreshes_mini': 'onPlaybackChanged(boolean playing)' in main and 'updateMobileMiniPlayerVisibility();' in main[main.find('onPlaybackChanged(boolean playing)'):main.find('onProgress(long positionMs', main.find('onPlaybackChanged(boolean playing)'))],
}

failed = []
for name, ok in checks.items():
    print(f'{name}: {"PASS" if ok else "FAIL"}')
    if not ok:
        failed.append(name)
if failed:
    raise SystemExit(1)
