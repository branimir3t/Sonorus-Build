from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
main_p = root / 'app/src/main/java/com/brane/sonora/MainActivity.java'
layout_p = root / 'app/src/main/res/layout/activity_main.xml'
full_layout_p = root / 'app/src/main/res/layout/view_fullscreen_now_playing.xml'
turntable_p = root / 'app/src/main/java/com/brane/sonora/TurntableView.java'
lyrics_p = root / 'app/src/main/java/com/brane/sonora/LyricsRepository.java'
build_p = root / 'app/build.gradle'

main = main_p.read_text(encoding='utf-8')
activity_layout = layout_p.read_text(encoding='utf-8')
build = build_p.read_text(encoding='utf-8')
full = full_layout_p.read_text(encoding='utf-8') if full_layout_p.exists() else ''
turntable = turntable_p.read_text(encoding='utf-8') if turntable_p.exists() else ''
lyrics = lyrics_p.read_text(encoding='utf-8') if lyrics_p.exists() else ''

checks = []
def check(name, cond):
    checks.append((name, bool(cond)))

# Full-screen overlay and entry/exit.
check('fullscreen layout exists', full_layout_p.exists())
check('activity includes fullscreen layout', '@layout/view_fullscreen_now_playing' in activity_layout)
check('fullscreen overlay id', 'fullscreenNowPlayingOverlay' in full)
check('fullscreen close button', 'fullscreenCloseButton' in full)
check('fullscreen artwork and metadata', all(x in full for x in ['fullscreenCover', 'fullscreenTitle', 'fullscreenArtist', 'fullscreenAlbumYear', 'fullscreenTech']))
check('fullscreen seek and time', all(x in full for x in ['fullscreenProgress', 'fullscreenCurrentTime', 'fullscreenTotalTime']))
check('fullscreen transport buttons', all(x in full for x in ['fullscreenPrevButton', 'fullscreenPlayButton', 'fullscreenStopButton', 'fullscreenNextButton']))
check('fullscreen lyrics controls', all(x in full for x in ['fullscreenLyrics', 'fullscreenLyricsDownloadButton', 'fullscreenLyricsStatus']))
check('hero cover opens fullscreen', 'heroArt.setOnClickListener(v -> showFullscreenNowPlaying())' in main)
check('compact cover opens fullscreen', 'nowArt.setOnClickListener(v -> showFullscreenNowPlaying())' in main)
check('back closes fullscreen first', re.search(r'onBackPressed\(\).*fullscreenNowPlayingOverlay', main, re.S) is not None)
check('fullscreen adaptive body exists', 'fullscreenNowPlayingBody' in full and 'applyFullscreenNowPlayingLayout' in main)

# Turntable visual and motion.
check('turntable view exists', turntable_p.exists())
check('turntable draws platter and tonearm', 'drawCircle' in turntable and 'drawLine' in turntable)
check('fullscreen layout uses photographic turntable scene', 'fullscreenScenePhoto' in full and '@drawable/sonorus_turntable_scene' in full)
check('vinyl group exists', 'fullscreenVinylGroup' in full)
check('vinyl rotation animator exists', 'ObjectAnimator' in main and 'fullscreenVinylAnimator' in main)
check('vinyl motion depends on playback', 'updateFullscreenVinylMotion' in main and 'activeCatalogPreviewTrackId' in main)

# Source-aware PLAYER / preview behavior.
check('current fullscreen source helper', 'getFullscreenNowPlayingTrack()' in main)
check('fullscreen refresh helper', 'refreshFullscreenNowPlaying()' in main)
check('fullscreen preview seek routes to service', 'seekCatalogPreview(activeCatalogPreviewTrackId' in main)
check('fullscreen player seek routes to engine', 'engine.seekTo' in main)
check('fullscreen preview stop uses service', 'fullscreenStopButton' in main and 'playbackService.stopCatalogPreview()' in main)
check('fullscreen player stop pauses and rewinds', 'engine.pause();' in main and 'engine.seekTo(0L);' in main)
check('preview progress updates fullscreen', 'updateFullscreenProgress(positionMs, durationMs)' in main)
check('engine progress updates fullscreen', 'updateFullscreenProgress(positionMs, durationMs)' in main)
check('preview end refreshes fullscreen', 'onCatalogPreviewChanged' in main and 'refreshFullscreenNowPlaying();' in main)

# Lyrics repository and cache.
check('lyrics repository exists', lyrics_p.exists())
check('lrclib https endpoint', 'https://lrclib.net/api/get' in lyrics and 'https://lrclib.net/api/search' in lyrics)
check('lyrics request url encodes fields', 'URLEncoder.encode' in lyrics)
check('lyrics exact and fallback lookup', 'album_name' in lyrics and 'fetchExact' in lyrics and 'fetchSearch' in lyrics)
check('lyrics supports plain and synced', 'plainLyrics' in lyrics and 'syncedLyrics' in lyrics)
check('lyrics strips lrc timestamps', 'syncedLyrics.replaceAll' in lyrics and '(?m)^\\\\[\\\\d{2}:\\\\d{2}' in lyrics)
check('lyrics cache directory', 'sonorus_lyrics' in lyrics and 'getFilesDir()' in lyrics)
check('lyrics cache hash', 'SHA-256' in lyrics)
check('lyrics user initiated only', 'fullscreenLyricsDownloadButton.setOnClickListener' in main and 'fetchAndCache' in main)
check('lyrics cached load on open', 'getCached' in main)

# Version and preservation.
check('version code 35', re.search(r'versionCode\s+35\b', build) is not None)
check('version name 0.3.11.13', "versionName '0.3.11.13-mobile-polish2'" in build)
check('application id preserved', "applicationId 'com.brane.sonora'" in build)
check('no Internet Search source introduced', not (root / 'app/src/main/java/com/brane/sonora/InternetSearchRepository.java').exists())

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    raise SystemExit(1)
