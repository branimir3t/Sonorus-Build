from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
source=root/'app/src/main/java/com/brane/sonora/VinylSceneGeometry.java'
assert source.exists(), 'Missing shared scene geometry: old renderer rotates only the label'
with tempfile.TemporaryDirectory() as out:
    subprocess.run(['java','com.sun.tools.javac.Main','-d',out,str(source),str(root/'tools/scene-tests/VinylSceneGeometryTest.java')],check=True)
    subprocess.run(['java','-cp',out,'com.brane.sonora.VinylSceneGeometryTest'],check=True)
