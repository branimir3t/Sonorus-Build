import os
from pathlib import Path
import subprocess
import tempfile


root = Path(__file__).resolve().parents[1]
sdk_candidates = [
    Path(os.environ[name])
    for name in ("ANDROID_HOME", "ANDROID_SDK_ROOT")
    if os.environ.get(name)
]
sdk_candidates.extend(Path("/workspace/scratch").glob("*/work/toolchain/android-sdk"))
sdk = next((path for path in sdk_candidates if path.is_dir()), None)
assert sdk is not None, "Android SDK not found"

build_tools = sorted((sdk / "build-tools").glob("*"), reverse=True)
aapt2 = next((path / "aapt2" for path in build_tools if (path / "aapt2").is_file()), None)
android_jars = sorted((sdk / "platforms").glob("android-*/android.jar"), reverse=True)
assert aapt2 is not None and android_jars, "aapt2 or android.jar not found"

with tempfile.TemporaryDirectory(prefix="sonorus-resource-link-") as temp_dir:
    temp = Path(temp_dir)
    manifest = (root / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
    if "package=" not in manifest.split(">", 1)[0]:
        manifest = manifest.replace(
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.brane.sonora">',
            1,
        )
    manifest_path = temp / "AndroidManifest.xml"
    manifest_path.write_text(manifest, encoding="utf-8")

    compiled = temp / "compiled-res.zip"
    compile_result = subprocess.run(
        [str(aapt2), "compile", "--dir", str(root / "app/src/main/res"), "-o", str(compiled)],
        capture_output=True,
        text=True,
    )
    assert compile_result.returncode == 0, compile_result.stdout + compile_result.stderr

    generated = temp / "gen"
    generated.mkdir()
    link_result = subprocess.run(
        [
            str(aapt2), "link", "-o", str(temp / "resources.apk"),
            "-I", str(android_jars[0]), "--manifest", str(manifest_path),
            "--java", str(generated), "--min-sdk-version", "26",
            "--target-sdk-version", "35", "--version-code", "30",
            "--version-name", "0.3.11.12-mobile-polish", "--auto-add-overlay",
            str(compiled),
        ],
        capture_output=True,
        text=True,
    )
    assert link_result.returncode == 0, link_result.stdout + link_result.stderr

print("PASS: Android resources compile and link for v0.3.11.8")
