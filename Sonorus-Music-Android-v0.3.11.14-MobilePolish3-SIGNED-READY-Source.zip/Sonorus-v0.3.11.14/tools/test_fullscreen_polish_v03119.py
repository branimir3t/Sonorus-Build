from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
layout = (root/'app/src/main/res/layout/view_fullscreen_now_playing.xml').read_text(encoding='utf-8')
main = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
glass = (root/'app/src/main/res/drawable/bg_fullscreen_glass.xml').read_text(encoding='utf-8')
lyrics_bg = (root/'app/src/main/res/drawable/bg_fullscreen_lyrics.xml').read_text(encoding='utf-8')

checks = {
    'background_overlay_lightened': '#72070606' not in layout,
    'info_column_has_room': 'android:id="@+id/fullscreenInfoColumn"' in layout and 'android:paddingTop="10dp"' in layout and 'android:paddingEnd="12dp"' in layout,
    'player_card_padding_increased': 'android:id="@+id/fullscreenPlayerCard"' in layout and 'android:paddingTop="11dp"' in layout and 'android:paddingEnd="20dp"' in layout,
    'lyrics_card_padding_increased': 'android:id="@+id/fullscreenLyricsCard"' in layout and 'android:paddingTop="10dp"' in layout and 'android:paddingEnd="12dp"' in layout,
    'glass_more_transparent': '#E5191B22' not in glass and '#D8' in glass,
    'lyrics_bg_more_transparent': '#EC171920' not in lyrics_bg and '#D8' in lyrics_bg,
    'no_saved_offline_label': 'SPREMLJENO OFFLINE' not in main,
    'status_hidden_after_success': 'fullscreenLyricsStatus.setVisibility(View.GONE);' in main and 'fullscreenLyricsStatus.setText("");' in main,
    'status_shown_when_missing': 'fullscreenLyricsStatus.setVisibility(View.VISIBLE);' in main and 'fullscreenLyricsStatus.setText("Tekst nije spremljen");' in main,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f'{name}: {'PASS' if ok else 'FAIL'}')
if failed:
    raise SystemExit(1)
