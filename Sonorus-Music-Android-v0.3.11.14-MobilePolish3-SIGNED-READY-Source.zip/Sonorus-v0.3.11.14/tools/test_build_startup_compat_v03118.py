from pathlib import Path
import re


build = Path('app/build.gradle').read_text(encoding='utf-8')
main = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
service = Path('app/src/main/java/com/brane/sonora/PlaybackService.java').read_text(encoding='utf-8')

failures = []

if 'versionCode 35' not in build:
    failures.append('APK must upgrade the delivered v0.3.11.7 versionCode 29')
if "versionName '0.3.11.13-mobile-polish2'" not in build:
    failures.append('APK must retain the intended v0.3.11.8 version name')

on_create = re.search(
    r'protected void onCreate\(Bundle savedInstanceState\) \{(?P<body>.*?)\n    \}',
    main,
    re.S,
)
if not on_create:
    failures.append('MainActivity.onCreate not found')
else:
    body = on_create.group('body')
    if body.index('setContentView(R.layout.activity_main)') > body.index('ThemeSupport.bg(this)'):
        failures.append('Layout must exist before system-bar styling')
    if body.index('bindViews()') > body.index('applySystemBarInsets()'):
        failures.append('Views must be bound before inset listeners are installed')
    if 'root.post(this::applyFullscreenMode)' not in body:
        failures.append('Immersive mode must be posted after layout setup')
    if not re.search(r'try \{\s*bindService\(', body):
        failures.append('Service binding must not abort Activity startup')

if 'import android.view.WindowInsetsController;' not in main:
    failures.append('Modern WindowInsetsController implementation is required')
if 'WindowInsets.Type.systemBars()' not in main:
    failures.append('Non-fullscreen insets must use modern systemBars()')
if 'private boolean isFullscreenEnabled()' not in main:
    failures.append('Fullscreen preference lookup must be guarded')
if 'if (artworkLoader != null) artworkLoader.shutdown();' not in main:
    failures.append('Partial startup teardown must tolerate a null artwork loader')
if 'b.post(() -> { applyFullscreenMode(); applySystemBarInsets(); });' not in main:
    failures.append('Fullscreen setting changes must wait for the UI transaction')

on_resume = re.search(r'protected void onResume\(\) \{(?P<body>.*?)\n    \}', main, re.S)
if not on_resume or 'root.post(this::applyFullscreenMode)' not in on_resume.group('body'):
    failures.append('Resume must defer immersive mode until the root view is attached')

configuration = re.search(
    r'void onConfigurationChanged\(Configuration newConfig\) \{(?P<body>.*?)\n    \}',
    main,
    re.S,
)
if not configuration or 'root.post(() -> { applyFullscreenMode(); applySystemBarInsets(); });' not in configuration.group('body'):
    failures.append('Configuration changes must defer fullscreen and inset reapplication')

for method_name in ('registerNoisyReceiver', 'registerScreenStateReceiver'):
    method = re.search(
        rf'private void {method_name}\(\) \{{(?P<body>.*?)\n    \}}',
        service,
        re.S,
    )
    if not method:
        failures.append(f'{method_name} not found')
    elif 'try {' not in method.group('body') or 'catch (RuntimeException ignored)' not in method.group('body'):
        failures.append(f'{method_name} must tolerate platform receiver-registration failures')

assert not failures, '\n'.join(failures)
print('PASS: current upgrade identity and guarded startup compatibility are present')
