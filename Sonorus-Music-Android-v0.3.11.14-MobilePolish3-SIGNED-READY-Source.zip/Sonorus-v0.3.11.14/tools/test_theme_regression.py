from pathlib import Path

settings = Path('app/src/main/java/com/brane/sonora/SonorusSettings.java').read_text(encoding='utf-8')
main = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
backdrop = Path('app/src/main/java/com/brane/sonora/ThemeBackdropView.java').read_text(encoding='utf-8')
styles = Path('app/src/main/res/values/styles.xml').read_text(encoding='utf-8')

assert 'THEME_OBSIDIAN = 4' in settings
assert 'THEME_CRIMSON = 5' in settings
assert '<= THEME_CRIMSON' in settings, 'Theme range must safely accept the two new IDs'
assert 'AppThemeObsidian' in main and 'AppThemeCrimson' in main
assert 'Obsidian 3D' in main and 'Crimson 3D' in main
assert 'style name="AppThemeObsidian"' in styles
assert 'style name="AppThemeCrimson"' in styles
assert 'URL_OBSIDIAN' in backdrop and 'URL_CRIMSON' in backdrop
assert 'THEME_OBSIDIAN' in backdrop and 'THEME_CRIMSON' in backdrop
assert 'LAYER_TYPE_SOFTWARE' not in backdrop, 'Theme backdrop must not force software rendering'
assert 'THREAD_PRIORITY_BACKGROUND' in backdrop, 'Theme photo I/O/decode must stay background priority'
print('PASS: Obsidian/Crimson themes and optimized photographic backdrops are wired')
