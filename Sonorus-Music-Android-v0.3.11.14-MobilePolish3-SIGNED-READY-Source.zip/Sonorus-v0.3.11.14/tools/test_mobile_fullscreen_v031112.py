from pathlib import Path
root=Path(__file__).resolve().parents[1]
mobile_layout=root/'app/src/main/res/layout/view_mobile_fullscreen_content.xml'
full=(root/'app/src/main/res/layout/view_fullscreen_now_playing.xml').read_text(encoding='utf-8')
main=(root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
text=mobile_layout.read_text(encoding='utf-8') if mobile_layout.exists() else ''
checks={
 'mobile_layout_exists': mobile_layout.exists(),
 'mobile_content_included': '@layout/view_mobile_fullscreen_content' in full,
 'desktop_content_id': 'fullscreenDesktopContent' in full,
 'dynamic_backdrop': 'mobileFullscreenBackdrop' in text and 'RenderEffect.createBlurEffect' in main,
 'large_cover': 'mobileFullscreenCover' in text,
 'no_now_playing_label': 'ŠTO SVIRA' not in text,
 'sonorus_brand': 'SONORUS' in text,
 'quick_actions': all(x in text for x in ['mobileFullscreenQueueButton','mobileFullscreenFavoriteButton','mobileFullscreenAddPlaylistButton','mobileFullscreenLyricsButton']),
 'transport': all(x in text for x in ['mobileFullscreenPrevButton','mobileFullscreenPlayButton','mobileFullscreenNextButton','mobileFullscreenShuffleButton','mobileFullscreenRepeatButton']),
 'lyrics_sheet': all(x in text for x in ['mobileFullscreenLyricsSheet','mobileFullscreenLyricsDownloadButton','mobileFullscreenLyricsInputButton','mobileFullscreenLyricsEditButton','mobileFullscreenLyricsCloseButton']),
 'phone_toggle': 'phoneFullscreen' in main and 'mobileFullscreenContent.setVisibility' in main and 'fullscreenDesktopContent.setVisibility' in main,
 'mobile_progress': 'mobileFullscreenProgress' in main,
 'lyrics_input_and_edit': 'showFullscreenLyricsEditor(true)' in main and 'showFullscreenLyricsEditor(false)' in main,
}
failed=[]
for k,v in checks.items():
 print(f'{k}: {"PASS" if v else "FAIL"}')
 if not v: failed.append(k)
if failed: raise SystemExit(1)
