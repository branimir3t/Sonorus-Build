from pathlib import Path
normalizer = Path('app/src/main/java/com/brane/sonora/LoudnessNormalizer.java').read_text(encoding='utf-8')
engine = Path('app/src/main/java/com/brane/sonora/AudioEngine.java').read_text(encoding='utf-8')
assert 'TARGET_RMS_DB = -12.0f' in normalizer, 'Live normalization target must be raised from the old -18 dB profile'
assert 'MAX_BOOST_DB = 12.0f' in normalizer, 'Quiet tracks need sufficient upward gain range'
assert 'safePeak = 0.891f' in normalizer, 'Peak headroom should stay around -1 dBFS'
assert 'sonorus_loudness_cache_v2' in normalizer, 'Old -18 dB cached analyses must not be reused'
assert 'Math.min(1200' in engine, 'AudioEngine must allow the analyzer-approved boost range instead of capping at the old 6 dB'
print('PASS: live loudness profile is louder, cache-safe and engine boost range matches analyzer')
