from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
layout = (root/'app/src/main/res/layout/view_fullscreen_now_playing.xml').read_text(encoding='utf-8')
main = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
lyrics = (root/'app/src/main/java/com/brane/sonora/LyricsRepository.java').read_text(encoding='utf-8')
gradle = (root/'app/build.gradle').read_text(encoding='utf-8')
ambient = root/'app/src/main/res/drawable-nodpi/sonorus_turntable_ambient_full.jpg'

checks = {
    'version_bumped': 'versionCode 35' in gradle and "versionName '0.3.11.13-mobile-polish2'" in gradle,
    'full_screen_background_asset': '@drawable/sonorus_turntable_ambient_full' in layout and ambient.exists() and ambient.stat().st_size > 120_000,
    'background_not_black_bars': 'android:id="@+id/fullscreenAmbientBackground"' in layout and 'android:scaleType="centerCrop"' in layout and '#46070606' not in layout,
    'compact_modern_player': 'android:id="@+id/fullscreenPlayerCard"' in layout and 'android:paddingTop="11dp"' in layout and 'android:paddingBottom="10dp"' in layout and 'android:textSize="18sp"' in layout,
    'compact_controls': 'android:layout_height="46dp"' in layout and 'android:layout_height="42dp"' in layout and layout.count('android:background="@drawable/bg_chip"') >= 4,
    'lyrics_edit_button': 'android:id="@+id/fullscreenLyricsEditButton"' in layout and 'Unesi / uredi' in layout,
    'lyrics_edit_wired': 'fullscreenLyricsEditButton = findViewById(R.id.fullscreenLyricsEditButton);' in main and 'showFullscreenLyricsEditor()' in main,
    'lyrics_manual_save_api': 'public boolean saveLocal(Track track, String lyrics)' in lyrics,
    'lyrics_editor_dialog': 'private void showFullscreenLyricsEditor()' in main and 'setHint("Upiši ili uredi tekst pjesme")' in main and 'setPositiveButton("Spremi"' in main,
    'lyrics_editor_refresh': 'fullscreenLyrics.setText(text);' in main and 'fullscreenLyricsStatus.setVisibility(View.GONE);' in main,
}

failed=[]
for name, ok in checks.items():
    print(f'{name}: {"PASS" if ok else "FAIL"}')
    if not ok: failed.append(name)
if failed:
    raise SystemExit(1)
