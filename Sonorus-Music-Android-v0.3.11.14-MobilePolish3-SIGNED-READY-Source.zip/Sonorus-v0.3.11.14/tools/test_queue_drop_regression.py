from pathlib import Path
import re

src = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
# Queue reorder must determine the insertion index from the actual ACTION_DROP coordinates,
# not only from the last ACTION_DRAG_LOCATION cached value.
m = re.search(r'case DragEvent\.ACTION_DROP:(.*?)(?:case DragEvent\.ACTION_DRAG_EXITED:)', src, re.S)
assert m, 'ACTION_DROP block not found'
block = m.group(1)
queue_branch = block.split('} else {', 1)[1] if '} else {' in block else ''
assert 'rowAt(list, event.getX(), event.getY(), true)' in queue_branch, (
    'Queue ACTION_DROP still uses a stale cached insertion index instead of the actual drop coordinates'
)
print('PASS: queue drop uses actual ACTION_DROP coordinates')
