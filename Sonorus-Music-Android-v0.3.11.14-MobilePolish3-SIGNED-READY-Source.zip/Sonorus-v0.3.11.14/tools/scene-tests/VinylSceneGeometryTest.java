package com.brane.sonora;
public final class VinylSceneGeometryTest {
    static void near(double a,double b) { if(Math.abs(a-b)>0.001) throw new AssertionError(a+" != "+b); }
    public static void main(String[] args) {
        for(int angle=0;angle<=360;angle+=5) {
            double[] center=VinylSceneGeometry.projectRotated(0,0,angle);
            near(center[0],524); near(center[1],480);
            for(int p=0;p<360;p+=5) {
                double[] edge=VinylSceneGeometry.projectRotated(Math.cos(Math.toRadians(p)),Math.sin(Math.toRadians(p)),angle);
                if(edge[0]<195 || edge[0]>850 || edge[1]<397 || edge[1]>587) throw new AssertionError("Disc leaves platter");
            }
            if(Math.abs(VinylSceneGeometry.armLift(angle))>0.18) throw new AssertionError("Arm lifts too far");
        }
        near(VinylSceneGeometry.advance(15,900,true),195);
        near(VinylSceneGeometry.advance(15,900,false),15);
        near(VinylSceneGeometry.advance(350,100,true),10);
        near(VinylSceneGeometry.armLift(0),VinylSceneGeometry.armLift(360));
        near(VinylSceneGeometry.fitScale(970,866),1);
        near(VinylSceneGeometry.fitScale(485,1000),0.5);
        System.out.println("PASS: fixed spindle, full revolution within platter, gentle periodic arm, play/pause and fit scaling");
    }
}
