from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text()
def method(name):
 return re.search(r'void '+name+r'\([^)]*\)\s*\{(.*?)\n    \}',s,re.S).group(1)
assert 'sceneActivityResumed = false' in method('onPause'), 'Pause must close a lifecycle gate, not only stop current frame'
assert 'sceneActivityResumed = true' in method('onResume'), 'Resume must reopen the scene lifecycle gate'
assert 'sceneActivityResumed && visible && playing' in method('updateFullscreenTurntableState'), 'Later audio callbacks must not restart a paused scene'
print('PASS: audio refresh callbacks cannot reopen paused activity animation')
