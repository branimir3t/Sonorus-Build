from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
icons = [
    'ic_menu_add.xml','ic_menu_queue.xml','ic_menu_edit.xml','ic_menu_bell.xml',
    'ic_menu_share.xml','ic_menu_info.xml','ic_menu_multiselect.xml','ic_menu_delete.xml',
    'ic_menu_ringtone.xml','ic_menu_alarm.xml','ic_menu_notification.xml'
]
checks = {
    'share_action_present': 'Podijeli' in main and 'shareTrack(track)' in main,
    'android_share_intent': 'Intent.ACTION_SEND' in main and 'Intent.EXTRA_STREAM' in main,
    'share_uri_permission': 'Intent.FLAG_GRANT_READ_URI_PERMISSION' in main and 'ClipData.newRawUri' in main,
    'audio_mime_type': 'audio/*' in main,
    'icon_aware_menu_rows': 'addCompactMenuItem(LinearLayout panel, int iconResId, String label, Runnable action)' in main,
    'compound_icon': 'setCompoundDrawablesWithIntrinsicBounds' in main and 'setCompoundDrawablePadding' in main,
    'track_menu_narrower': 'compactTrackMenuWidthPx' in main and 'showCompactTrackMenuDialog' in main,
    'track_menu_dense_row': 'item.setMinHeight(dp(34))' in main and 'item.setTextSize(13)' in main,
    'icons_exist': all((root/'app/src/main/res/drawable'/name).exists() for name in icons),
    'delete_uses_icon': 'R.drawable.ic_menu_delete' in main and 'Ukloni iz Sonorusa' in main,
    'add_uses_icon': 'R.drawable.ic_menu_add' in main and 'Dodaj u playlistu' in main,
}
failed=[]
for k,v in checks.items():
    print(f'{k}: {"PASS" if v else "FAIL"}')
    if not v: failed.append(k)
if failed:
    raise SystemExit(1)
