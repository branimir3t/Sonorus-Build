from pathlib import Path
import re

service = Path('app/src/main/java/com/brane/sonora/PlaybackService.java').read_text(encoding='utf-8')
main = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
art = Path('app/src/main/java/com/brane/sonora/ArtworkLoader.java').read_text(encoding='utf-8')

assert 'playbackHealthTicker' in service, 'Service-side playback/radio health ticker missing'
assert 'armPlaybackHealthTicker' in service, 'Health ticker must be armed only for active playback/radio'
assert 'radioRecoveryTask' in service and 'cancelRadioRecovery' in service, 'Radio reconnect callbacks must be cancellable'
assert 'mainHandler.removeCallbacks(playbackHealthTicker)' in service, 'Health ticker must be removed on destroy'

m = re.search(r'@Override public void onTrackChanged\(Track track, int index\) \{(.*?)\n    \}', service, re.S)
assert m and 'updateSessionQueue();' not in m.group(1), 'Track change must not rebuild unchanged MediaSession queue'

assert 'PROGRESS_UI_INTERVAL_MS' in main and 'lastProgressUiMs' in main, 'UI progress updates must be throttled independently of audio ticker'
assert 'Executors.newFixedThreadPool(2)' in art, 'Artwork I/O should use bounded two-thread pool'
assert 'new Size(320, 320)' in art, 'Artwork decode target should be bounded for smooth scrolling'
print('PASS: live playback/radio stability guards are present')
