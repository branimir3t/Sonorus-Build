from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
LAYOUT = ROOT / 'app/src/main/res/layout/activity_main.xml'
MAIN = ROOT / 'app/src/main/java/com/brane/sonora/MainActivity.java'
ANDROID = '{http://schemas.android.com/apk/res/android}'

def id_name(el):
    raw = el.attrib.get(ANDROID + 'id', '')
    return raw.split('/')[-1] if '/' in raw else raw

def find(root, name):
    for el in root.iter():
        if id_name(el) == name:
            return el
    raise AssertionError(f'missing view id: {name}')

root = ET.parse(LAYOUT).getroot()
main = MAIN.read_text(encoding='utf-8')

# Header search trigger + dropdown row.
find(root, 'mobileQueueSearchToggle')
row = find(root, 'mobileQueueSearchRow')
assert row.attrib.get(ANDROID + 'visibility') == 'gone', 'mobile search row must start collapsed'
find(root, 'mobileQueueSearchBox')

# Compact transport and seek controls.
for view_id in ('mobileQueuePrevButton', 'mobileQueuePlayButton', 'mobileQueueStopButton', 'mobileQueueNextButton',
                'mobileQueueProgress', 'mobileQueueCurrentTime', 'mobileQueueTotalTime'):
    find(root, view_id)

# Footer is deliberately compact and centered.
footer = find(root, 'mobileQueueMetaBar')
assert footer.attrib.get(ANDROID + 'layout_height') in ('34dp', '36dp', '38dp'), 'mobile queue meta bar is still too tall'
meta = find(root, 'mobileQueueMeta')
assert meta.attrib.get(ANDROID + 'gravity') == 'center', 'mobile queue meta must be centered'
assert meta.attrib.get(ANDROID + 'layout_width') == 'match_parent', 'mobile queue meta should use full centered width'

# Wiring: search toggles, four controls, progress updates and time labels.
for token in (
    'R.id.mobileQueueSearchToggle',
    'R.id.mobileQueuePrevButton',
    'R.id.mobileQueuePlayButton',
    'R.id.mobileQueueStopButton',
    'R.id.mobileQueueNextButton',
    'R.id.mobileQueueProgress',
    'mobileQueueSearchRow.setVisibility',
    'mobileQueueProgress.setProgress',
    'mobileQueueCurrentTime.setText',
    'mobileQueueTotalTime.setText',
):
    assert token in main, f'missing MainActivity wiring: {token}'

print('mobile player compact controls: PASS')
