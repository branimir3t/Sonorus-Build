from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
layout = (root/'app/src/main/res/layout/view_fullscreen_now_playing.xml').read_text(encoding='utf-8')
main = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
gradle = (root/'app/build.gradle').read_text(encoding='utf-8')

checks = {
    'version': "versionName '0.3.11.13-mobile-polish2'" in gradle and 'versionCode 35' in gradle,
    'ambient_background': 'fullscreenAmbientBackground' in layout and '@drawable/sonorus_turntable_ambient_full' in layout,
    'photo_scene': 'fullscreenScenePhoto' in layout and '@drawable/sonorus_turntable_scene' in layout,
    'no_drawn_turntable': 'com.brane.sonora.TurntableView' not in layout and 'com.brane.sonora.TonearmView' not in layout and 'com.brane.sonora.VinylRecordView' not in layout,
    'dynamic_cover': 'fullscreenCover' in layout and 'fullscreenCoverSleeve' in layout and 'artworkLoader.load(track, fullscreenCover)' in main,
    'dynamic_label': 'fullscreenRecordLabel' in layout and 'artworkLoader.load(track, fullscreenRecordLabel)' in main,
    'photographic_sizing': 'layoutFullscreenPhotographicStage' in main,
    'rpm': 'VINYL_REVOLUTION_MS = 1800L' in main,
    'lyrics_scroll': 'fullscreenLyricsScroll' in layout and 'android:scrollbars="vertical"' in layout,
    'lyrics_dominant': 'android:id="@+id/fullscreenLyricsCard"' in layout and 'android:layout_weight="1"' in layout,
}

for name, ok in checks.items():
    print(f'{name}: {"OK" if ok else "FAIL"}')
if not all(checks.values()):
    raise SystemExit(1)

scene = root/'app/src/main/res/drawable-nodpi/sonorus_turntable_scene.jpg'
ambient = root/'app/src/main/res/drawable-nodpi/sonorus_turntable_ambient.jpg'
for p, minimum in ((scene, 100_000), (ambient, 20_000)):
    print(p.name, p.stat().st_size if p.exists() else 0)
    if not p.exists() or p.stat().st_size < minimum:
        raise SystemExit(1)
