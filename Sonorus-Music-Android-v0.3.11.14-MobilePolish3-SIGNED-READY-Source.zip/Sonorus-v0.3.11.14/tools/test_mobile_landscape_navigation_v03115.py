from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
layout = (root / 'app/src/main/res/layout/activity_main.xml').read_text(encoding='utf-8')

checks = []
def check(name, cond):
    checks.append((name, bool(cond)))

# Root cause guard: responsive mode must consider both orientation and height, not width alone.
check('responsive reads display height', 'heightDp' in main)
check('mobile landscape uses orientation', 'Configuration.ORIENTATION_LANDSCAPE' in main)
check('compact mobile landscape profile exists', 'mobileLandscape' in main)
check('compact landscape excludes wide tablet layout', re.search(r'mobileLandscape\s*=.*!wideLayout', main) is not None)
check('compact landscape has phone-height guard', 'heightDp < 600' in main)

# The 172dp hero is the element that starves the weighted catalog/settings area on short phones.
# In compact landscape it must be hidden and the existing compact playerBar must be used instead.
check('hero hidden in compact mobile landscape', re.search(r'heroPanel\.setVisibility\([^;]*mobileLandscape', main) is not None)
check('compact player visibility delegated', 'updateMobileMiniPlayerVisibility' in main and 'playerBar.setVisibility(phone && fullscreenHidden && localTrack ? View.VISIBLE : View.GONE)' in main)

# Fixed chrome must be explicitly compacted and restored after rotation.
for marker, compact, normal, label in [
    ('search', 48, 56, 'search row'),
    ('nav', 44, 52, 'mobile nav'),
    ('radio', 54, 76, 'radio card'),
    ('context', 30, 36, 'context header'),
    ('player', 58, 66, 'compact player'),
]:
    check(f'{label} compact/restore sizing', f'{marker}HeightDp = mobileLandscape ? {compact} : {normal};' in main)

# The main content remains weight-based and Settings remains a scrollable full child of that area.
check('main content keeps weighted remaining height', 'android:layout_height="0dp"' in layout and 'android:layout_weight="1"' in layout)
settings = layout[layout.find('android:id="@+id/settingsPanel"'):layout.find('android:id="@+id/permissionPanel"')]
check('settings remains scrollable and fills content area', '<ScrollView' in layout[layout.rfind('<ScrollView', 0, layout.find('android:id="@+id/settingsPanel"')):layout.find('android:id="@+id/settingsPanel"')+200] and 'android:layout_height="match_parent"' in settings[:300])

# All nine mobile navigation targets must still route through selectSection.
for section in ['HOME','MUSIC','ARTISTS','ALBUMS','GENRES','FOLDERS','PLAYLISTS','FAVORITES','SETTINGS']:
    check(f'mobile nav {section.lower()} remains wired', f'Section.{section}' in main)
check('all mobile nav buttons still attach through shared handler', main.count('attachNav(R.id.nav') >= 9)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    raise SystemExit(1)
