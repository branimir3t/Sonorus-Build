from pathlib import Path

root = Path(__file__).resolve().parents[1]
layout = (root/'app/src/main/res/layout/view_fullscreen_now_playing.xml').read_text(encoding='utf-8')

checks = {
    'ambient_background_uses_ambient_asset': 'android:id="@+id/fullscreenAmbientBackground"' in layout and '@drawable/sonorus_turntable_ambient_full' in layout,
    'scene_photo_kept_for_left_stage': 'android:id="@+id/fullscreenScenePhoto"' in layout and '@drawable/sonorus_turntable_scene' in layout,
    'scene_asset_referenced_once': layout.count('@drawable/sonorus_turntable_scene') == 1,
    'ambient_asset_referenced_once': layout.count('@drawable/sonorus_turntable_ambient_full') == 1,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f'{name}: {'PASS' if ok else 'FAIL'}')
if failed:
    raise SystemExit(1)
