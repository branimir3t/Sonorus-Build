from pathlib import Path
root = Path(__file__).resolve().parents[1]
gradle = (root/'app/build.gradle').read_text(encoding='utf-8')
gitignore = (root/'.gitignore').read_text(encoding='utf-8')
checks = {
    'signing_props_loaded': 'keystore.properties' in gradle,
    'release_signing_config': 'signingConfigs' in gradle and 'signingConfig signingConfigs.release' in gradle,
    'no_debug_fallback_for_release': 'signingConfig signingConfigs.debug' not in gradle,
    'missing_props_fail_clear': 'Missing keystore.properties' in gradle,
    'android_studio_injected_signing_supported': 'android.injected.signing.store.file' in gradle and '!hasInjectedSigning' in gradle,
    'secrets_gitignored': 'keystore.properties' in gitignore and '*.jks' in gitignore and '*.keystore' in gitignore,
    'example_present': (root/'keystore.properties.example').exists(),
    'release_script_present': (root/'BUILD-SIGNED-RELEASE.cmd').exists(),
    'debug_script_present': (root/'BUILD-UPDATE-DEBUG.cmd').exists(),
    'guide_present': (root/'SIGNED-BUILD-README.txt').exists(),
}
failed=[]
for k,v in checks.items():
    print(f'{k}: {"PASS" if v else "FAIL"}')
    if not v: failed.append(k)
if failed:
    raise SystemExit(1)
