from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
layout_p = root / 'app/src/main/res/layout/view_fullscreen_now_playing.xml'
main_p = root / 'app/src/main/java/com/brane/sonora/MainActivity.java'
turntable_p = root / 'app/src/main/java/com/brane/sonora/TurntableView.java'
vinyl_p = root / 'app/src/main/java/com/brane/sonora/VinylRecordView.java'
tonearm_p = root / 'app/src/main/java/com/brane/sonora/TonearmView.java'
build_p = root / 'app/build.gradle'

layout = layout_p.read_text(encoding='utf-8')
main = main_p.read_text(encoding='utf-8')
turntable = turntable_p.read_text(encoding='utf-8')
build = build_p.read_text(encoding='utf-8')
vinyl = vinyl_p.read_text(encoding='utf-8') if vinyl_p.exists() else ''
tonearm = tonearm_p.read_text(encoding='utf-8') if tonearm_p.exists() else ''

checks = []
def check(name, cond): checks.append((name, bool(cond)))

# Premium composition: one grounded stage, compact player, large contained lyrics.
check('turntable stage is integrated', 'fullscreenTurntableFrame' in layout and 'clipChildren="false"' in layout)
check('cover sleeve integrated into stage', 'fullscreenCoverSleeve' in layout and 'fullscreenCover' in layout)
check('compact player card exists', 'fullscreenPlayerCard' in layout)
check('large lyrics card exists', 'fullscreenLyricsCard' in layout)
check('lyrics use dedicated scroll container', 'fullscreenLyricsScroll' in layout and '<ScrollView' in layout)
check('lyrics panel keeps text inside screen', re.search(r'android:id="@\+id/fullscreenLyricsScroll"[\s\S]*?android:layout_height="0dp"[\s\S]*?android:layout_weight="1"', layout) is not None)
check('no whole-screen content ScrollView', layout.count('<ScrollView') == 1)
check('fullscreen visual and info columns fill available height', 'android:id="@+id/fullscreenVisualColumn"' in layout and 'android:id="@+id/fullscreenInfoColumn"' in layout)

# Realistic vinyl and perspective.
check('vinyl record custom view exists', vinyl_p.exists())
check('vinyl draws grooves', 'drawArc' in vinyl and 'drawCircle' in vinyl)
check('vinyl uses radial shading', 'RadialGradient' in vinyl)
check('layout uses photographic vinyl scene', 'fullscreenScenePhoto' in layout and '@drawable/sonorus_turntable_scene' in layout)
check('tonearm custom view exists', tonearm_p.exists())
check('photographic scene carries realistic tonearm', 'com.brane.sonora.TonearmView' not in layout and 'fullscreenScenePhoto' in layout)
check('tonearm has engaged animation', 'ValueAnimator' in tonearm and 'setEngaged' in tonearm)
check('turntable base uses perspective path', 'Path' in turntable and 'drawPath' in turntable)
check('turntable base draws grounded shadow', 'drawOval' in turntable and 'LinearGradient' in turntable)

# Natural 33 1/3 rpm rotation and 3D perspective.
check('natural vinyl speed around 33 rpm', 'VINYL_REVOLUTION_MS = 1800L' in main)
check('vinyl has a shared projective plane', 'canvas.concat(plane)' in (root/'app/src/main/java/com/brane/sonora/PhotographicVinylScene.java').read_text())
check('vinyl keeps linear rotation', 'elapsed*360f/1800f' in (root/'app/src/main/java/com/brane/sonora/VinylSceneGeometry.java').read_text())
check('photographic platter motion follows playback', 'updateFullscreenTurntableState' in main and 'fullscreenVinylAnimator' in main)

# Responsive composition should size stage and columns without clipping.
check('fullscreen stage field exists', 'fullscreenTurntableFrame' in main)
check('cover sleeve field exists', 'fullscreenCoverSleeve' in main)
check('lyrics scroll field exists', 'fullscreenLyricsScroll' in main)
check('responsive photographic sizing exists', 'layoutFullscreenPhotographicStage' in main)
check('wide columns use asymmetric weights', 'android:layout_weight="1.16"' in layout and 'android:layout_weight="0.84"' in layout)

# Version/preservation.
check('version code 35', re.search(r'versionCode\s+35\b', build) is not None)
check('version name 0.3.11.13', "versionName '0.3.11.13-mobile-polish2'" in build)
check('application id preserved', "applicationId 'com.brane.sonora'" in build)

failed = [n for n, ok in checks if not ok]
for n, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    raise SystemExit(1)
