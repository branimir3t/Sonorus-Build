from pathlib import Path

build = Path('app/build.gradle').read_text(encoding='utf-8')
settings = Path('app/src/main/java/com/brane/sonora/SonorusSettings.java').read_text(encoding='utf-8')
engine = Path('app/src/main/java/com/brane/sonora/AudioEngine.java').read_text(encoding='utf-8')
ids = Path('app/src/main/java/com/brane/sonora/IdStore.java').read_text(encoding='utf-8')
metadata = Path('app/src/main/java/com/brane/sonora/TrackMetadataStore.java').read_text(encoding='utf-8')
playlists = Path('app/src/main/java/com/brane/sonora/PlaylistStore.java').read_text(encoding='utf-8')

assert "applicationId 'com.brane.sonora'" in build
assert 'versionCode 35' in build
assert "versionName '0.3.11.13-mobile-polish2'" in build
assert '"sonorus_settings"' in settings
assert '"sonora_player"' in engine
assert '"sonora_ids"' in ids
assert '"sonorus_track_overrides"' in metadata
assert '"sonora_playlists"' in playlists
print('PASS: upgrade identity and persistent stores are preserved')
