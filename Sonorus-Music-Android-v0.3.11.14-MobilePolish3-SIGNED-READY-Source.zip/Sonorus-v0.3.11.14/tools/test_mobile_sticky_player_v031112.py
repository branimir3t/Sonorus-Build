from pathlib import Path
root = Path(__file__).resolve().parents[1]
layout = (root/'app/src/main/res/layout/activity_main.xml').read_text(encoding='utf-8')
main = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
bg = root/'app/src/main/res/drawable/bg_mobile_mini_player.xml'
checks = {
    'mini_bg_exists': bg.exists(),
    'compact_height': 'android:id="@+id/playerBar"' in layout and 'android:layout_height="66dp"' in layout,
    'queue_button': 'mobileBottomQueueButton' in layout and 'mobileBottomQueueButton' in main,
    'compact_cover': 'android:id="@+id/nowArt"' in layout and 'android:layout_width="46dp"' in layout,
    'progress_hidden': 'android:id="@+id/progressBar"' in layout and 'android:visibility="gone"' in layout,
    'visibility_helper': 'updateMobileMiniPlayerVisibility' in main,
    'hidden_in_fullscreen': 'fullscreenNowPlayingOverlay.getVisibility() != View.VISIBLE' in main,
    'restored_on_close': 'hideFullscreenNowPlaying()' in main and 'updateMobileMiniPlayerVisibility();' in main,
    'phone_only': 'widthDp < 700' in main,
}
failed=[]
for k,v in checks.items():
    print(f'{k}: {"PASS" if v else "FAIL"}')
    if not v: failed.append(k)
if failed: raise SystemExit(1)
