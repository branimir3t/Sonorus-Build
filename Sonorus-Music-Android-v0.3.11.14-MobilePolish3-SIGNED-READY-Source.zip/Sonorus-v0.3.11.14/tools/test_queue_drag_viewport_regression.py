from pathlib import Path
import re
src = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
m = re.search(r'case DragEvent\.ACTION_DRAG_ENDED:(.*?)(?:return true;)', src, re.S)
assert m, 'ACTION_DRAG_ENDED block not found'
block=m.group(1)
assert 'scrollPlayerToCurrent(false)' not in block, (
    'Queue drag end recenters the current song and makes the dropped row appear to jump away'
)
print('PASS: drag end preserves queue viewport')
