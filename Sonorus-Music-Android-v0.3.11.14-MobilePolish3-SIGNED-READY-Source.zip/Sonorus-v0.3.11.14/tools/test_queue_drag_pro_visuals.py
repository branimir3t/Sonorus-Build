from pathlib import Path

adapter = Path('app/src/main/java/com/brane/sonora/QueueAdapter.java').read_text(encoding='utf-8')
main = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')

assert 'callbacks.onDragStart(h.root, position)' in adapter, 'Drag shadow must use the full queue row, not only the ≡ handle'
assert 'case DragEvent.ACTION_DRAG_EXITED:' in main and 'adapter.updateDropIndex(-1)' in main, 'Leaving the list should clear only the target preview, not cancel the drag state'
assert 'ColorDrawable dropIndicator' not in main, 'Queue reorder must not reintroduce an extra insertion line'
print('PASS: queue drag uses full-row shadow and line-free stable target preview')
