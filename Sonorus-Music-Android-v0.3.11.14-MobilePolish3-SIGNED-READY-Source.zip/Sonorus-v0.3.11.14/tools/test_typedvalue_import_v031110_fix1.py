from pathlib import Path
main = (Path(__file__).resolve().parents[1]/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
uses = 'TypedValue out = new TypedValue();' in main
has_import = 'import android.util.TypedValue;' in main
print('typedvalue_used:', 'PASS' if uses else 'FAIL')
print('typedvalue_imported:', 'PASS' if has_import else 'FAIL')
if not uses or not has_import:
    raise SystemExit(1)
