from pathlib import Path
src = Path('app/src/main/java/com/brane/sonora/PlaybackService.java').read_text(encoding='utf-8')
assert 's.startsWith("[") ? new JSONArray(s) : new JSONObject(s)' in src, 'Radio metadata must parse top-level JSON arrays as well as objects'
assert 'private String extractRadioMetadata(Object node)' in src, 'Recursive radio metadata extractor missing'
assert 'node instanceof JSONArray' in src and 'node instanceof JSONObject' in src, 'Nested JSON arrays/objects must be supported'
assert 'if (song == null || song.isEmpty()) return;' in src, 'Failed metadata refresh must preserve the last good song instead of overwriting it'
assert 'OLD_SCHOOL_METADATA_DIRECT' in src and 'OLD_SCHOOL_METADATA_PROXY' in src, 'Proxy + direct metadata fallback chain must remain intact'
print('PASS: radio metadata parser supports arrays/nesting and preserves last good metadata')
