from pathlib import Path
import re

layout = Path('app/src/main/res/layout/activity_main.xml').read_text(encoding='utf-8')
radio = Path('app/src/main/res/drawable/bg_radio_premium.xml').read_text(encoding='utf-8')
java = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')

assert 'android:id="@+id/leftClockText"' in layout, 'Tablet left clock is missing'
assert 'android:id="@+id/leftDateText"' in layout, 'Tablet left date is missing'
assert '?attr/sonorusDivider' in radio, 'Radio card border must match idle navigation border color'
assert 'android:width="1dp"' in radio, 'Radio card border must match idle navigation border width'
assert 'updateLeftClock' in java, 'Clock update method missing'
assert 'HH:mm' in java, '24-hour clock format missing'
assert 'EEEE, dd.MM.yyyy.' in java, 'Croatian long date format missing'
assert 'removeCallbacks(clockTicker)' in java, 'Clock ticker must be cancelled with Activity lifecycle'
print('PASS: radio frame matches menu and tablet clock/date are wired')
