from pathlib import Path

root = Path(__file__).resolve().parents[1]
layout = (root/'app/src/main/res/layout/catalog_item.xml').read_text()
adapter = (root/'app/src/main/java/com/brane/sonora/CatalogAdapter.java').read_text()
activity = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text()
service = (root/'app/src/main/java/com/brane/sonora/PlaybackService.java').read_text()

checks = {
    'preview button exists before favorite': layout.find('@+id/previewButton') != -1 and layout.find('@+id/previewButton') < layout.find('@+id/favoriteButton'),
    'adapter exposes preview callback': 'void onEntryPreview(Track track);' in adapter,
    'preview visible only for tracks': 'h.preview.setVisibility' in adapter and 'CatalogEntry.Kind.TRACK' in adapter,
    'preview button invokes callback': 'callbacks.onEntryPreview(e.track)' in adapter,
    'service has catalog preview API': 'startCatalogPreview(Track track)' in service and 'stopCatalogPreview()' in service,
    'preview does not add to queue': 'playTrackNow(track)' not in service[service.find('startCatalogPreview(Track track)'):service.find('stopCatalogPreview()', service.find('startCatalogPreview(Track track)'))],
    'service pauses main engine for preview': 'previewResumeEngineAfterStop = engine != null && engine.isPlaying()' in service and 'engine.pause();' in service,
    'service restores prior player position without auto-resume': (lambda block: 'engine.seekTo(savedPosition);' in block and 'engine.resume();' not in block)(service[service.find('private void restorePlaybackAfterCatalogPreview()'):service.find('private void clearCatalogPreviewRestoreState()', service.find('private void restorePlaybackAfterCatalogPreview()'))]),
    'activity connects catalog preview': 'onEntryPreview(Track track)' in activity and 'playbackService.startCatalogPreview(track)' in activity,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
if failed:
    raise SystemExit(f'{len(failed)} checks failed: {failed}')
print(f'PASS: {len(checks)}/{len(checks)} catalog preview checks')
