from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
art = (root/'app/src/main/java/com/brane/sonora/ArtworkLoader.java').read_text(encoding='utf-8')
local_art_path = root/'app/src/main/java/com/brane/sonora/LocalArtworkStore.java'
local_art = local_art_path.read_text(encoding='utf-8') if local_art_path.exists() else ''

checks = {
    'next_option_removed': 'Reproduciraj sljedeće' not in main,
    'track_menu_custom_compact': 'buildCompactTrackOptionsPanel' in main and 'addCompactMenuItem' in main,
    'track_title_theme_accent': 'title.setTextColor(ThemeSupport.accent(this))' in main,
    'track_title_divider': 'ThemeSupport.divider(this)' in main and 'divider' in main,
    'cover_picker_request': 'REQUEST_COVER_IMAGE' in main and 'Intent.ACTION_OPEN_DOCUMENT' in main and 'image/*' in main,
    'edit_has_cover_action': 'Odaberi cover s uređaja' in main,
    'local_art_store_exists': local_art_path.exists(),
    'local_art_persists_file': 'cover_overrides' in local_art and 'FileOutputStream' in local_art,
    'artwork_override_precedes_media': 'LocalArtworkStore.load' in art and art.find('LocalArtworkStore.load') < art.find('loadThumbnail'),
    'artwork_invalidate': 'invalidateTrack' in art,
    'fullscreen_no_auto_hide_on_null_track': 'if (track == null) { hideFullscreenNowPlaying(); return; }' not in main,
    'fullscreen_no_radio_auto_hide': '&& fullscreenNowPlayingOverlay.getVisibility() == View.VISIBLE) hideFullscreenNowPlaying();' not in main,
    'fullscreen_manual_close_kept': 'fullscreenCloseButton.setOnClickListener(v -> hideFullscreenNowPlaying())' in main,
    'fullscreen_back_close_kept': 'onBackPressed()' in main and 'hideFullscreenNowPlaying(); return;' in main,
    'dialogs_theme_translucent': 'GradientDrawable dialogBackground' in main and 'ThemeSupport.card(this)' in main and 'setAlpha(' in main,
    'dialogs_compact_width': 'compactDialogWidthPx' in main,
    'all_alert_dialogs_use_helper': main.count('showPremiumDialog(') >= 10,
}

failed=[]
for k,v in checks.items():
    print(f'{k}: {"PASS" if v else "FAIL"}')
    if not v: failed.append(k)
if failed:
    raise SystemExit(1)
