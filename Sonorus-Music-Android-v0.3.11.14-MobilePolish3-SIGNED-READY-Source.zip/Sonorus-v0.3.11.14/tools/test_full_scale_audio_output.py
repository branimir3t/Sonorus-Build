from pathlib import Path
import re

settings = Path('app/src/main/java/com/brane/sonora/SonorusSettings.java').read_text(encoding='utf-8')
service = Path('app/src/main/java/com/brane/sonora/PlaybackService.java').read_text(encoding='utf-8')
engine = Path('app/src/main/java/com/brane/sonora/AudioEngine.java').read_text(encoding='utf-8')

# Live-use default must be neutral/full-scale unless the user explicitly enabled normalization.
assert 'getBoolean("loudness_normalization", false)' in settings, \
    'Loudness normalization must default OFF so untouched upgrades/new installs stay at neutral full-scale output'

# Media routing must remain standard MUSIC/MEDIA for Android Auto and normal playback devices.
assert 'AudioAttributes.USAGE_MEDIA' in engine and 'AudioAttributes.CONTENT_TYPE_MUSIC' in engine, \
    'Local playback must use MEDIA/MUSIC audio attributes'
assert 'AudioAttributes.USAGE_MEDIA' in service and 'AudioAttributes.CONTENT_TYPE_MUSIC' in service, \
    'Service audio focus must use MEDIA/MUSIC audio attributes'

# Local focus regain must always restore full master mix.
local_gain = re.search(r'case AudioManager\.AUDIOFOCUS_GAIN:(.*?)(?:case AudioManager\.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:)', service, re.S)
assert local_gain and 'engine.setMasterVolume(1f);' in local_gain.group(1) and 'engine.reassertOutputMix();' in local_gain.group(1), \
    'Local playback must restore full output mix on AUDIOFOCUS_GAIN'

# Radio focus regain must explicitly restore full player volume.
radio_handler = re.search(r'private void handleRadioFocusChange\(int focus\) \{(.*?)\n    \}', service, re.S)
assert radio_handler and 'case AudioManager.AUDIOFOCUS_GAIN:' in radio_handler.group(1) and 'setRadioVolume(1f);' in radio_handler.group(1), \
    'Radio must restore full volume on AUDIOFOCUS_GAIN'

# Health ticker must correct any stale Android Auto duck state after focus is back.
health = re.search(r'private final Runnable playbackHealthTicker = new Runnable\(\) \{(.*?)\n    \};', service, re.S)
assert health and 'if (radioPlaying && radioPlayer != null && focusHeld)' in health.group(1), \
    'Radio health ticker block missing'
assert 'if (!duckedForFocus) setRadioVolume(1f);' in health.group(1), \
    'Radio health ticker must reassert full volume whenever focus is held and not ducked'

print('PASS: neutral full-scale audio output and focus recovery are guarded')
