from pathlib import Path
root = Path(__file__).resolve().parents[1]
adapter = (root/'app/src/main/java/com/brane/sonora/CatalogAdapter.java').read_text(encoding='utf-8')
main = (root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
layout = root/'app/src/main/res/layout/catalog_album_grid_item.xml'
checks = {
    'album_grid_layout_exists': layout.exists(),
    'square_album_art': 'com.brane.sonora.SquareImageView' in (layout.read_text(encoding='utf-8') if layout.exists() else '') and (root/'app/src/main/java/com/brane/sonora/SquareImageView.java').exists(),
    'adapter_album_grid_mode': 'setAlbumGridMode' in adapter and 'albumGridMode' in adapter,
    'adapter_two_view_types': 'getViewTypeCount()' in adapter and 'getItemViewType' in adapter,
    'album_holder': 'AlbumHolder' in adapter and 'catalogAlbumArt' in adapter,
    'phone_album_two_columns': 'topLevelPhoneAlbums' in main and 'catalogGrid.setNumColumns(topLevelPhoneAlbums ? 2' in main,
    'album_grid_only_top_level': 'section == Section.ALBUMS && detailParent == null' in main,
}
failed=[]
for k,v in checks.items():
    print(f'{k}: {"PASS" if v else "FAIL"}')
    if not v: failed.append(k)
if failed: raise SystemExit(1)
