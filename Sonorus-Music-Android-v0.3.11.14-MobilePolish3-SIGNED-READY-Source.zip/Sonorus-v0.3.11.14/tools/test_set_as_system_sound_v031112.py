from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
helper_path=root/'app/src/main/java/com/brane/sonora/SystemSoundSetter.java'
helper=helper_path.read_text(encoding='utf-8') if helper_path.exists() else ''
checks={
 'helper_exists': helper_path.exists(),
 'write_settings_permission': 'android.permission.WRITE_SETTINGS' in manifest,
 'set_as_menu': 'Postavi kao…' in main and 'showSetAsSystemSoundMenu' in main,
 'ringtone_choice': 'Melodija zvona' in main,
 'alarm_choice': 'Alarm' in main,
 'notification_choice': 'Zvuk obavijesti' in main,
 'ringtone_manager': 'RingtoneManager.setActualDefaultRingtoneUri' in helper,
 'settings_flow': 'Settings.System.canWrite' in helper and 'ACTION_MANAGE_WRITE_SETTINGS' in helper,
 'mediastore_flags': 'IS_RINGTONE' in helper and 'IS_ALARM' in helper and 'IS_NOTIFICATION' in helper,
 'pending_retry': 'pendingSystemSoundTrackId' in main and 'applyPendingSystemSoundIfAllowed' in main,
}
failed=[]
for k,v in checks.items():
 print(f'{k}: {"PASS" if v else "FAIL"}')
 if not v: failed.append(k)
if failed: raise SystemExit(1)
