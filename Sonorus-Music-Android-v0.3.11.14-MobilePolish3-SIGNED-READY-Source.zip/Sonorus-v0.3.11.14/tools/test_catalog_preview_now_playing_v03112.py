from pathlib import Path

layout = Path('app/src/main/res/layout/catalog_item.xml').read_text(encoding='utf-8')
adapter = Path('app/src/main/java/com/brane/sonora/CatalogAdapter.java').read_text(encoding='utf-8')
activity = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
service = Path('app/src/main/java/com/brane/sonora/PlaybackService.java').read_text(encoding='utf-8')

checks = {
    'catalog timeline row removed': 'catalogPreviewProgressRow' not in layout,
    'catalog seekbar removed': 'catalogPreviewSeek' not in layout,
    'adapter no longer owns preview timeline state': 'previewPositionMs' not in adapter and 'previewDurationMs' not in adapter and 'onEntryPreviewSeek' not in adapter,
    'activity tracks active catalog preview': 'activeCatalogPreviewTrackId' in activity,
    'preview takes over now-playing presentation': 'showCatalogPreviewNowPlaying' in activity and 'heroTitle.setText(track.title)' in activity and 'nowTitle.setText(track.title)' in activity,
    'preview progress uses main now-playing timeline': 'updateCatalogPreviewNowPlayingProgress' in activity and 'heroProgressBar.setProgress' in activity and 'progressBar.setProgress' in activity,
    'stopping preview restores player presentation': 'activeCatalogPreviewTrackId = -1L' in activity and 'refreshPlayerViews();' in activity[activity.find('onCatalogPreviewChanged'):activity.find('onRadioStateChanged')],
    'catalog stop does not auto resume player': 'engine.seekTo(savedPosition);' in service[service.find('private void restorePlaybackAfterCatalogPreview()'):service.find('private void clearCatalogPreviewRestoreState()', service.find('private void restorePlaybackAfterCatalogPreview()'))] and 'engine.resume();' not in service[service.find('private void restorePlaybackAfterCatalogPreview()'):service.find('private void clearCatalogPreviewRestoreState()', service.find('private void restorePlaybackAfterCatalogPreview()'))],
    'player playback explicitly stops preview first': 'if (isCatalogPreviewActive()) stopCatalogPreviewInternal(false);' in service[service.find('public boolean prepareForPlayback()'):service.find('private void acquirePlaybackWakeLock')],
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise AssertionError('Missing: ' + '; '.join(failed))
print(f'PASS: {len(checks)}/{len(checks)} catalog preview now-playing checks')
