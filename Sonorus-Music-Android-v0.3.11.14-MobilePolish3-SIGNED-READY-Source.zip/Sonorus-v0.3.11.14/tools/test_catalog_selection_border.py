from pathlib import Path
import xml.etree.ElementTree as ET

java = Path('app/src/main/java/com/brane/sonora/CatalogAdapter.java').read_text(encoding='utf-8')
assert 'R.drawable.bg_catalog_selected : R.drawable.bg_catalog_idle' in java, 'Catalog adapter must use selected-only catalog backgrounds'

idle = Path('app/src/main/res/drawable/bg_catalog_idle.xml')
selected = Path('app/src/main/res/drawable/bg_catalog_selected.xml')
assert idle.exists(), 'bg_catalog_idle.xml missing'
assert selected.exists(), 'bg_catalog_selected.xml missing'

idle_text = idle.read_text(encoding='utf-8')
sel_text = selected.read_text(encoding='utf-8')
assert '<stroke' not in idle_text, 'Idle catalog card must have no border stroke'
assert '<stroke' in sel_text and '?attr/sonorusAccent' in sel_text, 'Selected catalog card must have accent border'
ET.parse(idle)
ET.parse(selected)
print('PASS: catalog uses border only for selected track')
