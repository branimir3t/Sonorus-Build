from pathlib import Path

backdrop = Path('app/src/main/java/com/brane/sonora/ThemeBackdropView.java').read_text(encoding='utf-8')
styles = Path('app/src/main/res/values/styles.xml').read_text(encoding='utf-8')
assert 'sans-serif-medium' in styles, 'Vinyl Gold must use clean sans-serif premium typography'
assert 'drawVinylMotionOverlay' in backdrop, 'Vinyl motion overlay missing'
assert 'postInvalidateDelayed(50L)' in backdrop, 'Vinyl animation must be throttled instead of redrawing at display refresh rate'
assert 'postInvalidateOnAnimation()' not in backdrop, 'Vinyl animation should not force a full 60/120 Hz redraw loop'
print('PASS: Vinyl Gold motion is present and throttled for playback-safe UI load')
