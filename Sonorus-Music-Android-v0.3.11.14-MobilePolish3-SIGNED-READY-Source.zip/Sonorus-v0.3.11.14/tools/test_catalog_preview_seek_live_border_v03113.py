from pathlib import Path

activity = Path('app/src/main/java/com/brane/sonora/MainActivity.java').read_text(encoding='utf-8')
adapter = Path('app/src/main/java/com/brane/sonora/CatalogAdapter.java').read_text(encoding='utf-8')
layout = Path('app/src/main/res/layout/catalog_item.xml').read_text(encoding='utf-8')
live_border = Path('app/src/main/java/com/brane/sonora/CatalogLiveBorderLayout.java')

checks = {
    'activity stores preview duration for seek': 'activeCatalogPreviewDurationMs' in activity,
    'main seek routes to catalog preview when active': 'playbackService.seekCatalogPreview(activeCatalogPreviewTrackId' in activity,
    'main seek keeps normal engine path otherwise': 'engine.seekTo(duration * seekBar.getProgress() / 1000L)' in activity,
    'preview ticker does not fight user drag': 'if (!userSeeking) {' in activity[activity.find('private void updateCatalogPreviewNowPlayingProgress'):activity.find('@Override public void onRadioStateChanged')],
    'catalog root uses live border layout': 'com.brane.sonora.CatalogLiveBorderLayout' in layout,
    'adapter marks currently previewing row as playing': 'h.root.setPreviewPlaying(previewing)' in adapter,
    'preview row reuses selected accent border': 'selected || previewing' in adapter,
    'dedicated live border view exists': live_border.exists(),
}

if live_border.exists():
    live = live_border.read_text(encoding='utf-8')
    checks.update({
        'live border animates only while preview plays': 'setPreviewPlaying(boolean playing)' in live and 'ValueAnimator.INFINITE' in live,
        'live border uses Sonorus accent': 'ThemeSupport.accent(getContext())' in live,
        'live border stops animator when inactive': 'animator.cancel()' in live,
    })

failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise AssertionError('Missing: ' + '; '.join(failed))
print(f'PASS: {len(checks)}/{len(checks)} catalog preview seek/live-border checks')
