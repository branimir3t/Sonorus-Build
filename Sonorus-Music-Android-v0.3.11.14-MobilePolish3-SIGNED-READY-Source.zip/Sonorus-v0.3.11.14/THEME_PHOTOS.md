# Sonorus theme photo sources

Premium themes use fixed real-photo Unsplash sources. The app downloads the selected background once and stores it in its private theme cache, so later launches can reuse the cached photograph offline. If the image is not yet cached and the device has no network, the theme falls back to its dark themed surface instead of showing a broken image.

- **Midnight Stage** — Family Life (@familylifecs), blue stage lights and smoke: https://unsplash.com/photos/stage-lights-illuminating-a-dark-venue-with-blue-hues-ONYijuqr8aw
- **Copper Studio** — XT7 Core (@xt7core), Warm Audio studio microphone in a recording booth: https://unsplash.com/photos/a-microphone-and-a-microphone-stand-in-a-dark-room-cRbS1lE1xpo
- **Vinyl Gold** — Karl Hörnfeldt (@karlhornfeldt), turntable/vinyl photograph: https://unsplash.com/photos/black-and-gray-turntable-on-table-L5gqyA9NLAM

The referenced photos are marked on Unsplash as free to use under the Unsplash License.

- **Obsidian 3D** — Liana S (@cherstve_pechivo), stage lights through smoke on a dark background: https://unsplash.com/photos/stage-lights-shining-through-smoke-on-a-dark-background-Z4dBIqRR9j0
- **Crimson 3D** — Rafael Garcin (@nimbus_vulpis), band/stage under deep red lighting: https://unsplash.com/photos/a-band-playing-on-a-stage-with-red-lighting-KmVbrso2N4M

Sve photo teme učitavaju se izvan main threada i spremaju u privatni `theme_backdrops` cache. Ako fotografija nije dostupna, Sonorus prikazuje odgovarajuću tamnu theme paletu bez blokiranja audio reprodukcije.
