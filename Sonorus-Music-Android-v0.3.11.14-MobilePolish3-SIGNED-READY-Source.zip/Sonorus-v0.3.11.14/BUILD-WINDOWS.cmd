@echo off
call "%~dp0BUILD-UPDATE-DEBUG.cmd"
