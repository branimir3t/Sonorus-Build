@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ================================================
echo   SONORUS v0.3.11.13 MOBILE POLISH 2 - SIGNED RELEASE APK
echo ================================================
echo.

if not exist "keystore.properties" (
  echo GRESKA: Nedostaje keystore.properties
  echo.
  echo 1. Kopiraj keystore.properties.example u keystore.properties
  echo 2. Upisi putanju do ISTOG .jks/.keystore kljuca koji je potpisao postojecu aplikaciju
  echo 3. Upisi storePassword, keyAlias i keyPassword
  echo.
  pause
  exit /b 1
)

if not defined ANDROID_HOME (
  if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
)
if not defined ANDROID_SDK_ROOT set "ANDROID_SDK_ROOT=%ANDROID_HOME%"

if not defined ANDROID_HOME (
  echo GRESKA: Android SDK nije pronaden.
  pause
  exit /b 1
)

call gradlew.bat --no-daemon clean assembleRelease
if errorlevel 1 (
  echo.
  echo RELEASE BUILD NIJE USPIO.
  pause
  exit /b 1
)

set "APK=app\build\outputs\apk\release\app-release.apk"
set "OUT=Sonorus-v0.3.11.13-MobilePolish2-signed-release.apk"
if not exist "%APK%" (
  echo GRESKA: Release APK nije pronaden nakon builda.
  pause
  exit /b 1
)

set "APKSIGNER="
for /f "delims=" %%F in ('dir /b /s "%ANDROID_HOME%\build-tools\*\apksigner.bat" 2^>nul ^| sort /r') do (
  if not defined APKSIGNER set "APKSIGNER=%%F"
)

if not defined APKSIGNER (
  echo GRESKA: apksigner.bat nije pronaden u Android SDK Build-Tools.
  pause
  exit /b 1
)

call "!APKSIGNER!" verify --verbose --print-certs "%APK%"
if errorlevel 1 (
  echo.
  echo GRESKA: APK je izgraden, ali provjera potpisa nije prosla.
  pause
  exit /b 1
)

copy /y "%APK%" "%OUT%" >nul

echo.
echo USPJEH: %OUT%
echo Potpis je provjeren s apksignerom.
echo.
echo Ako Android javi da aplikacija nije kompatibilna za update,
echo razlog je gotovo sigurno da instalirana aplikacija koristi drugi signing key.
echo.
pause
