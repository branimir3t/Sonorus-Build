SONORUS v0.3.11.13 MOBILE POLISH 2 - SIGNED READY
=======================================

Ovaj projekt NE sadrzi tvoj privatni signing key niti lozinke.
applicationId ostaje: com.brane.sonora
versionCode: 34

KOJU OPCIJU KORISTITI?
----------------------

A) Ako je postojeci Sonorus na uredaj instaliran preko Android Studio Run/debug
   na OVOM istom Windows korisnickom racunu:

   Pokreni:
      BUILD-UPDATE-DEBUG.cmd

   Dobit ces:
      Sonorus-v0.3.11.13-MobilePolish2-update-debug.apk

   Android Studio koristi standardni debug key iz:
      %USERPROFILE%\.android\debug.keystore


B) Ako je postojeci Sonorus release APK potpisan vlastitim .jks/.keystore kljucem:

   1. Pronadi ISTI key kojim je potpisan postojeci APK.
   2. Kopiraj:
         keystore.properties.example
      u:
         keystore.properties
   3. U keystore.properties upisi:
         storeFile=C:/putanja/do/tvog/kljuca.jks
         storePassword=...
         keyAlias=...
         keyPassword=...

      Na Windowsu koristi / u putanji da izbjegnes escape probleme.

   4. Pokreni:
         BUILD-SIGNED-RELEASE.cmd

   Dobit ces:
         Sonorus-v0.3.11.13-MobilePolish2-signed-release.apk

   Skripta nakon builda automatski provjerava potpis s apksignerom.


VAZNO
-----
- Novi APK moze azurirati postojecu instalaciju SAMO ako je potpisan ISTIM kljucem.
- Nemoj stvarati novi key ako zelis sacuvati postojecu instalaciju i podatke.
- keystore.properties, *.jks i *.keystore su u .gitignore i ne ulaze u projektni ZIP.
- Ako nemas stari release key, ne postoji siguran nacin da drugim kljucem potpisani APK
  zamijeni postojecu aplikaciju bez deinstalacije.

ANDROID STUDIO GUI
------------------
Ako zelis koristiti Android Studio umjesto .cmd skripte:
Build > Generate Signed App Bundle or APK > APK > odaberi POSTOJECI key > release.
Android Studio moze proslijediti signing podatke direktno Gradleu; keystore.properties tada nije obavezan.
