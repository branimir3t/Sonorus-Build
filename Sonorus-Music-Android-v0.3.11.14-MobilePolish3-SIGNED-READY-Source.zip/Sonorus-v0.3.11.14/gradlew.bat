@echo off
setlocal EnableExtensions
set "GRADLE_VERSION=8.9"
set "ROOT=%~dp0"
set "DIST=%ROOT%.gradle-local\gradle-%GRADLE_VERSION%"
set "ZIP=%ROOT%.gradle-local\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%DIST%\bin\gradle.bat" (
  echo [Sonorus] Gradle %GRADLE_VERSION% nije pronaden. Preuzimam sluzbenu distribuciju...
  if not exist "%ROOT%.gradle-local" mkdir "%ROOT%.gradle-local"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%ROOT%.gradle-local' -Force"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
