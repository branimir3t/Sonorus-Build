# Sonorus v0.3.11.8 Photographic Vinyl

Aktivna baza: v0.3.11.7 + high-fidelity vizualni redizajn isključivo full-screen `Što svira` ekrana. Lijeva zona koristi fotografsku hi-fi gramofonsku scenu, dinamički cover i rotirajuću labelu ploče; desni PLAYER ostaje kompaktan, a lyrics panel je dominantniji i scrollable. Playback, catalog preview, radio, queue i trajna spremišta ostaju nepromijenjeni.

Isporuka je source ZIP only; APK/Gradle build se u ovom okruženju ne pokreće.

# Sonorus v0.3.11.7 Vinyl Lounge

Aktivna baza: v0.3.11.6 + vizualni redizajn isključivo full-screen `Što svira` ekrana. Gramofon je sada perspektivni, uzemljeni hi-fi objekt s realnijom vinilnom pločom (~33 1/3 RPM), animiranom ručkom i integriranim coverom. Desni PLAYER panel je kompaktniji, a tekst pjesme ima veći unutarnji scroll panel. Playback izvori, queue, radio i trajna spremišta ostaju isti.

Isporuka ove faze je source ZIP; u ovom okruženju se APK build namjerno ne pokreće.

# Sonorus v0.3.11 Catalog Preview

Status: source release s odvojenim katalog preview playbackom, bez mutacije PLAYER queuea. Upgrade identitet i trajni podaci ostaju kompatibilni.

# Sonorus v0.3.10 Mobile Player Compact

Aktivna razvojna verzija za nastupe. Fokus ove faze: pouzdan Old School Radio metadata prikaz, profesionalniji PLAYER drag/drop, snažnija ali sigurna normalizacija te lakša animirana Vinyl Gold tema.

- Old School Radio metadata parser podržava JSON objekt, JSON niz, ugniježđene vrijednosti i plain-text fallback; nevaljan refresh ne briše zadnju dobru pjesmu.
- PLAYER drag koristi cijeli red kao drag-shadow, bez dodatnih insertion crta; target se diskretno označava, a autoscroll je mirniji.
- Ujednačavanje glasnoće koristi novi profil oko -12 dB RMS sa ~-1 dB peak headroomom i do 12 dB analyzer-approved boosta; stari loudness cache se ne koristi.
- Vinyl Gold koristi sans-serif premium tipografiju i sporu vinyl animaciju ograničenu na oko 20 fps kako UI ne bi nepotrebno opterećivao reprodukciju.
- Package `com.brane.sonora` i postojeći persistent storeovi ostaju nepromijenjeni.

Build napomena: ciljani regresijski testovi i statičke provjere prolaze. Puni Gradle build je ponovno pokušan, ali ovo izvršno okruženje nema lokalni Gradle 8.9/Android SDK, a DNS prema `services.gradle.org` je blokiran.

# Sonorus v0.3.3 Catalog Card Polish

## v0.3.3 ciljane dorade
- Kataloške kartice: kompaktniji razmaci, manji artwork, manji/autosize naslov i izvođač.
- Kataloške kartice: samo trajanje pjesme; format/bitrate su uklonjeni iz ovog prikaza.
- Kataloške kartice: srce i + su približeni; katalog više nema `≡` ručku za preslagivanje.
- Ručno preslagivanje pjesama ostaje u PLAYERU.
- Now Playing naslov ima više prostora; dugi nazivi koriste 2 retka i autosize 13–18sp.
- Tehnički red je manji, jednoredan i bez velikog chipa.
- Playback kontrole + visualizer su kompaktnije, progress/seek ostaje ispod kontrola.
- Old School Radio kartica je 184dp; uklonjen je divider i usko zaglavlje više ne reže tekst u bijele artefakte.

Baza: v0.2.9 RadioFlowFix.

Glavne izmjene:
- četiri kompletne vizualne teme: Sonorus Original + Midnight Stage + Copper Studio + Vinyl Gold;
- tema se bira u Postavkama i pamti između pokretanja;
- svaka tema mijenja globalnu paletu, tipografiju, premium 3D površine/kartice, aktivna stanja i fotografsku pozadinu;
- katalog: brzi dvostruki dodir na pjesmu odmah pokreće reprodukciju;
- tablet Old School Radio kartica je viša i presložena tako da Trenutno svira ima punu širinu;
- radio metadata stanje se ponovno šalje UI-ju i nakon reconnecta/rotacije;
- Android Auto: MediaBrowserService + MediaSession browse stablo, lokalna glazba, Old School Radio, Play/Pause/Stop, Previous/Next, queue i Play from search/media id;
- radio i lokalna glazba ostaju međusobno isključivi;
- postojeći foreground playback, wake lock, audio focus i background reprodukcija ostaju sačuvani.

Napomena QA: XML i resource reference su statički provjereni. Puni Android build nije izvršen u ovom okruženju jer Gradle distribucija/Android SDK nisu lokalno dostupni, a mrežni download Gradlea nije dostupan.

## v0.3.4 Player Compact
PLAYER queue kartice i tipografija dodatno su kompaktirani radi većeg broja vidljivih pjesama, uz očuvanu čitljivost i postojeći drag & drop.



[v0.3.5] Player drag indicator polish, active queue styling refresh, compact catalog card polish, and redesigned tablet Old School Radio card.


## v0.3.6 UI Final Polish
- Tablet Old School Radio: premium centered layout, autosizing title/artist metadata and robust separator parsing.
- Now Playing: more width for long titles, smaller artwork/controls, preserved seek bar and technical data.
- Player: single overlay drag insertion line (no panel recolor, no duplicate/flicker), active track uses dark gradient + accent title without orange outline.
- Catalog: tighter grid spacing and title/artist typography matched to Player.

## v0.3.7 Radio + Catalog Polish
- Tablet radio dodatno optimiziran za lijevi stupac; donji brand logo uklonjen.
- Katalog spacing: 2dp × 2dp.
- PLAYER ima samo jednu drag insertion liniju i nema outline aktivne/odabrane pjesme.
- Tap izvan kataloške/PLAYER kartice uklanja prolaznu selekciju bez diranja reprodukcije.
- Nadogradnja zadržava isti `com.brane.sonora` applicationId i iste trajne storage namespaceove; nema migracije koja briše korisničke podatke.
- XML/resursi i Java syntax smoke statički provjereni. Puni Gradle build u ovom okruženju nije izvršen jer Android SDK/Gradle distribucija nisu lokalno dostupni, a mrežni download je blokiran.



## Mobile PLAYER compact controls
- Padajuća tražilica u zaglavlju uz Spremi/Očisti.
- Mini Prev / Play-Pause / Stop / Next kontrole.
- Zaseban tanki seek bar s vremenima.
- Donji info-red 36dp i centriran.
