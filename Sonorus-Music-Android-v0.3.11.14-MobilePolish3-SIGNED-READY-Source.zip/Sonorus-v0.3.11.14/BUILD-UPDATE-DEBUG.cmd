@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ================================================
echo   SONORUS v0.3.11.13 MOBILE POLISH 2 - DEBUG UPDATE APK
echo ================================================
echo.
echo Use this ONLY if the currently installed Sonorus was installed
 echo from Android Studio Run/debug on this same Windows user account.
echo.

if not defined ANDROID_HOME (
  if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
)
if not defined ANDROID_SDK_ROOT set "ANDROID_SDK_ROOT=%ANDROID_HOME%"

if not defined ANDROID_HOME (
  echo GRESKA: Android SDK nije pronaden.
  pause
  exit /b 1
)

call gradlew.bat --no-daemon clean assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD NIJE USPIO.
  pause
  exit /b 1
)

set "APK=app\build\outputs\apk\debug\app-debug.apk"
set "OUT=Sonorus-v0.3.11.13-MobilePolish2-update-debug.apk"
if not exist "%APK%" (
  echo GRESKA: APK nije pronaden nakon builda.
  pause
  exit /b 1
)
copy /y "%APK%" "%OUT%" >nul

echo.
echo USPJEH: %OUT%
echo APK je potpisan standardnim Android Studio debug kljucem.
echo.
pause
