# Sonorus v0.2.2 Alpha - no custom shrinking rules yet.
