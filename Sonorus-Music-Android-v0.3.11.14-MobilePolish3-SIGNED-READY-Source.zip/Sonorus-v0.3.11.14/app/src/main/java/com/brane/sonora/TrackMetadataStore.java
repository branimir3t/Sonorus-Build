package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

public final class TrackMetadataStore {
    private static final String PREFS = "sonorus_track_overrides";

    private TrackMetadataStore() {}

    public static Track apply(Context context, Track track) {
        if (context == null || track == null) return track;
        try {
            String raw = prefs(context).getString("track:" + track.id, null);
            if (raw == null || raw.isEmpty()) return track;
            JSONObject o = new JSONObject(raw);
            return new Track(
                    track.id,
                    pick(o.optString("title"), track.title),
                    pick(o.optString("artist"), track.artist),
                    pick(o.optString("album"), track.album),
                    track.albumId,
                    track.durationMs,
                    track.dateAddedSec,
                    track.relativePath,
                    track.uri,
                    track.sizeBytes,
                    track.mimeType,
                    o.optInt("year", track.year)
            );
        } catch (Exception ignored) { return track; }
    }

    public static void save(Context context, Track base, String title, String artist, String album, int year) {
        if (context == null || base == null) return;
        try {
            JSONObject o = new JSONObject();
            o.put("title", safe(title, base.title));
            o.put("artist", safe(artist, base.artist));
            o.put("album", safe(album, base.album));
            o.put("year", Math.max(0, year));
            prefs(context).edit().putString("track:" + base.id, o.toString()).apply();
        } catch (Exception ignored) {}
    }

    private static String safe(String value, String fallback) {
        if (value == null) return fallback == null ? "" : fallback;
        String s = value.trim();
        if (s.isEmpty()) return fallback == null ? "" : fallback;
        return s;
    }

    private static String pick(String value, String fallback) {
        if (value == null || value.trim().isEmpty()) return fallback;
        return value.trim();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
