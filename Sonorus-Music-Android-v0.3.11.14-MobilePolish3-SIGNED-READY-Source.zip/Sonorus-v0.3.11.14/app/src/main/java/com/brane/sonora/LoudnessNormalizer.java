package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.Looper;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lagana lokalna analiza glasnoće. Analizira nekoliko kratkih PCM prozora kroz
 * pjesmu, procjenjuje RMS/peak i računa siguran gain. Originalna datoteka se ne mijenja.
 */
public final class LoudnessNormalizer {
    public interface Callback { void onResult(Track track, Result result); }

    public static final class Result {
        public final float measuredRmsDb;
        public final float peak;
        public final float gainDb;
        public final float gainLinear;

        Result(float measuredRmsDb, float peak, float gainDb, float gainLinear) {
            this.measuredRmsDb = measuredRmsDb;
            this.peak = peak;
            this.gainDb = gainDb;
            this.gainLinear = gainLinear;
        }
    }

    private static final float TARGET_RMS_DB = -12.0f;
    private static final float MAX_BOOST_DB = 12.0f;
    private static final float MAX_CUT_DB = -6.0f;
    private static final long WINDOW_US = 2_800_000L;

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final SharedPreferences cache;
    private final Map<Long, Result> memory = new ConcurrentHashMap<>();

    public LoudnessNormalizer(Context context) {
        this.context = context.getApplicationContext();
        this.cache = this.context.getSharedPreferences("sonorus_loudness_cache_v2", Context.MODE_PRIVATE);
    }

    public void analyze(Track track, Callback cb) {
        if (track == null || cb == null) return;
        Result hit = memory.get(track.id);
        if (hit == null) hit = readCache(track);
        if (hit != null) {
            Result out = hit;
            memory.put(track.id, hit);
            main.post(() -> cb.onResult(track, out));
            return;
        }
        executor.execute(() -> {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); } catch (Exception ignored) {}
            Result r = analyzeBlocking(track);
            if (r == null) r = new Result(-12f, 0.9f, 0f, 1f);
            memory.put(track.id, r);
            saveCache(track, r);
            Result out = r;
            main.post(() -> cb.onResult(track, out));
        });
    }

    private Result analyzeBlocking(Track track) {
        long durationUs = Math.max(1_000_000L, track.durationMs * 1000L);
        double power = 0.0;
        long samples = 0L;
        float peak = 0f;

        float[] points = {0.10f, 0.30f, 0.52f, 0.74f, 0.90f};
        for (float point : points) {
            long center = (long)(durationUs * point);
            long start = Math.max(0L, Math.min(durationUs - 200_000L, center - WINDOW_US / 2L));
            long end = Math.min(durationUs, start + WINDOW_US);
            Stats s = decodeStats(track, start, end);
            if (s == null || s.samples <= 0) continue;
            power += s.powerSum;
            samples += s.samples;
            peak = Math.max(peak, s.peak);
        }
        if (samples <= 0L) return null;

        float rms = (float)Math.sqrt(power / samples);
        if (!Float.isFinite(rms) || rms < 0.00001f) return new Result(-60f, peak, 0f, 1f);
        float rmsDb = (float)(20.0 * Math.log10(rms));
        float desiredDb = TARGET_RMS_DB - rmsDb;
        desiredDb = Math.max(MAX_CUT_DB, Math.min(MAX_BOOST_DB, desiredDb));

        if (peak > 0.0001f) {
            // About -1 dBTP headroom for a stronger but safe live-playback output.
            float safePeak = 0.891f;
            float headroomDb = (float)(20.0 * Math.log10(safePeak / peak));
            desiredDb = Math.min(desiredDb, Math.max(MAX_CUT_DB, headroomDb));
        }
        float linear = (float)Math.pow(10.0, desiredDb / 20.0);
        return new Result(rmsDb, peak, desiredDb, linear);
    }

    private static final class Stats {
        double powerSum;
        long samples;
        float peak;
    }

    private Stats decodeStats(Track track, long startUs, long endUs) {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(context, track.uri, null);
            int audioIx = -1;
            MediaFormat format = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { audioIx = i; format = f; break; }
            }
            if (audioIx < 0 || format == null) return null;
            ex.selectTrack(audioIx);
            if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime == null) return null;
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(format, null, null, 0);
            codec.start();

            int pcmEncoding = AudioFormat.ENCODING_PCM_16BIT;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false, outputDone = false;
            int guard = 0;
            Stats total = new Stats();

            while (!outputDone && guard++ < 12000) {
                if (!inputDone) {
                    int inIx = codec.dequeueInputBuffer(7000);
                    if (inIx >= 0) {
                        ByteBuffer in = codec.getInputBuffer(inIx);
                        if (in != null) {
                            int size = ex.readSampleData(in, 0);
                            long pts = ex.getSampleTime();
                            if (size < 0 || pts < 0 || pts > endUs) {
                                codec.queueInputBuffer(inIx, 0, 0, Math.max(0, pts), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputDone = true;
                            } else {
                                codec.queueInputBuffer(inIx, 0, size, pts, 0);
                                ex.advance();
                            }
                        }
                    }
                }

                int outIx = codec.dequeueOutputBuffer(info, 7000);
                if (outIx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = of.getInteger(MediaFormat.KEY_PCM_ENCODING);
                } else if (outIx >= 0) {
                    ByteBuffer b = codec.getOutputBuffer(outIx);
                    if (b != null && info.size > 0 && info.presentationTimeUs >= startUs && info.presentationTimeUs <= endUs) {
                        b.position(info.offset);
                        b.limit(info.offset + info.size);
                        accumulate(total, b.slice().order(ByteOrder.LITTLE_ENDIAN), pcmEncoding);
                    }
                    outputDone = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || info.presentationTimeUs > endUs;
                    codec.releaseOutputBuffer(outIx, false);
                }
            }
            return total.samples > 0 ? total : null;
        } catch (Exception ignored) {
            return null;
        } finally {
            try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception ignored) {}
            try { ex.release(); } catch (Exception ignored) {}
        }
    }

    private void accumulate(Stats s, ByteBuffer b, int encoding) {
        if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
            while (b.remaining() >= 4) {
                float v = b.getFloat();
                if (!Float.isFinite(v)) continue;
                v = Math.max(-1f, Math.min(1f, v));
                s.powerSum += v * v; s.samples++; s.peak = Math.max(s.peak, Math.abs(v));
            }
        } else if (encoding == AudioFormat.ENCODING_PCM_8BIT) {
            while (b.remaining() >= 1) {
                float v = ((b.get() & 0xFF) - 128) / 128f;
                s.powerSum += v * v; s.samples++; s.peak = Math.max(s.peak, Math.abs(v));
            }
        } else {
            while (b.remaining() >= 2) {
                float v = b.getShort() / 32768f;
                s.powerSum += v * v; s.samples++; s.peak = Math.max(s.peak, Math.abs(v));
            }
        }
    }

    private void saveCache(Track t, Result r) {
        cache.edit().putString("l:" + t.id,
                t.durationMs + "," + r.measuredRmsDb + "," + r.peak + "," + r.gainDb + "," + r.gainLinear).apply();
    }

    private Result readCache(Track t) {
        try {
            String raw = cache.getString("l:" + t.id, null);
            if (raw == null) return null;
            String[] p = raw.split(",");
            if (p.length != 5 || Long.parseLong(p[0]) != t.durationMs) return null;
            return new Result(Float.parseFloat(p[1]), Float.parseFloat(p[2]), Float.parseFloat(p[3]), Float.parseFloat(p[4]));
        } catch (Exception ignored) { return null; }
    }

    public void shutdown() { executor.shutdownNow(); }
}
