package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class OnlineMetadataRepository {
    public interface Callback { void onResult(Track track, Metadata metadata); }

    public static final class Metadata {
        public final String title, artist, album, genre, year, artworkUrl, artistImageUrl;
        Metadata(String title, String artist, String album, String genre, String year, String artworkUrl, String artistImageUrl) {
            this.title = clean(title); this.artist = clean(artist); this.album = clean(album);
            this.genre = clean(genre); this.year = clean(year); this.artworkUrl = clean(artworkUrl); this.artistImageUrl = clean(artistImageUrl);
        }
        private static String clean(String s) { return s == null ? "" : s.trim(); }
        public boolean hasUsefulData() { return !title.isEmpty() || !artist.isEmpty() || !album.isEmpty() || !artworkUrl.isEmpty(); }
    }

    private static volatile OnlineMetadataRepository instance;
    public static OnlineMetadataRepository get(Context c) {
        if (instance == null) synchronized (OnlineMetadataRepository.class) {
            if (instance == null) instance = new OnlineMetadataRepository(c.getApplicationContext());
        }
        return instance;
    }

    private final Context context;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final SharedPreferences cache;
    private final Map<Long, Metadata> memory = new ConcurrentHashMap<>();
    private final Map<String, String> artistMemory = new ConcurrentHashMap<>();

    private OnlineMetadataRepository(Context c) {
        context = c;
        cache = c.getSharedPreferences("sonorus_online_metadata_cache_v2", Context.MODE_PRIVATE);
    }

    public void resolve(Track track, Callback cb) {
        if (track == null || cb == null || !SonorusSettings.onlineMetadata(context) || !hasReliableIdentity(track)) {
            if (cb != null) main.post(() -> cb.onResult(track, null));
            return;
        }
        Metadata hit = memory.get(track.id);
        if (hit == null) hit = readCached(track);
        if (hit != null) {
            Metadata finalHit = hit;
            memory.put(track.id, hit);
            main.post(() -> cb.onResult(track, finalHit));
            return;
        }
        if (!networkAllowed()) { main.post(() -> cb.onResult(track, null)); return; }
        executor.execute(() -> {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); } catch (Exception ignored) {}
            Metadata m = resolveBlocking(track);
            if (m != null && m.hasUsefulData()) {
                memory.put(track.id, m);
                saveCached(track, m);
            }
            main.post(() -> cb.onResult(track, m));
        });
    }

    public Metadata resolveBlocking(Track track) {
        if (track == null || !SonorusSettings.onlineMetadata(context) || !hasReliableIdentity(track)) return null;
        Metadata hit = memory.get(track.id);
        if (hit != null) return hit;
        Metadata cached = readCached(track);
        if (cached != null) { memory.put(track.id, cached); return cached; }
        if (!networkAllowed()) return null;
        try {
            String cleanTitle = normalize(track.title);
            String term = track.artist + " " + cleanTitle;
            String endpoint = "https://itunes.apple.com/search?entity=song&limit=8&term=" + enc(term);
            JSONObject root = new JSONObject(httpGet(endpoint));
            JSONArray arr = root.optJSONArray("results");
            JSONObject best = null;
            double bestScore = -1;
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o == null) continue;
                    double score = score(track, o.optString("trackName"), o.optString("artistName"));
                    if (score > bestScore) { bestScore = score; best = o; }
                }
            }
            if (best == null || !isAcceptableMatch(track, bestScore, best.optString("trackName"), best.optString("artistName"))) return null;
            String release = best.optString("releaseDate");
            String year = release.length() >= 4 ? release.substring(0, 4) : "";
            String art = best.optString("artworkUrl100");
            if (!art.isEmpty()) art = art.replace("100x100bb", "700x700bb").replace("100x100", "700x700");
            String artist = best.optString("artistName");
            String artistImage = resolveArtistImageBlocking(artist);
            Metadata m = new Metadata(
                    best.optString("trackName"), artist, best.optString("collectionName"),
                    best.optString("primaryGenreName"), year, art, artistImage);
            memory.put(track.id, m);
            saveCached(track, m);
            return m;
        } catch (Exception ignored) {
            return null;
        }
    }

    public String resolveArtistImageBlocking(String artist) {
        if (artist == null || artist.trim().isEmpty() || !SonorusSettings.onlineMetadata(context)) return "";
        String key = artist.trim().toLowerCase(Locale.ROOT);
        String hit = artistMemory.get(key);
        if (hit != null) return hit;
        String cached = cache.getString("artist:" + key, null);
        if (cached != null) { artistMemory.put(key, cached); return cached; }
        if (!networkAllowed()) return "";
        try {
            JSONObject root = new JSONObject(httpGet("https://api.deezer.com/search/artist?limit=3&q=" + enc(artist)));
            JSONArray data = root.optJSONArray("data");
            if (data != null && data.length() > 0) {
                JSONObject a = data.optJSONObject(0);
                String url = a == null ? "" : a.optString("picture_xl");
                if (url.isEmpty() && a != null) url = a.optString("picture_big");
                if (!url.isEmpty()) {
                    artistMemory.put(key, url);
                    cache.edit().putString("artist:" + key, url).apply();
                    return url;
                }
            }
        } catch (Exception ignored) {}
        cache.edit().putString("artist:" + key, "").apply();
        artistMemory.put(key, "");
        return "";
    }

    public boolean networkAllowed() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(n);
            if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false;
            if (!SonorusSettings.wifiOnly(context)) return true;
            return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET);
        } catch (Exception ignored) { return false; }
    }

    public void clearCache() {
        memory.clear(); artistMemory.clear(); cache.edit().clear().apply();
    }

    private String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(7000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Sonorus/0.2 Android Music Player");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) b.append(line);
            return b.toString();
        } finally { c.disconnect(); }
    }

    private void saveCached(Track t, Metadata m) {
        try {
            JSONObject o = new JSONObject();
            o.put("title", m.title); o.put("artist", m.artist); o.put("album", m.album); o.put("genre", m.genre);
            o.put("year", m.year); o.put("art", m.artworkUrl); o.put("artistArt", m.artistImageUrl);
            o.put("duration", t.durationMs);
            o.put("identity", identityKey(t));
            cache.edit().putString("track:" + t.id, o.toString()).apply();
        } catch (Exception ignored) {}
    }

    private Metadata readCached(Track t) {
        try {
            String s = cache.getString("track:" + t.id, null);
            if (s == null) return null;
            JSONObject o = new JSONObject(s);
            if (o.optLong("duration", t.durationMs) != t.durationMs) return null;
            if (!identityKey(t).equals(o.optString("identity"))) return null;
            return new Metadata(o.optString("title"), o.optString("artist"), o.optString("album"), o.optString("genre"),
                    o.optString("year"), o.optString("art"), o.optString("artistArt"));
        } catch (Exception ignored) { return null; }
    }

    private double score(Track local, String title, String artist) {
        double t = similarity(local.title, title);
        double a = similarity(local.artist, artist);
        if (t >= 0.995 && a >= 0.995) return 1.0;
        return t * 0.7 + a * 0.3;
    }

    private boolean isAcceptableMatch(Track local, double score, String title, String artist) {
        double titleScore = similarity(local.title, title);
        double artistScore = similarity(local.artist, artist);
        return titleScore >= 0.84 && artistScore >= 0.72 && score >= 0.80;
    }

    private double similarity(String a, String b) {
        String x = normalize(a), y = normalize(b);
        if (x.isEmpty() || y.isEmpty()) return 0;
        if (x.equals(y)) return 1;
        if (x.contains(y) || y.contains(x)) return 0.82;
        String[] xs = x.split(" "), ys = y.split(" ");
        int common = 0;
        for (String xx : xs) for (String yy : ys) if (xx.length() > 1 && xx.equals(yy)) { common++; break; }
        return (2.0 * common) / Math.max(1, xs.length + ys.length);
    }

    private String normalize(String s) {
        if (s == null) return "";
        String x = s.toLowerCase(Locale.ROOT);
        x = x.replaceAll("^[0-9]{1,3}\\s*[-._)]\\s*", "");
        x = x.replaceAll("\\[(official|lyrics?|video|audio|remastered?|hd|4k|320kbps|hq)[^\\]]*\\]", " ");
        x = x.replaceAll("\\((official|lyrics?|video|audio|remastered?|hd|4k|320kbps|hq)[^\\)]*\\)", " ");
        x = x.replaceAll("\\b(official|lyrics?|video|audio|remastered?|hd|4k|320kbps|hq|explicit|clean)\\b", " ");
        return x.replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
    }

    private boolean hasReliableIdentity(Track track) {
        if (track == null) return false;
        String title = normalize(track.title);
        String artist = normalize(track.artist);
        if (title.isEmpty() || artist.isEmpty()) return false;
        if (TrackNameParser.isUnknownArtist(track.artist)) return false;
        if (title.equals("nepoznata pjesma") || title.equals("unknown track") || title.equals("audio")) return false;
        return !title.contains("quick share") && !artist.contains("quick share");
    }

    private String identityKey(Track t) {
        return normalize(t == null ? "" : t.artist) + "|" + normalize(t == null ? "" : t.title);
    }

    private String enc(String s) {
        try { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); }
        catch (Exception e) { return ""; }
    }
}
