package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.Looper;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lagana on-device analiza početka i završetka pjesme za Smart Crossfade.
 * Ne šalje audio na internet. Dekodira kratke prozore PCM-a i mjeri stvarnu
 * energiju signala kako bi prepoznao leading/trailing tišinu i intenzitet.
 */
public final class SmartCrossfadeAnalyzer {
    public interface Callback { void onResult(Track track, Analysis analysis); }

    public static final class Analysis {
        public final long leadingSilenceMs;
        public final long trailingSilenceMs;
        public final float headEnergy;
        public final float tailEnergy;

        public Analysis(long leadingSilenceMs, long trailingSilenceMs, float headEnergy, float tailEnergy) {
            this.leadingSilenceMs = Math.max(0L, leadingSilenceMs);
            this.trailingSilenceMs = Math.max(0L, trailingSilenceMs);
            this.headEnergy = Math.max(0f, headEnergy);
            this.tailEnergy = Math.max(0f, tailEnergy);
        }
    }

    private static final long HEAD_WINDOW_US = 14_000_000L;
    private static final long TAIL_WINDOW_US = 24_000_000L;
    private static final float SILENCE_RMS = 0.018f;

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final SharedPreferences cache;
    private final Map<Long, Analysis> memory = new ConcurrentHashMap<>();

    public SmartCrossfadeAnalyzer(Context context) {
        this.context = context.getApplicationContext();
        this.cache = this.context.getSharedPreferences("sonorus_smart_crossfade_cache", Context.MODE_PRIVATE);
    }

    public void analyze(Track track, Callback cb) {
        if (track == null || cb == null) return;
        Analysis hit = memory.get(track.id);
        if (hit == null) hit = readCache(track);
        if (hit != null) {
            Analysis h = hit;
            memory.put(track.id, hit);
            main.post(() -> cb.onResult(track, h));
            return;
        }
        executor.execute(() -> {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); } catch (Exception ignored) {}
            Analysis a = analyzeBlocking(track);
            if (a != null) {
                memory.put(track.id, a);
                saveCache(track, a);
            }
            Analysis out = a == null ? new Analysis(0, 0, 0.08f, 0.08f) : a;
            main.post(() -> cb.onResult(track, out));
        });
    }

    private Analysis analyzeBlocking(Track track) {
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(context, track.uri, null);
            int audioTrack = -1;
            MediaFormat format = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    format = f;
                    break;
                }
            }
            if (audioTrack < 0 || format == null) return null;
            long durationUs = format.containsKey(MediaFormat.KEY_DURATION) ? format.getLong(MediaFormat.KEY_DURATION) : track.durationMs * 1000L;
            if (durationUs <= 0) durationUs = track.durationMs * 1000L;

            Window head = decodeWindow(track, 0L, Math.min(durationUs, HEAD_WINDOW_US));
            long tailStart = Math.max(0L, durationUs - TAIL_WINDOW_US);
            Window tail = decodeWindow(track, tailStart, durationUs);
            if (head == null && tail == null) return null;

            long leading = head == null ? 0 : detectLeadingSilence(head);
            long trailing = tail == null ? 0 : detectTrailingSilence(tail, durationUs);
            float headEnergy = head == null ? 0.08f : averageActiveEnergy(head, true);
            float tailEnergy = tail == null ? 0.08f : averageActiveEnergy(tail, false);
            return new Analysis(Math.min(7000L, leading), Math.min(7000L, trailing), headEnergy, tailEnergy);
        } catch (Exception ignored) {
            return null;
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
        }
    }

    private static final class Sample {
        final long timeUs;
        final float rms;
        Sample(long timeUs, float rms) { this.timeUs = timeUs; this.rms = rms; }
    }

    private static final class Window {
        final long startUs;
        final long endUs;
        final List<Sample> samples;
        Window(long startUs, long endUs, List<Sample> samples) { this.startUs = startUs; this.endUs = endUs; this.samples = samples; }
    }

    private Window decodeWindow(Track track, long startUs, long endUs) {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(context, track.uri, null);
            int ix = -1;
            MediaFormat format = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { ix = i; format = f; break; }
            }
            if (ix < 0 || format == null) return null;
            ex.selectTrack(ix);
            if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime == null) return null;
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(format, null, null, 0);
            codec.start();

            ArrayList<Sample> out = new ArrayList<>();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false, outputDone = false;
            int pcmEncoding = AudioFormat.ENCODING_PCM_16BIT;
            int guard = 0;
            while (!outputDone && guard++ < 10000) {
                if (!inputDone) {
                    int inIx = codec.dequeueInputBuffer(7000);
                    if (inIx >= 0) {
                        ByteBuffer in = codec.getInputBuffer(inIx);
                        if (in != null) {
                            int size = ex.readSampleData(in, 0);
                            long pts = ex.getSampleTime();
                            if (size < 0 || pts < 0 || pts > endUs) {
                                codec.queueInputBuffer(inIx, 0, 0, Math.max(0, pts), MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputDone = true;
                            } else {
                                codec.queueInputBuffer(inIx, 0, size, pts, 0);
                                ex.advance();
                            }
                        }
                    }
                }

                int outIx = codec.dequeueOutputBuffer(info, 7000);
                if (outIx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = of.getInteger(MediaFormat.KEY_PCM_ENCODING);
                } else if (outIx >= 0) {
                    ByteBuffer b = codec.getOutputBuffer(outIx);
                    if (b != null && info.size > 0 && info.presentationTimeUs >= startUs && info.presentationTimeUs <= endUs) {
                        b.position(info.offset);
                        b.limit(info.offset + info.size);
                        float rms = rms(b.slice().order(ByteOrder.LITTLE_ENDIAN), pcmEncoding);
                        out.add(new Sample(info.presentationTimeUs, rms));
                    }
                    outputDone = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || info.presentationTimeUs > endUs;
                    codec.releaseOutputBuffer(outIx, false);
                }
            }
            return new Window(startUs, endUs, out);
        } catch (Exception ignored) {
            return null;
        } finally {
            try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception ignored) {}
            try { ex.release(); } catch (Exception ignored) {}
        }
    }

    private float rms(ByteBuffer b, int encoding) {
        if (b.remaining() <= 0) return 0f;
        double sum = 0;
        int n = 0;
        if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
            while (b.remaining() >= 4) {
                float v = b.getFloat();
                if (!Float.isFinite(v)) continue;
                v = Math.max(-1f, Math.min(1f, v));
                sum += v * v; n++;
            }
        } else if (encoding == AudioFormat.ENCODING_PCM_8BIT) {
            while (b.remaining() >= 1) {
                float v = ((b.get() & 0xFF) - 128) / 128f;
                sum += v * v; n++;
            }
        } else {
            while (b.remaining() >= 2) {
                float v = b.getShort() / 32768f;
                sum += v * v; n++;
            }
        }
        return n == 0 ? 0f : (float)Math.sqrt(sum / n);
    }

    private long detectLeadingSilence(Window w) {
        if (w.samples.isEmpty()) return 0;
        int activeRun = 0;
        long firstActive = w.startUs;
        for (Sample s : w.samples) {
            if (s.rms >= SILENCE_RMS) {
                activeRun++;
                if (activeRun >= 2) { firstActive = s.timeUs; break; }
            } else activeRun = 0;
        }
        return Math.max(0L, (firstActive - w.startUs) / 1000L);
    }

    private long detectTrailingSilence(Window w, long durationUs) {
        if (w.samples.isEmpty()) return 0;
        int activeRun = 0;
        long lastActive = durationUs;
        for (int i = w.samples.size() - 1; i >= 0; i--) {
            Sample s = w.samples.get(i);
            if (s.rms >= SILENCE_RMS) {
                activeRun++;
                if (activeRun >= 2) { lastActive = s.timeUs; break; }
            } else activeRun = 0;
        }
        return Math.max(0L, (durationUs - lastActive) / 1000L);
    }

    private float averageActiveEnergy(Window w, boolean fromStart) {
        if (w.samples.isEmpty()) return 0.08f;
        double sum = 0; int n = 0;
        int limit = Math.min(18, w.samples.size());
        if (fromStart) {
            boolean active = false;
            for (Sample s : w.samples) {
                if (!active && s.rms >= SILENCE_RMS) active = true;
                if (active) { sum += s.rms; n++; if (n >= limit) break; }
            }
        } else {
            for (int i = w.samples.size() - 1; i >= 0 && n < limit; i--) {
                Sample s = w.samples.get(i);
                if (s.rms >= SILENCE_RMS) { sum += s.rms; n++; }
            }
        }
        return n == 0 ? 0.02f : (float)(sum / n);
    }

    private void saveCache(Track t, Analysis a) {
        cache.edit().putString("a:" + t.id, t.durationMs + "," + a.leadingSilenceMs + "," + a.trailingSilenceMs + "," + a.headEnergy + "," + a.tailEnergy).apply();
    }

    private Analysis readCache(Track t) {
        try {
            String s = cache.getString("a:" + t.id, null);
            if (s == null) return null;
            String[] p = s.split(",");
            if (p.length != 5 || Long.parseLong(p[0]) != t.durationMs) return null;
            return new Analysis(Long.parseLong(p[1]), Long.parseLong(p[2]), Float.parseFloat(p[3]), Float.parseFloat(p[4]));
        } catch (Exception ignored) { return null; }
    }

    public void shutdown() { executor.shutdownNow(); }
}
