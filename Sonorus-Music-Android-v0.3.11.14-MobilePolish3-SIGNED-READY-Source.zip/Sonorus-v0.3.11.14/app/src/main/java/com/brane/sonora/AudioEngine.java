package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.audiofx.LoudnessEnhancer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

public final class AudioEngine {
    public interface Listener {
        default void onQueueChanged() {}
        default void onTrackChanged(Track track, int index) {}
        default void onPlaybackChanged(boolean playing) {}
        default void onProgress(long positionMs, long durationMs) {}
        default void onModesChanged(boolean shuffle, int repeatMode, boolean crossfadeEnabled, int crossfadeSeconds, boolean fadeInOut, boolean smartCrossfade) {}
        default void onPlaybackError(String message) {}
    }

    public static final int REPEAT_OFF = 0;
    public static final int REPEAT_ALL = 1;
    public static final int REPEAT_ONE = 2;
    public static final int CROSSFADE_STANDARD = 0;
    public static final int CROSSFADE_SMART = 1;
    public static final int CROSSFADE_RADIO = 2;

    private static final String PREFS = "sonora_player";

    private final Context context;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private final ArrayList<Track> queue = new ArrayList<>();
    private final Random random = new Random();
    private final SmartCrossfadeAnalyzer smartAnalyzer;
    private final LoudnessNormalizer loudnessAnalyzer;
    private SmartCrossfadeAnalyzer.Analysis currentAnalysis;
    private SmartCrossfadeAnalyzer.Analysis nextAnalysis;
    private long activeCrossfadeDurationMs = 5000L;
    private long fadeInStartMs = 0L;
    private boolean fadeInActive = false;

    private final AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build();

    private MediaPlayer currentPlayer;
    private MediaPlayer nextPlayer;
    private int currentIndex = -1;
    private int preloadedIndex = -1;
    private int generation = 0;
    private int preloadGeneration = 0;
    private boolean currentPrepared = false;
    private boolean nextPrepared = false;
    private boolean playing = false;
    private boolean loading = false;
    private boolean released = false;
    private boolean isCrossfading = false;
    private float crossfadeProgress = 0f;
    private long lastCrossfadeTick = 0L;
    private float masterVolume = 1f;
    private float lastCurrentMixFraction = 1f;
    private float lastNextMixFraction = 0f;
    private MediaPlayer lastCompletionSource;
    private boolean shuffle;
    private int repeatMode;
    private int crossfadeSeconds;
    private boolean crossfadeEnabled;
    private boolean fadeInOut;
    private boolean smartCrossfade;
    private int crossfadeMode;
    private float transitionNextGain = 1f;
    private boolean loudnessNormalization;
    private float currentNormalizationVolume = 1f;
    private float nextNormalizationVolume = 1f;
    private LoudnessEnhancer currentLoudnessEnhancer;
    private LoudnessEnhancer nextLoudnessEnhancer;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (released) return;
            tick();
            handler.postDelayed(this, 100L);
        }
    };

    public AudioEngine(Context context) {
        this.context = context.getApplicationContext();
        SharedPreferences p = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        shuffle = p.getBoolean("shuffle", false);
        repeatMode = p.getInt("repeat", REPEAT_OFF);
        crossfadeEnabled = SonorusSettings.crossfadeEnabled(this.context);
        crossfadeSeconds = SonorusSettings.crossfadeSeconds(this.context);
        fadeInOut = SonorusSettings.fadeInOut(this.context);
        crossfadeMode = SonorusSettings.crossfadeMode(this.context);
        smartCrossfade = crossfadeMode != CROSSFADE_STANDARD;
        smartAnalyzer = new SmartCrossfadeAnalyzer(this.context);
        loudnessAnalyzer = new LoudnessNormalizer(this.context);
        loudnessNormalization = SonorusSettings.loudnessNormalization(this.context);
        handler.post(ticker);
    }

    public void addListener(Listener l) {
        if (l == null) return;
        listeners.addIfAbsent(l);
        l.onQueueChanged();
        l.onTrackChanged(getCurrentTrack(), currentIndex);
        l.onPlaybackChanged(playing);
        l.onModesChanged(shuffle, repeatMode, crossfadeEnabled, crossfadeSeconds, fadeInOut, smartCrossfade);
    }

    public void removeListener(Listener l) {
        listeners.remove(l);
    }

    public List<Track> getQueueSnapshot() {
        return new ArrayList<>(queue);
    }

    public Track getCurrentTrack() {
        if (currentIndex < 0 || currentIndex >= queue.size()) return null;
        return queue.get(currentIndex);
    }

    public int getCurrentIndex() { return currentIndex; }
    public boolean isPlaying() { return playing; }
    public boolean isShuffle() { return shuffle; }
    public int getRepeatMode() { return repeatMode; }
    public int getCrossfadeSeconds() { return crossfadeSeconds; }
    public boolean isCrossfadeEnabled() { return crossfadeEnabled; }
    public boolean isFadeInOutEnabled() { return fadeInOut; }
    public boolean isSmartCrossfadeEnabled() { return smartCrossfade; }
    public int getCrossfadeMode() { return crossfadeMode; }
    public boolean isLoudnessNormalizationEnabled() { return loudnessNormalization; }

    public long getPosition() {
        try { return currentPrepared && currentPlayer != null ? currentPlayer.getCurrentPosition() : 0L; }
        catch (Exception ignored) { return 0L; }
    }

    public long getDuration() {
        try { return currentPrepared && currentPlayer != null ? currentPlayer.getDuration() : 0L; }
        catch (Exception ignored) { return 0L; }
    }

    public void setQueue(List<Track> tracks, boolean autoplay) {
        Track oldCurrent = getCurrentTrack();
        long oldId = oldCurrent == null ? -1L : oldCurrent.id;
        queue.clear();
        if (tracks != null) queue.addAll(tracks);
        if (oldId != -1L) currentIndex = indexOfId(oldId);
        if (currentIndex >= queue.size()) currentIndex = -1;
        notifyQueueChanged();
        invalidatePreload();
        if (autoplay && !queue.isEmpty()) playIndex(0);
        else if (currentIndex == -1 && !queue.isEmpty()) notifyTrackChanged();
    }

    public void addTrack(Track track) {
        if (track == null) return;
        queue.add(track);
        notifyQueueChanged();
        refreshPreloadAfterQueueEdit();
    }

    public void addTracks(List<Track> tracks) {
        if (tracks == null || tracks.isEmpty()) return;
        queue.addAll(tracks);
        notifyQueueChanged();
        refreshPreloadAfterQueueEdit();
    }

    public void insertTrack(int index, Track track) {
        if (track == null) return;
        int safe = Math.max(0, Math.min(index, queue.size()));
        if (currentIndex >= 0 && safe <= currentIndex) currentIndex++;
        queue.add(safe, track);
        notifyQueueChanged();
        refreshPreloadAfterQueueEdit();
    }

    public void insertTracks(int index, List<Track> tracks) {
        if (tracks == null || tracks.isEmpty()) return;
        int safe = Math.max(0, Math.min(index, queue.size()));
        if (currentIndex >= 0 && safe <= currentIndex) currentIndex += tracks.size();
        queue.addAll(safe, tracks);
        notifyQueueChanged();
        refreshPreloadAfterQueueEdit();
    }

    public void removeAt(int index) {
        if (index < 0 || index >= queue.size()) return;
        boolean removingCurrent = index == currentIndex;
        queue.remove(index);
        if (queue.isEmpty()) {
            stopAndReset();
            currentIndex = -1;
            notifyQueueChanged();
            notifyTrackChanged();
            return;
        }
        if (removingCurrent) {
            // Brisanje pjesme koja trenutno svira NE smije automatski pokrenuti drugu.
            // Zaustavi samo aktivni playback, zadrži preostali red i čekaj ručni odabir.
            stopAndReset();
            currentIndex = -1;
            notifyQueueChanged();
            notifyTrackChanged();
            return;
        }
        if (index < currentIndex) currentIndex--;
        notifyQueueChanged();
        refreshPreloadAfterQueueEdit();
    }

    public void moveItem(int from, int to) {
        if (from < 0 || from >= queue.size()) return;
        int bounded = Math.max(0, Math.min(to, queue.size() - 1));
        if (from == bounded) return;
        int oldCurrentIndex = currentIndex;
        Track moved = queue.remove(from);
        queue.add(bounded, moved);
        if (oldCurrentIndex == from) currentIndex = bounded;
        else if (from < oldCurrentIndex && bounded >= oldCurrentIndex) currentIndex = oldCurrentIndex - 1;
        else if (from > oldCurrentIndex && bounded <= oldCurrentIndex) currentIndex = oldCurrentIndex + 1;
        notifyQueueChanged();
        refreshPreloadAfterQueueEdit();
    }

    public void clearQueue() {
        queue.clear();
        currentIndex = -1;
        stopAndReset();
        notifyQueueChanged();
        notifyTrackChanged();
    }

    public void refreshTrackMetadata(Track updated) {
        if (updated == null) return;
        boolean changed = false;
        for (int i = 0; i < queue.size(); i++) {
            if (queue.get(i).id == updated.id) {
                queue.set(i, updated);
                changed = true;
            }
        }
        if (changed) {
            notifyQueueChanged();
            if (getCurrentTrack() != null && getCurrentTrack().id == updated.id) notifyTrackChanged();
        }
    }

    public void playTrackNow(Track track) {
        if (track == null) return;
        int ix = indexOfId(track.id);
        if (ix < 0) {
            queue.add(track);
            ix = queue.size() - 1;
            notifyQueueChanged();
        }
        playIndex(ix);
    }

    public void playIndex(int index) {
        if (index < 0 || index >= queue.size()) return;
        lastCompletionSource = null;
        generation++;
        loading = true;
        cancelCrossfade(false);
        releaseLoudnessEnhancer(currentLoudnessEnhancer);
        currentLoudnessEnhancer = null;
        currentNormalizationVolume = 1f;
        releasePlayer(currentPlayer);
        currentPlayer = null;
        currentPrepared = false;
        invalidatePreload();
        currentIndex = index;
        notifyTrackChanged();

        final int myGeneration = generation;
        final Track track = queue.get(index);
        MediaPlayer p = createPlayer(track);
        if (p == null) {
            loading = false;
            notifyError("Pjesma se ne može otvoriti: " + track.title);
            return;
        }
        currentPlayer = p;
        p.setOnPreparedListener(mp -> {
            if (released || myGeneration != generation || mp != currentPlayer) {
                releasePlayer(mp);
                return;
            }
            currentPrepared = true;
            loading = false;
            fadeInActive = fadeInOut;
            fadeInStartMs = SystemClock.elapsedRealtime();
            prepareLoudness(mp, track, true);
            applyVolumes(fadeInActive ? 0f : 1f, 0f);
            try {
                mp.start();
                playing = true;
                notifyPlaybackChanged();
                preloadFollowing();
            } catch (Exception e) {
                notifyError("Reprodukcija nije uspjela: " + track.title);
            }
        });
        p.setOnCompletionListener(mp -> {
            if (mp != currentPlayer) return;
            if (isCrossfading) {
                // Nikad ne ostavljaj preloaded pjesmu da napreduje utišana ako je
                // stara pjesma završila prije zadnjeg crossfade ticka.
                finalizeCrossfade();
                return;
            }
            onNaturalCompletion(mp);
        });
        p.setOnErrorListener((mp, what, extra) -> {
            if (mp == currentPlayer) {
                loading = false;
                notifyError("Greška reprodukcije: " + track.title);
                playNextAfterFailure();
            }
            return true;
        });
        try { p.prepareAsync(); }
        catch (Exception e) {
            loading = false;
            notifyError("Pjesma se ne može pripremiti: " + track.title);
        }
    }

    public void togglePlayPause() {
        if (queue.isEmpty()) return;
        if (loading) return;
        if (currentPlayer == null || !currentPrepared) {
            playIndex(currentIndex >= 0 ? currentIndex : 0);
            return;
        }
        if (playing) pause(); else resume();
    }

    public void pause() {
        if (!playing) return;
        try { if (currentPlayer != null && currentPrepared && currentPlayer.isPlaying()) currentPlayer.pause(); } catch (Exception ignored) {}
        try { if (isCrossfading && nextPlayer != null && nextPrepared && nextPlayer.isPlaying()) nextPlayer.pause(); } catch (Exception ignored) {}
        playing = false;
        notifyPlaybackChanged();
    }

    public void resume() {
        if (playing || currentPlayer == null || !currentPrepared) return;
        try {
            reassertOutputMix();
            currentPlayer.start();
            if (isCrossfading && nextPlayer != null && nextPrepared) nextPlayer.start();
            playing = true;
            lastCrossfadeTick = SystemClock.elapsedRealtime();
            notifyPlaybackChanged();
        } catch (Exception ignored) {}
    }

    public void next() {
        if (queue.isEmpty()) return;
        int next = calculateNextIndex(false);
        if (next >= 0) playIndex(next);
        else {
            pause();
            seekTo(0L);
        }
    }

    public void previous() {
        if (queue.isEmpty()) return;
        if (getPosition() > 5000L) {
            seekTo(0L);
            return;
        }
        int prev;
        if (shuffle) prev = random.nextInt(queue.size());
        else if (currentIndex > 0) prev = currentIndex - 1;
        else if (repeatMode == REPEAT_ALL) prev = queue.size() - 1;
        else prev = 0;
        playIndex(prev);
    }

    public void seekTo(long positionMs) {
        if (currentPlayer == null || !currentPrepared) return;
        cancelCrossfade(true);
        try {
            long duration = currentPlayer.getDuration();
            currentPlayer.seekTo((int) Math.max(0L, Math.min(positionMs, duration)));
            fadeInActive = false;
            applyVolumes(1f, 0f);
            preloadFollowing();
        } catch (Exception ignored) {}
    }

    public void setShuffle(boolean enabled) {
        shuffle = enabled;
        persistModes();
        invalidatePreload();
        preloadFollowing();
        notifyModesChanged();
    }

    public void toggleShuffle() { setShuffle(!shuffle); }

    public void cycleRepeatMode() {
        setRepeatMode((repeatMode + 1) % 3);
    }

    public void setRepeatMode(int mode) {
        repeatMode = mode == REPEAT_ALL || mode == REPEAT_ONE ? mode : REPEAT_OFF;
        persistModes();
        invalidatePreload();
        preloadFollowing();
        notifyModesChanged();
    }

    public void setCrossfadeEnabled(boolean enabled) {
        crossfadeEnabled = enabled;
        SonorusSettings.setCrossfadeEnabled(context, enabled);
        cancelCrossfade(true);
        if (enabled && smartCrossfade) analyzeForSmartCrossfade();
        notifyModesChanged();
    }

    public void setCrossfadeSeconds(int seconds) {
        crossfadeSeconds = sanitizeCrossfade(seconds);
        SonorusSettings.setCrossfadeSeconds(context, crossfadeSeconds);
        notifyModesChanged();
    }

    public void setFadeInOutEnabled(boolean enabled) {
        fadeInOut = enabled;
        if (!enabled) { fadeInActive = false; if (!isCrossfading) applyVolumes(1f, 0f); }
        SonorusSettings.setFadeInOut(context, enabled);
        notifyModesChanged();
    }

    public void setSmartCrossfadeEnabled(boolean enabled) {
        setCrossfadeMode(enabled ? CROSSFADE_SMART : CROSSFADE_STANDARD);
    }

    public void setCrossfadeMode(int mode) {
        crossfadeMode = mode == CROSSFADE_RADIO ? CROSSFADE_RADIO : mode == CROSSFADE_SMART ? CROSSFADE_SMART : CROSSFADE_STANDARD;
        smartCrossfade = crossfadeMode != CROSSFADE_STANDARD;
        SonorusSettings.setCrossfadeMode(context, crossfadeMode);
        currentAnalysis = null;
        nextAnalysis = null;
        transitionNextGain = 1f;
        if (smartCrossfade) analyzeForSmartCrossfade();
        notifyModesChanged();
    }

    public void setMasterVolume(float volume) {
        masterVolume = Math.max(0f, Math.min(1f, volume));
        // Ne računaj miks ponovno iz stanja jer time možemo pregaziti fade/crossfade.
        // Samo ponovno primijeni zadnje stvarne omjere na MediaPlayere.
        applyVolumes(lastCurrentMixFraction, lastNextMixFraction);
    }

    /** Ponovno postavlja izlazne glasnoće bez promjene pozicije, fadea ili crossfadea. */
    public void reassertOutputMix() {
        applyVolumes(lastCurrentMixFraction, lastNextMixFraction);
    }

    /**
     * Health-check za foreground servis. Ako platforma ostavi naš logical playing=true,
     * ali MediaPlayer više stvarno ne svira, sigurno ga nastavi ili obradi prirodni kraj.
     */
    public void verifyPlaybackActive() {
        if (!playing || !currentPrepared || currentPlayer == null || isCrossfading) return;
        try {
            if (currentPlayer.isPlaying()) return;
            long pos = currentPlayer.getCurrentPosition();
            long dur = currentPlayer.getDuration();
            if (dur > 0L && pos >= Math.max(0L, dur - 350L)) {
                onNaturalCompletion(currentPlayer);
                return;
            }
            reassertOutputMix();
            currentPlayer.start();
        } catch (Exception ignored) {}
    }

    public void setLoudnessNormalizationEnabled(boolean enabled) {
        loudnessNormalization = enabled;
        SonorusSettings.setLoudnessNormalization(context, enabled);
        if (!enabled) {
            releaseLoudnessEnhancer(currentLoudnessEnhancer); currentLoudnessEnhancer = null;
            releaseLoudnessEnhancer(nextLoudnessEnhancer); nextLoudnessEnhancer = null;
            currentNormalizationVolume = 1f;
            nextNormalizationVolume = 1f;
            applyVolumes(isCrossfading ? (float)Math.cos(crossfadeProgress * Math.PI / 2.0) : 1f,
                    isCrossfading ? (float)Math.sin(crossfadeProgress * Math.PI / 2.0) * transitionNextGain : 0f);
        } else {
            Track current = getCurrentTrack();
            if (currentPrepared && currentPlayer != null && current != null) prepareLoudness(currentPlayer, current, true);
            if (nextPrepared && nextPlayer != null && preloadedIndex >= 0 && preloadedIndex < queue.size()) prepareLoudness(nextPlayer, queue.get(preloadedIndex), false);
        }
    }

    private int sanitizeCrossfade(int value) {
        return value == 10 || value == 15 ? value : 5;
    }

    private MediaPlayer createPlayer(Track track) {
        try {
            MediaPlayer p = new MediaPlayer();
            p.setAudioAttributes(audioAttributes);
            try { p.setWakeMode(context, android.os.PowerManager.PARTIAL_WAKE_LOCK); } catch (Exception ignored) {}
            p.setDataSource(context, track.uri);
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    private void preloadFollowing() {
        if (!currentPrepared || currentPlayer == null || queue.isEmpty()) return;
        int target = calculateNextIndex(true);
        if (target < 0 || target >= queue.size()) return;
        preloadGeneration++;
        final int my = preloadGeneration;
        final int targetIndex = target;
        final Track targetTrack = queue.get(targetIndex);
        currentAnalysis = null;
        nextAnalysis = null;
        if (smartCrossfade) analyzeForSmartCrossfade(targetTrack);
        releaseLoudnessEnhancer(nextLoudnessEnhancer);
        nextLoudnessEnhancer = null;
        nextNormalizationVolume = 1f;
        releasePlayer(nextPlayer);
        nextPlayer = createPlayer(targetTrack);
        preloadedIndex = targetIndex;
        nextPrepared = false;
        if (nextPlayer == null) return;
        nextPlayer.setOnPreparedListener(mp -> {
            if (released || my != preloadGeneration || mp != nextPlayer) {
                releasePlayer(mp);
                return;
            }
            nextPrepared = true;
            prepareLoudness(mp, targetTrack, false);
            try { mp.setVolume(0f, 0f); } catch (Exception ignored) {}
        });
        nextPlayer.setOnErrorListener((mp, what, extra) -> {
            if (mp == nextPlayer) {
                nextPrepared = false;
                releaseLoudnessEnhancer(nextLoudnessEnhancer); nextLoudnessEnhancer = null; nextNormalizationVolume = 1f;
                releasePlayer(nextPlayer);
                nextPlayer = null;
                preloadedIndex = -1;
            }
            return true;
        });
        try { nextPlayer.prepareAsync(); }
        catch (Exception ignored) {
            releaseLoudnessEnhancer(nextLoudnessEnhancer); nextLoudnessEnhancer = null; nextNormalizationVolume = 1f;
            releasePlayer(nextPlayer);
            nextPlayer = null;
            preloadedIndex = -1;
        }
    }

    private void analyzeForSmartCrossfade() {
        int target = calculateNextIndex(true);
        if (target >= 0 && target < queue.size()) analyzeForSmartCrossfade(queue.get(target));
    }

    private void analyzeForSmartCrossfade(Track targetTrack) {
        if (!smartCrossfade || targetTrack == null) return;
        Track currentTrack = getCurrentTrack();
        if (currentTrack != null) {
            final long id = currentTrack.id;
            smartAnalyzer.analyze(currentTrack, (t, a) -> {
                Track now = getCurrentTrack();
                if (now != null && now.id == id) currentAnalysis = a;
            });
        }
        final long nextId = targetTrack.id;
        smartAnalyzer.analyze(targetTrack, (t, a) -> {
            if (preloadedIndex >= 0 && preloadedIndex < queue.size() && queue.get(preloadedIndex).id == nextId) nextAnalysis = a;
        });
    }

    private int calculateNextIndex(boolean forPreload) {
        if (queue.isEmpty()) return -1;
        if (repeatMode == REPEAT_ONE) return currentIndex >= 0 ? currentIndex : 0;
        if (shuffle) {
            if (queue.size() == 1) return repeatMode == REPEAT_ALL ? 0 : -1;
            int candidate = currentIndex;
            for (int i = 0; i < 8 && candidate == currentIndex; i++) candidate = random.nextInt(queue.size());
            if (candidate == currentIndex) candidate = (currentIndex + 1) % queue.size();
            return candidate;
        }
        if (currentIndex + 1 < queue.size()) return currentIndex + 1;
        if (repeatMode == REPEAT_ALL) return 0;
        return -1;
    }

    private void tick() {
        if (currentPlayer == null || !currentPrepared) return;
        long pos = getPosition();
        long dur = getDuration();
        for (Listener l : listeners) l.onProgress(pos, dur);
        if (!playing) {
            lastCrossfadeTick = SystemClock.elapsedRealtime();
            return;
        }

        // Sigurnosni watchdog: neki uređaji/codecovi u pozadini mogu propustiti
        // MediaPlayer onCompletion callback. Ako je player došao do kraja i više
        // stvarno ne svira, ručno pokreni isti put za sljedeću pjesmu.
        if (!isCrossfading && dur > 0L && pos >= Math.max(0L, dur - 350L)) {
            boolean actuallyPlaying = true;
            try { actuallyPlaying = currentPlayer.isPlaying(); } catch (Exception ignored) {}
            if (!actuallyPlaying) {
                onNaturalCompletion(currentPlayer);
                return;
            }
        }

        if (isCrossfading) {
            long now = SystemClock.elapsedRealtime();
            long dt = Math.max(0L, now - lastCrossfadeTick);
            lastCrossfadeTick = now;
            float denom = Math.max(500f, activeCrossfadeDurationMs);
            crossfadeProgress = Math.min(1f, crossfadeProgress + dt / denom);
            float currentV = (float)Math.cos(crossfadeProgress * Math.PI / 2.0);
            float nextV = (float)Math.sin(crossfadeProgress * Math.PI / 2.0);
            applyVolumes(currentV, nextV * transitionNextGain);
            if (crossfadeProgress >= 1f) finalizeCrossfade();
            return;
        }

        if (fadeInActive) {
            float fp = Math.min(1f, (SystemClock.elapsedRealtime() - fadeInStartMs) / 800f);
            applyVolumes((float)Math.sin(fp * Math.PI / 2.0), 0f);
            if (fp >= 1f) fadeInActive = false;
        }

        if (crossfadeEnabled && nextPrepared && nextPlayer != null && dur > 0L) {
            long cf = effectiveCrossfadeDurationMs();
            long silenceAdvance = smartCrossfade && currentAnalysis != null ? Math.min(crossfadeMode == CROSSFADE_RADIO ? 8000L : 5000L, currentAnalysis.trailingSilenceMs) : 0L;
            long threshold = Math.min(cf + silenceAdvance, Math.max(1000L, dur / 2L));
            if (dur - pos <= threshold) beginCrossfade();
        } else if (fadeInOut && !crossfadeEnabled && dur > 0L && dur - pos < 900L) {
            float f = Math.max(0f, Math.min(1f, (dur - pos) / 900f));
            applyVolumes((float)Math.sin(f * Math.PI / 2.0), 0f);
        }
    }

    private long effectiveCrossfadeDurationMs() {
        long base = crossfadeSeconds * 1000L;
        if (!smartCrossfade || currentAnalysis == null || nextAnalysis == null) return base;
        float tail = currentAnalysis.tailEnergy;
        float head = nextAnalysis.headEnergy;
        float factor = 1f;
        if (currentAnalysis.trailingSilenceMs > 1200L || tail < 0.025f) factor *= 0.68f;
        else if (tail > 0.12f && head > 0.12f) factor *= crossfadeMode == CROSSFADE_RADIO ? 1.08f : 1.0f;
        else factor *= crossfadeMode == CROSSFADE_RADIO ? 0.92f : 0.84f;
        if (head > 0.24f && tail < 0.05f) factor *= 0.82f;
        long value = (long)(base * factor);
        long max = crossfadeMode == CROSSFADE_RADIO ? Math.min(18000L, base + 2500L) : base;
        return Math.max(2800L, Math.min(max, value));
    }

    private float calculateTransitionGain() {
        if (!smartCrossfade || currentAnalysis == null || nextAnalysis == null) return 1f;
        float tail = Math.max(0.025f, currentAnalysis.tailEnergy);
        float head = Math.max(0.025f, nextAnalysis.headEnergy);
        float gain = (float)Math.sqrt(tail / head);
        float min = crossfadeMode == CROSSFADE_RADIO ? 0.72f : 0.80f;
        float max = crossfadeMode == CROSSFADE_RADIO ? 1.18f : 1.10f;
        return Math.max(min, Math.min(max, gain));
    }

    private void beginCrossfade() {
        if (isCrossfading || nextPlayer == null || !nextPrepared || preloadedIndex < 0) return;
        isCrossfading = true;
        crossfadeProgress = 0f;
        activeCrossfadeDurationMs = effectiveCrossfadeDurationMs();
        transitionNextGain = calculateTransitionGain();
        lastCrossfadeTick = SystemClock.elapsedRealtime();
        try {
            long maxLeadSkip = crossfadeMode == CROSSFADE_RADIO ? 8000L : 5000L;
            long offset = smartCrossfade && nextAnalysis != null ? Math.min(maxLeadSkip, nextAnalysis.leadingSilenceMs) : 0L;
            nextPlayer.seekTo((int) offset);
            nextPlayer.setVolume(0f, 0f);
            nextPlayer.start();
        } catch (Exception e) {
            isCrossfading = false;
            transitionNextGain = 1f;
            return;
        }
    }

    private void finalizeCrossfade() {
        if (!isCrossfading || nextPlayer == null) return;
        MediaPlayer old = currentPlayer;
        LoudnessEnhancer oldEnhancer = currentLoudnessEnhancer;
        currentPlayer = nextPlayer;
        currentPrepared = nextPrepared;
        currentIndex = preloadedIndex;
        currentLoudnessEnhancer = nextLoudnessEnhancer;
        currentNormalizationVolume = nextNormalizationVolume;
        nextLoudnessEnhancer = null;
        nextNormalizationVolume = 1f;
        nextPlayer = null;
        nextPrepared = false;
        preloadedIndex = -1;
        isCrossfading = false;
        crossfadeProgress = 0f;
        transitionNextGain = 1f;
        fadeInActive = false;
        lastCompletionSource = null;
        if (loudnessNormalization && currentLoudnessEnhancer == null && currentPlayer != null && getCurrentTrack() != null) prepareLoudness(currentPlayer, getCurrentTrack(), true);
        applyVolumes(1f, 0f);
        releaseLoudnessEnhancer(oldEnhancer);
        releasePlayer(old);
        attachCurrentCallbacks();
        notifyTrackChanged();
        notifyPlaybackChanged();
        preloadFollowing();
    }

    private void attachCurrentCallbacks() {
        final MediaPlayer p = currentPlayer;
        final Track track = getCurrentTrack();
        if (p == null || track == null) return;
        p.setOnCompletionListener(mp -> {
            if (mp != currentPlayer) return;
            if (isCrossfading) {
                finalizeCrossfade();
                return;
            }
            onNaturalCompletion(mp);
        });
        p.setOnErrorListener((mp, what, extra) -> {
            if (mp == currentPlayer) {
                notifyError("Greška reprodukcije: " + track.title);
                playNextAfterFailure();
            }
            return true;
        });
    }

    private void onNaturalCompletion(MediaPlayer source) {
        if (source == null || source != currentPlayer || source == lastCompletionSource || isCrossfading) return;
        lastCompletionSource = source;
        if (repeatMode == REPEAT_ONE && preloadedIndex == currentIndex && nextPrepared) {
            swapToPreloadedAndStart();
            return;
        }
        int next = calculateNextIndex(false);
        if (next < 0) {
            playing = false;
            try { currentPlayer.seekTo(0); } catch (Exception ignored) {}
            notifyPlaybackChanged();
            return;
        }
        if (nextPrepared && nextPlayer != null && preloadedIndex == next) swapToPreloadedAndStart();
        else playIndex(next);
    }

    private void swapToPreloadedAndStart() {
        if (nextPlayer == null || !nextPrepared || preloadedIndex < 0) return;
        final int targetIndex = preloadedIndex;
        final int oldIndex = currentIndex;
        final MediaPlayer old = currentPlayer;
        final LoudnessEnhancer oldEnhancer = currentLoudnessEnhancer;
        final float oldNormalization = currentNormalizationVolume;
        final MediaPlayer candidate = nextPlayer;
        final LoudnessEnhancer candidateEnhancer = nextLoudnessEnhancer;
        final float candidateNormalization = nextNormalizationVolume;

        currentPlayer = candidate;
        currentPrepared = true;
        currentIndex = targetIndex;
        currentLoudnessEnhancer = candidateEnhancer;
        currentNormalizationVolume = candidateNormalization;
        nextLoudnessEnhancer = null;
        nextNormalizationVolume = 1f;
        nextPlayer = null;
        nextPrepared = false;
        preloadedIndex = -1;
        lastCompletionSource = null;

        if (loudnessNormalization && currentLoudnessEnhancer == null && getCurrentTrack() != null) {
            prepareLoudness(currentPlayer, getCurrentTrack(), true);
        }

        boolean started = false;
        try {
            fadeInActive = fadeInOut;
            fadeInStartMs = SystemClock.elapsedRealtime();
            applyVolumes(fadeInActive ? 0f : 1f, 0f);
            if (!currentPlayer.isPlaying()) currentPlayer.start();
            started = true;
            playing = true;
        } catch (Exception ignored) {
            started = false;
        }

        if (!started) {
            // Ako preloaded MediaPlayer zakaže baš na prijelazu, ne ostavljamo engine
            // u lažnom "playing" stanju bez zvuka. Vratimo stari slot i otvorimo
            // sljedeću pjesmu normalnim putem.
            releaseLoudnessEnhancer(currentLoudnessEnhancer);
            releasePlayer(currentPlayer);
            currentPlayer = old;
            currentPrepared = old != null;
            currentIndex = oldIndex;
            currentLoudnessEnhancer = oldEnhancer;
            currentNormalizationVolume = oldNormalization;
            playing = false;
            playIndex(targetIndex);
            return;
        }

        releaseLoudnessEnhancer(oldEnhancer);
        releasePlayer(old);
        attachCurrentCallbacks();
        notifyTrackChanged();
        notifyPlaybackChanged();
        preloadFollowing();
    }

    private void playNextAfterFailure() {
        int next = calculateNextIndex(false);
        if (next >= 0 && next != currentIndex) playIndex(next);
        else {
            playing = false;
            notifyPlaybackChanged();
        }
    }

    private void cancelCrossfade(boolean keepCurrent) {
        if (!isCrossfading) return;
        if (keepCurrent) {
            try { if (nextPlayer != null && nextPlayer.isPlaying()) nextPlayer.pause(); } catch (Exception ignored) {}
            releaseLoudnessEnhancer(nextLoudnessEnhancer); nextLoudnessEnhancer = null; nextNormalizationVolume = 1f;
            releasePlayer(nextPlayer);
            nextPlayer = null;
            nextPrepared = false;
            preloadedIndex = -1;
            isCrossfading = false;
            crossfadeProgress = 0f;
            transitionNextGain = 1f;
            applyVolumes(1f, 0f);
        } else {
            isCrossfading = false;
            crossfadeProgress = 0f;
            transitionNextGain = 1f;
        }
    }

    private void invalidatePreload() {
        preloadGeneration++;
        releaseLoudnessEnhancer(nextLoudnessEnhancer); nextLoudnessEnhancer = null; nextNormalizationVolume = 1f;
        if (nextPlayer != null) releasePlayer(nextPlayer);
        nextPlayer = null;
        nextPrepared = false;
        preloadedIndex = -1;
        isCrossfading = false;
        crossfadeProgress = 0f;
        transitionNextGain = 1f;
        if (currentPlayer != null && currentPrepared) applyVolumes(1f, 0f);
    }

    private void refreshPreloadAfterQueueEdit() {
        if (currentPlayer != null && currentPrepared) {
            invalidatePreload();
            preloadFollowing();
        }
    }

    private int indexOfId(long id) {
        for (int i = 0; i < queue.size(); i++) if (queue.get(i).id == id) return i;
        return -1;
    }

    private void prepareLoudness(MediaPlayer player, Track track, boolean currentSlot) {
        if (player == null || track == null) return;
        if (!loudnessNormalization) {
            if (currentSlot) currentNormalizationVolume = 1f; else nextNormalizationVolume = 1f;
            return;
        }
        loudnessAnalyzer.analyze(track, (t, result) -> {
            if (released || result == null) return;
            boolean valid = currentSlot ? player == currentPlayer : player == nextPlayer;
            if (!valid) return;

            float linear = Math.max(0.35f, Math.min(2.0f, result.gainLinear));
            float volumePart = Math.min(1f, linear);
            int boostMb = 0;
            if (linear > 1.0001f) boostMb = Math.max(0, Math.min(1200, Math.round((float)(20.0 * Math.log10(linear)) * 100f)));

            LoudnessEnhancer enhancer = null;
            if (boostMb > 0) {
                try {
                    enhancer = new LoudnessEnhancer(player.getAudioSessionId());
                    enhancer.setTargetGain(boostMb);
                    enhancer.setEnabled(true);
                } catch (Exception ignored) {
                    releaseLoudnessEnhancer(enhancer);
                    enhancer = null;
                }
            }

            if (currentSlot) {
                releaseLoudnessEnhancer(currentLoudnessEnhancer);
                currentLoudnessEnhancer = enhancer;
                currentNormalizationVolume = volumePart;
            } else {
                releaseLoudnessEnhancer(nextLoudnessEnhancer);
                nextLoudnessEnhancer = enhancer;
                nextNormalizationVolume = volumePart;
            }
            reapplyMixVolumes();
        });
    }

    private void reapplyMixVolumes() {
        if (isCrossfading) {
            float a = (float)Math.cos(crossfadeProgress * Math.PI / 2.0);
            float b = (float)Math.sin(crossfadeProgress * Math.PI / 2.0);
            applyVolumes(a, b * transitionNextGain);
        } else {
            applyVolumes(fadeInActive ? 0f : 1f, 0f);
        }
    }

    private void releaseLoudnessEnhancer(LoudnessEnhancer enhancer) {
        if (enhancer == null) return;
        try { enhancer.setEnabled(false); } catch (Exception ignored) {}
        try { enhancer.release(); } catch (Exception ignored) {}
    }

    private void applyVolumes(float currentFraction, float nextFraction) {
        lastCurrentMixFraction = clamp01(currentFraction);
        lastNextMixFraction = clamp01(nextFraction);
        try {
            if (currentPlayer != null) {
                float v = lastCurrentMixFraction * masterVolume * currentNormalizationVolume;
                currentPlayer.setVolume(clamp01(v), clamp01(v));
            }
        } catch (Exception ignored) {}
        try {
            if (nextPlayer != null) {
                float v = lastNextMixFraction * masterVolume * nextNormalizationVolume;
                nextPlayer.setVolume(clamp01(v), clamp01(v));
            }
        } catch (Exception ignored) {}
    }

    private float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    private void stopAndReset() {
        generation++;
        invalidatePreload();
        releaseLoudnessEnhancer(currentLoudnessEnhancer); currentLoudnessEnhancer = null; currentNormalizationVolume = 1f;
        releasePlayer(currentPlayer);
        currentPlayer = null;
        currentPrepared = false;
        loading = false;
        playing = false;
        lastCurrentMixFraction = 1f;
        lastNextMixFraction = 0f;
        lastCompletionSource = null;
        notifyPlaybackChanged();
    }

    private void releasePlayer(MediaPlayer p) {
        if (p == null) return;
        try { p.setOnPreparedListener(null); p.setOnCompletionListener(null); p.setOnErrorListener(null); } catch (Exception ignored) {}
        try { p.stop(); } catch (Exception ignored) {}
        try { p.release(); } catch (Exception ignored) {}
    }

    private void persistModes() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("shuffle", shuffle)
                .putInt("repeat", repeatMode)
                .apply();
    }

    private void notifyQueueChanged() {
        IdStore.saveLastQueue(context, queue);
        for (Listener l : listeners) l.onQueueChanged();
    }

    private void notifyTrackChanged() {
        Track t = getCurrentTrack();
        for (Listener l : listeners) l.onTrackChanged(t, currentIndex);
    }

    private void notifyPlaybackChanged() {
        for (Listener l : listeners) l.onPlaybackChanged(playing);
    }

    private void notifyModesChanged() {
        for (Listener l : listeners) l.onModesChanged(shuffle, repeatMode, crossfadeEnabled, crossfadeSeconds, fadeInOut, smartCrossfade);
    }

    private void notifyError(String message) {
        for (Listener l : listeners) l.onPlaybackError(message);
    }

    public void release() {
        released = true;
        handler.removeCallbacksAndMessages(null);
        releaseLoudnessEnhancer(currentLoudnessEnhancer); currentLoudnessEnhancer = null;
        releaseLoudnessEnhancer(nextLoudnessEnhancer); nextLoudnessEnhancer = null;
        releasePlayer(currentPlayer);
        releasePlayer(nextPlayer);
        currentPlayer = null;
        nextPlayer = null;
        listeners.clear();
        smartAnalyzer.shutdown();
        loudnessAnalyzer.shutdown();
    }
}
