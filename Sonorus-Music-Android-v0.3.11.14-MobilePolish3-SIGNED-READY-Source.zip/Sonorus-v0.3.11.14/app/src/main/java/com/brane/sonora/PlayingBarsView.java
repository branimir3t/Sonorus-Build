package com.brane.sonora;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

public final class PlayingBarsView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ValueAnimator animator;
    private float phase;
    private boolean playing;
    private boolean effectsEnabled = true;

    public PlayingBarsView(Context c, AttributeSet a) { super(c, a); }

    public void setPlaying(boolean v) { playing = v; updateAnimator(); invalidate(); }
    public void setEffectsEnabled(boolean v) { effectsEnabled = v; updateAnimator(); invalidate(); }

    private void updateAnimator() {
        if (playing && effectsEnabled) {
            if (animator == null) {
                animator = ValueAnimator.ofFloat(0f, 6.28318f);
                animator.setDuration(1400L);
                animator.setRepeatCount(ValueAnimator.INFINITE);
                animator.setInterpolator(new LinearInterpolator());
                animator.addUpdateListener(a -> { phase = (float) a.getAnimatedValue(); invalidate(); });
            }
            if (!animator.isStarted()) animator.start();
        } else if (animator != null) animator.cancel();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int[] colors = {ThemeSupport.accent(getContext()), ThemeSupport.accentAlt(getContext()), 0xFFB64CFF, 0xFF4F7DFF, 0xFF20C7D9};
        float gap = dp(5), barW = dp(4);
        float total = colors.length * barW + (colors.length - 1) * gap;
        float x = (getWidth() - total) / 2f;
        float center = getHeight() / 2f;
        for (int i = 0; i < colors.length; i++) {
            float wave = playing && effectsEnabled ? (float)(0.35 + 0.65 * Math.abs(Math.sin(phase + i * 0.83))) : 0.28f + i * 0.05f;
            float h = Math.max(dp(7), getHeight() * 0.72f * wave);
            paint.setColor(colors[i]);
            paint.setAlpha(playing ? 240 : 110);
            c.drawRoundRect(x, center-h/2f, x+barW, center+h/2f, barW/2f, barW/2f, paint);
            x += barW + gap;
        }
    }

    @Override protected void onDetachedFromWindow() { if (animator != null) animator.cancel(); super.onDetachedFromWindow(); }
    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}
