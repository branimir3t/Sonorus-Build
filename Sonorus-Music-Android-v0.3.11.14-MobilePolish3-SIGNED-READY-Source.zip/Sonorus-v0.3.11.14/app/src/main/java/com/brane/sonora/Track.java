package com.brane.sonora;

import android.net.Uri;

import java.util.Objects;

public final class Track {
    public final long id;
    public final String title;
    public final String artist;
    public final String album;
    public final long albumId;
    public final long durationMs;
    public final long dateAddedSec;
    public final String relativePath;
    public final Uri uri;
    public final long sizeBytes;
    public final String mimeType;
    public final int year;

    public Track(long id, String title, String artist, String album, long albumId,
                 long durationMs, long dateAddedSec, String relativePath, Uri uri) {
        this(id, title, artist, album, albumId, durationMs, dateAddedSec, relativePath, uri, 0L, "", 0);
    }

    public Track(long id, String title, String artist, String album, long albumId,
                 long durationMs, long dateAddedSec, String relativePath, Uri uri,
                 long sizeBytes, String mimeType, int year) {
        this.id = id;
        this.title = clean(title, "Nepoznata pjesma");
        this.artist = cleanArtist(artist);
        this.album = clean(album, "Nepoznat album");
        this.albumId = albumId;
        this.durationMs = Math.max(0L, durationMs);
        this.dateAddedSec = dateAddedSec;
        this.relativePath = normalizePath(relativePath);
        this.uri = uri;
        this.sizeBytes = Math.max(0L, sizeBytes);
        this.mimeType = mimeType == null ? "" : mimeType.trim();
        this.year = Math.max(0, year);
    }

    private static String clean(String value, String fallback) {
        if (value == null) return fallback;
        String s = TrackNameParser.cleanDisplayText(value);
        return s.isEmpty() ? fallback : s;
    }

    private static String cleanArtist(String value) {
        String s = clean(value, "Nepoznat izvođač");
        if ("<unknown>".equalsIgnoreCase(s)) return "Nepoznat izvođač";
        return s;
    }

    private static String normalizePath(String value) {
        if (value == null) return "";
        String s = value.trim().replace('\\', '/');
        while (s.endsWith("/") && s.length() > 1) s = s.substring(0, s.length() - 1);
        return s;
    }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Track)) return false;
        return id == ((Track) o).id;
    }

    @Override public int hashCode() { return Objects.hash(id); }
}
