package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class PlaylistStore {
    private static final String PREFS = "sonora_playlists";
    private static final String INDEX = "playlist_names";
    private static final String ORDER = "playlist_order_v2";
    private static final String PREFIX = "playlist_";

    private PlaylistStore() {}

    public static void save(Context context, String name, List<Track> tracks) {
        String clean = cleanName(name);
        if (clean.isEmpty()) return;
        ArrayList<Long> ids = new ArrayList<>();
        if (tracks != null) for (Track t : tracks) if (t != null) ids.add(t.id);
        saveIds(context, clean, ids);
    }

    public static void append(Context context, String name, List<Track> tracks) {
        String clean = cleanName(name);
        if (clean.isEmpty() || tracks == null || tracks.isEmpty()) return;
        ArrayList<Long> ids = new ArrayList<>(loadIds(context, clean));
        for (Track t : tracks) if (t != null) ids.add(t.id);
        saveIds(context, clean, ids);
    }

    public static void saveIds(Context context, String name, List<Long> ids) {
        String clean = cleanName(name);
        if (clean.isEmpty()) return;
        SharedPreferences p = prefs(context);
        Set<String> names = new HashSet<>(p.getStringSet(INDEX, Collections.emptySet()));
        boolean added = names.add(clean);
        StringBuilder raw = new StringBuilder();
        if (ids != null) for (Long id : ids) {
            if (id == null) continue;
            if (raw.length() > 0) raw.append(',');
            raw.append(id);
        }
        SharedPreferences.Editor e = p.edit().putStringSet(INDEX, names).putString(PREFIX + Uri.encode(clean), raw.toString());
        if (added || !p.contains(ORDER)) e.putString(ORDER, encodeOrder(mergedOrder(p, names)));
        e.apply();
    }

    public static boolean contains(Context context, String name, long trackId) {
        for (Long id : loadIds(context, name)) if (id != null && id == trackId) return true;
        return false;
    }

    public static int duplicateCount(Context context, String name, List<Track> tracks) {
        if (tracks == null || tracks.isEmpty()) return 0;
        HashSet<Long> existing = new HashSet<>(loadIds(context, name));
        int count = 0;
        for (Track t : tracks) if (t != null && existing.contains(t.id)) count++;
        return count;
    }

    public static List<Track> onlyNew(Context context, String name, List<Track> tracks) {
        ArrayList<Track> out = new ArrayList<>();
        if (tracks == null) return out;
        HashSet<Long> existing = new HashSet<>(loadIds(context, name));
        for (Track t : tracks) if (t != null && !existing.contains(t.id)) out.add(t);
        return out;
    }

    public static void delete(Context context, String name) {
        String clean = cleanName(name);
        SharedPreferences p = prefs(context);
        Set<String> names = new HashSet<>(p.getStringSet(INDEX, Collections.emptySet()));
        names.remove(clean);
        ArrayList<String> order = mergedOrder(p, names);
        order.remove(clean);
        p.edit().putStringSet(INDEX, names).putString(ORDER, encodeOrder(order)).remove(PREFIX + Uri.encode(clean)).apply();
    }

    public static boolean rename(Context context, String oldName, String newName) {
        String oldClean = cleanName(oldName);
        String newClean = cleanName(newName);
        if (oldClean.isEmpty() || newClean.isEmpty() || oldClean.equals(newClean)) return false;
        SharedPreferences p = prefs(context);
        Set<String> names = new HashSet<>(p.getStringSet(INDEX, Collections.emptySet()));
        if (!names.contains(oldClean) || names.contains(newClean)) return false;
        String data = p.getString(PREFIX + Uri.encode(oldClean), "");
        ArrayList<String> order = mergedOrder(p, names);
        int ix = order.indexOf(oldClean);
        names.remove(oldClean); names.add(newClean);
        if (ix >= 0) order.set(ix, newClean);
        else if (!order.contains(newClean)) order.add(newClean);
        p.edit()
                .putStringSet(INDEX, names)
                .putString(ORDER, encodeOrder(order))
                .putString(PREFIX + Uri.encode(newClean), data == null ? "" : data)
                .remove(PREFIX + Uri.encode(oldClean))
                .apply();
        return true;
    }

    public static void move(Context context, String name, int delta) {
        if (delta == 0) return;
        SharedPreferences p = prefs(context);
        Set<String> names = new HashSet<>(p.getStringSet(INDEX, Collections.emptySet()));
        ArrayList<String> order = mergedOrder(p, names);
        int from = order.indexOf(name);
        if (from < 0) return;
        int to = Math.max(0, Math.min(order.size() - 1, from + delta));
        if (to == from) return;
        String item = order.remove(from);
        order.add(to, item);
        p.edit().putString(ORDER, encodeOrder(order)).apply();
    }

    public static List<String> names(Context context) {
        SharedPreferences p = prefs(context);
        Set<String> names = new HashSet<>(p.getStringSet(INDEX, Collections.emptySet()));
        ArrayList<String> order = mergedOrder(p, names);
        if (!order.equals(decodeOrder(p.getString(ORDER, "")))) p.edit().putString(ORDER, encodeOrder(order)).apply();
        return order;
    }

    public static List<Long> loadIds(Context context, String name) {
        String raw = prefs(context).getString(PREFIX + Uri.encode(cleanName(name)), "");
        ArrayList<Long> out = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return out;
        for (String part : raw.split(",")) {
            try { out.add(Long.parseLong(part)); } catch (NumberFormatException ignored) {}
        }
        return out;
    }

    public static int count(Context context, String name) { return loadIds(context, name).size(); }

    private static String cleanName(String name) { return name == null ? "" : name.trim(); }

    private static ArrayList<String> mergedOrder(SharedPreferences p, Set<String> names) {
        ArrayList<String> order = decodeOrder(p.getString(ORDER, ""));
        order.removeIf(n -> !names.contains(n));
        ArrayList<String> missing = new ArrayList<>();
        for (String n : names) if (!order.contains(n)) missing.add(n);
        missing.sort(String.CASE_INSENSITIVE_ORDER);
        order.addAll(missing);
        return order;
    }

    private static ArrayList<String> decodeOrder(String raw) {
        ArrayList<String> out = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return out;
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                String n = a.optString(i, "").trim();
                if (!n.isEmpty() && !out.contains(n)) out.add(n);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static String encodeOrder(List<String> order) {
        JSONArray a = new JSONArray();
        if (order != null) for (String n : order) if (n != null && !n.trim().isEmpty()) a.put(n.trim());
        return a.toString();
    }

    private static SharedPreferences prefs(Context context) { return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
}
