package com.brane.sonora;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Transparent tonearm overlay that moves between its rest and the record groove. */
public final class TonearmView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint highlight = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float engagedProgress;
    private ValueAnimator animator;

    public TonearmView(Context context) { this(context, null); }
    public TonearmView(Context context, AttributeSet attrs) { this(context, attrs, 0); }
    public TonearmView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        paint.setStrokeCap(Paint.Cap.ROUND);
        highlight.setStrokeCap(Paint.Cap.ROUND);
        setWillNotDraw(false);
    }

    public void setEngaged(boolean engaged) {
        float target = engaged ? 1f : 0f;
        if (Math.abs(target - engagedProgress) < 0.001f) return;
        if (animator != null) animator.cancel();
        animator = ValueAnimator.ofFloat(engagedProgress, target);
        animator.setDuration(engaged ? 520L : 620L);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(a -> {
            engagedProgress = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float pivotX = w * 0.82f;
        float pivotY = h * 0.29f;
        float elbowRestX = w * 0.89f;
        float elbowRestY = h * 0.47f;
        float tipRestX = w * 0.90f;
        float tipRestY = h * 0.60f;
        float elbowPlayX = w * 0.73f;
        float elbowPlayY = h * 0.48f;
        float tipPlayX = w * 0.61f;
        float tipPlayY = h * 0.58f;
        float e = engagedProgress;
        float elbowX = lerp(elbowRestX, elbowPlayX, e);
        float elbowY = lerp(elbowRestY, elbowPlayY, e);
        float tipX = lerp(tipRestX, tipPlayX, e);
        float tipY = lerp(tipRestY, tipPlayY, e);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x70000000);
        canvas.drawCircle(pivotX + dp(2f), pivotY + dp(4f), dp(19f), paint);
        paint.setColor(0xFF555B63);
        canvas.drawCircle(pivotX, pivotY, dp(18f), paint);
        paint.setColor(0xFF1A1B1F);
        canvas.drawCircle(pivotX, pivotY, dp(9f), paint);

        // Shadow, metal body and highlight are separate strokes for a more physical arm.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(8f));
        paint.setColor(0x55000000);
        canvas.drawLine(pivotX + dp(2f), pivotY + dp(3f), elbowX + dp(2f), elbowY + dp(3f), paint);
        canvas.drawLine(elbowX + dp(2f), elbowY + dp(3f), tipX + dp(2f), tipY + dp(3f), paint);

        paint.setStrokeWidth(dp(6f));
        paint.setColor(0xFFC9CDD2);
        canvas.drawLine(pivotX, pivotY, elbowX, elbowY, paint);
        canvas.drawLine(elbowX, elbowY, tipX, tipY, paint);
        highlight.setStyle(Paint.Style.STROKE);
        highlight.setStrokeWidth(dp(1.4f));
        highlight.setColor(0xA8FFFFFF);
        canvas.drawLine(pivotX - dp(1f), pivotY - dp(1f), elbowX - dp(1f), elbowY - dp(1f), highlight);
        canvas.drawLine(elbowX - dp(1f), elbowY - dp(1f), tipX - dp(1f), tipY - dp(1f), highlight);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF1C1D20);
        RectF cartridge = new RectF(tipX - dp(7f), tipY - dp(5f), tipX + dp(9f), tipY + dp(6f));
        canvas.save();
        canvas.rotate(-16f + 22f * e, tipX, tipY);
        canvas.drawRoundRect(cartridge, dp(2f), dp(2f), paint);
        paint.setColor(ThemeSupport.accent(getContext()));
        canvas.drawCircle(tipX + dp(7f), tipY + dp(5f), dp(2.1f), paint);
        canvas.restore();
    }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
}
