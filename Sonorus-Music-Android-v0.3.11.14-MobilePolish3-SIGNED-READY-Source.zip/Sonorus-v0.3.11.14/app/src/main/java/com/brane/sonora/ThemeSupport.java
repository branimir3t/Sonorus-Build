package com.brane.sonora;

import android.content.Context;
import android.graphics.Color;
import android.util.TypedValue;

public final class ThemeSupport {
    private ThemeSupport() {}

    public static int resolveColor(Context context, int attr, int fallback) {
        if (context == null) return fallback;
        TypedValue tv = new TypedValue();
        if (!context.getTheme().resolveAttribute(attr, tv, true)) return fallback;
        if (tv.type >= TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= TypedValue.TYPE_LAST_COLOR_INT) return tv.data;
        try { return context.getColor(tv.resourceId); } catch (Exception ignored) { return fallback; }
    }

    public static int accent(Context c) { return resolveColor(c, R.attr.sonorusAccent, Color.rgb(255,138,43)); }
    public static int accentAlt(Context c) { return resolveColor(c, R.attr.sonorusAccentAlt, Color.rgb(182,76,255)); }
    public static int text(Context c) { return resolveColor(c, R.attr.sonorusTextPrimary, Color.WHITE); }
    public static int text2(Context c) { return resolveColor(c, R.attr.sonorusTextSecondary, Color.rgb(183,186,199)); }
    public static int text3(Context c) { return resolveColor(c, R.attr.sonorusTextMuted, Color.rgb(126,130,145)); }
    public static int divider(Context c) { return resolveColor(c, R.attr.sonorusDivider, Color.rgb(43,46,57)); }
    public static int bg(Context c) { return resolveColor(c, R.attr.sonorusBg, Color.rgb(9,10,14)); }
    public static int panel(Context c) { return resolveColor(c, R.attr.sonorusPanel, Color.rgb(17,18,24)); }
    public static int panel2(Context c) { return resolveColor(c, R.attr.sonorusPanel2, Color.rgb(24,26,34)); }
    public static int card(Context c) { return resolveColor(c, R.attr.sonorusCard, Color.rgb(28,30,39)); }
}
