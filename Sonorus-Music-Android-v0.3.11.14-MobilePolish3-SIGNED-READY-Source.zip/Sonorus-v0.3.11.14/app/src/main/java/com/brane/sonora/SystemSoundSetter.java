package com.brane.sonora;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;

public final class SystemSoundSetter {
    private SystemSoundSetter() {}

    public static boolean canWriteSettings(Context context) {
        return context != null && Settings.System.canWrite(context);
    }

    public static void openWriteSettings(Activity activity) {
        if (activity == null) return;
        Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:" + activity.getPackageName()));
        activity.startActivity(intent);
    }

    public static boolean setAs(Context context, Track track, int type) {
        if (context == null || track == null || track.uri == null || !canWriteSettings(context)) return false;
        markMediaTypeBestEffort(context.getContentResolver(), track.uri, type);
        try {
            RingtoneManager.setActualDefaultRingtoneUri(context, type, track.uri);
            Uri actual = RingtoneManager.getActualDefaultRingtoneUri(context, type);
            return actual != null && actual.equals(track.uri);
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    private static void markMediaTypeBestEffort(ContentResolver resolver, Uri uri, int type) {
        if (resolver == null || uri == null) return;
        ContentValues values = new ContentValues();
        if (type == RingtoneManager.TYPE_RINGTONE) values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
        else if (type == RingtoneManager.TYPE_ALARM) values.put(MediaStore.Audio.Media.IS_ALARM, true);
        else if (type == RingtoneManager.TYPE_NOTIFICATION) values.put(MediaStore.Audio.Media.IS_NOTIFICATION, true);
        if (values.size() == 0) return;
        try { resolver.update(uri, values, null, null); }
        catch (RuntimeException ignored) {}
    }
}
