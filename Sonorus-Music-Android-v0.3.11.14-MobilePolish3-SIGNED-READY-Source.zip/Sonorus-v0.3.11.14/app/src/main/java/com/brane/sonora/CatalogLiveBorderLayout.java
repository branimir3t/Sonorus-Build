package com.brane.sonora;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;
import android.widget.LinearLayout;

public final class CatalogLiveBorderLayout extends LinearLayout {
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ValueAnimator animator;
    private float phase;
    private boolean previewPlaying;

    public CatalogLiveBorderLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
        borderPaint.setStyle(Paint.Style.STROKE);
    }

    public void setPreviewPlaying(boolean playing) {
        if (previewPlaying == playing) return;
        previewPlaying = playing;
        updateAnimator();
        invalidate();
    }

    private void updateAnimator() {
        if (previewPlaying) {
            if (animator == null) {
                animator = ValueAnimator.ofFloat(0f, (float)(Math.PI * 2.0));
                animator.setDuration(1200L);
                animator.setRepeatCount(ValueAnimator.INFINITE);
                animator.setInterpolator(new LinearInterpolator());
                animator.addUpdateListener(value -> {
                    phase = (float)value.getAnimatedValue();
                    invalidate();
                });
            }
            if (!animator.isStarted()) animator.start();
        } else if (animator != null) {
            animator.cancel();
            phase = 0f;
        }
    }

    @Override protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        if (!previewPlaying || getWidth() <= 0 || getHeight() <= 0) return;

        float wave = 0.5f + 0.5f * (float)Math.sin(phase);
        borderPaint.setColor(ThemeSupport.accent(getContext()));
        borderPaint.setAlpha((int)(150f + 95f * wave));
        borderPaint.setStrokeWidth(dp(1.6f + 0.8f * wave));

        float inset = dp(2.2f);
        canvas.drawRoundRect(inset, inset, getWidth() - inset, getHeight() - inset, dp(15f), dp(15f), borderPaint);
    }

    @Override protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
