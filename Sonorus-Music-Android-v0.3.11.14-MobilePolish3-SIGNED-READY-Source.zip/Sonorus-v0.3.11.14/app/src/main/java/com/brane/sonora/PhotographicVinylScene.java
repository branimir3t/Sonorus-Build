package com.brane.sonora;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

/** One photographic stage: sleeve, rotating record, fixed light, spindle, then stylus. */
public final class PhotographicVinylScene extends FrameLayout {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final Matrix plane=new Matrix(), sleeveMatrix=new Matrix();
    private final Path discClip=new Path(), armClip=new Path(), sleeveEdge=new Path(), surfaceClip=new Path(), centerClip=new Path();
    private final RectF disc=new RectF(-1,-1,1,1), sceneRect=new RectF(0,0,970,866),
        sleeveRect=new RectF(0,0,1,1), labelRect=new RectF(-.315f,-.315f,.315f,.315f),
        spindleBase=new RectF(519,477,531,483), spindleTop=new RectF(521,475,528,479);
    private final Rect oldBounds=new Rect();
    private final Bitmap record;
    private final Shader light;
    private ImageView photo,cover,label;
    private boolean playing;
    private float angle;
    private long lastFrame;

    public PhotographicVinylScene(Context c,AttributeSet a) {
        super(c,a);
        setWillNotDraw(false);
        // Homography of the physical platter plane. Its center is always the spindle.
        plane.setValues(new float[]{VinylSceneGeometry.RX, VinylSceneGeometry.CX*VinylSceneGeometry.PERSPECTIVE, VinylSceneGeometry.CX,
            0, VinylSceneGeometry.RY+VinylSceneGeometry.CY*VinylSceneGeometry.PERSPECTIVE, VinylSceneGeometry.CY,
            0,VinylSceneGeometry.PERSPECTIVE,1});
        discClip.addCircle(0,0,1,Path.Direction.CW);
        surfaceClip.set(discClip); surfaceClip.transform(plane);
        centerClip.addCircle(0,0,.315f,Path.Direction.CW); centerClip.transform(plane);
        sleeveMatrix.setPolyToPoly(new float[]{0,0,1,0,1,1,0,1},0,
            new float[]{94,106,525,88,554,461,122,477},0,4);
        sleeveEdge.moveTo(94,106); sleeveEdge.lineTo(90,111); sleeveEdge.lineTo(117,478); sleeveEdge.lineTo(122,477); sleeveEdge.close();
        // Photograph silhouette: cartridge, bent polished tube and pivot; no rectangular crop.
        float[] arm={638,514,646,481,649,468,685,456,714,449,738,434,778,382,777,367,785,355,
            811,349,835,351,844,361,844,397,832,408,811,413,789,410,787,397,
            751,449,731,462,724,472,721,497,700,505,687,509,679,523,650,526};
        armClip.moveTo(arm[0],arm[1]);
        for(int i=2;i<arm.length;i+=2) armClip.lineTo(arm[i],arm[i+1]);
        armClip.close();
        record=makeRecord();
        light=new SweepGradient(0,0,new int[]{0x00000000,0x08D6E6FF,0x287887BD,0x00000000,
            0x00FFCE7C,0x48EBA643,0x10E8B75B,0x00000000,0x0DDDE9F7,0x00000000},
            new float[]{0,.07f,.16f,.25f,.39f,.49f,.56f,.66f,.83f,1});
    }
    @Override protected void onFinishInflate() {
        super.onFinishInflate();
        photo=findViewById(R.id.fullscreenScenePhoto);
        cover=findViewById(R.id.fullscreenCover);
        label=findViewById(R.id.fullscreenRecordLabel);
    }
    @Override public void onDescendantInvalidated(View child, View target) {
        super.onDescendantInvalidated(child,target);
        // ArtworkLoader updates these ImageViews asynchronously; redraw even while paused.
        invalidate();
    }
    public void setPlaying(boolean value) {
        if(playing!=value) { playing=value; lastFrame=0; }
        invalidate();
    }
    @Override protected void onWindowVisibilityChanged(int visibility) { super.onWindowVisibilityChanged(visibility); lastFrame=0; }
    @Override protected void onDetachedFromWindow() { lastFrame=0; super.onDetachedFromWindow(); }
    @Override protected void dispatchDraw(Canvas canvas) {
        if(photo==null || getWidth()==0 || getHeight()==0) return;
        long now=SystemClock.uptimeMillis();
        boolean animate=playing && isShown() && getWindowVisibility()==View.VISIBLE;
        if(animate && lastFrame!=0) angle=VinylSceneGeometry.advance(angle,Math.min(64,now-lastFrame),true);
        lastFrame=animate?now:0;
        float s=VinylSceneGeometry.fitScale(getWidth(),getHeight());
        int stage=canvas.save();
        canvas.translate((getWidth()-970*s)/2,(getHeight()-866*s)/2); canvas.scale(s,s);
        drawDrawable(canvas,photo.getDrawable(),sceneRect);
        // The printed artwork reaches every sleeve edge; no UI border or rounded corners.
        paint.setColor(0xFF3E3020); canvas.drawPath(sleeveEdge,paint);
        int sleeve=canvas.save(); canvas.concat(sleeveMatrix);
        drawArtwork(canvas,cover.getDrawable(),sleeveRect); canvas.restoreToCount(sleeve);
        int platter=canvas.save(); canvas.concat(plane); canvas.clipPath(discClip);
        int spin=canvas.save(); canvas.rotate(angle);
        paint.setColor(Color.WHITE); paint.setAlpha(255);
        canvas.drawBitmap(record,null,disc,paint);
        // Label shares precisely the same rotation AND homography as the entire record.
        int sticker=canvas.save();
        canvas.clipPath(labelCircle());
        drawArtwork(canvas,label.getDrawable(),labelRect);
        canvas.restoreToCount(sticker);
        canvas.restoreToCount(spin);
        // Room highlights do not rotate with the material.
        paint.setShader(light); canvas.drawCircle(0,0,1,paint); paint.setShader(null);
        canvas.restoreToCount(platter);
        // The photographed room reflection remains fixed on the rotating grooves.
        // Clip in scene coordinates, excluding the label and moving arm silhouette.
        int reflection=canvas.save();
        canvas.clipPath(surfaceClip);
        canvas.clipOutPath(centerClip);
        canvas.clipOutPath(armClip);
        Drawable photographed=photo.getDrawable();
        if(photographed instanceof BitmapDrawable) {
            paint.setAlpha(175);
            canvas.drawBitmap(((BitmapDrawable)photographed).getBitmap(),null,sceneRect,paint);
            paint.setAlpha(255);
        }
        canvas.restoreToCount(reflection);
        paint.setColor(0xFF080807); canvas.drawOval(spindleBase,paint);
        paint.setColor(0xFFBBA881); canvas.drawOval(spindleTop,paint);
        // Reuse the actual photographic arm, with a subpixel lift around its fixed bearing.
        int arm=canvas.save(); canvas.rotate(VinylSceneGeometry.armLift(angle),811,377);
        canvas.clipPath(armClip); drawDrawable(canvas,photo.getDrawable(),sceneRect);
        canvas.restoreToCount(arm);
        canvas.restoreToCount(stage);
        if(animate) postInvalidateOnAnimation();
    }
    private final Path labelPath=new Path();
    private Path labelCircle() {
        if(labelPath.isEmpty()) labelPath.addCircle(0,0,.315f,Path.Direction.CW);
        return labelPath;
    }
    private void drawDrawable(Canvas c,Drawable d,RectF target) {
        if(d==null) return;
        if(d instanceof BitmapDrawable) {
            canvasBitmap(c,((BitmapDrawable)d).getBitmap(),target); return;
        }
        oldBounds.set(d.getBounds());
        int save=c.save(); c.translate(target.left,target.top); c.scale(target.width()/970f,target.height()/866f);
        d.setBounds(0,0,970,866); d.draw(c); d.setBounds(oldBounds); c.restoreToCount(save);
    }
    private void canvasBitmap(Canvas c,Bitmap b,RectF target) {
        paint.setColor(Color.WHITE); paint.setAlpha(255); c.drawBitmap(b,null,target,paint);
    }
    private void drawArtwork(Canvas c,Drawable d,RectF target) {
        if(d==null) return;
        Bitmap bitmap=d instanceof BitmapDrawable ? ((BitmapDrawable)d).getBitmap() : null;
        int iw=bitmap!=null ? bitmap.getWidth() : Math.max(1,d.getIntrinsicWidth());
        int ih=bitmap!=null ? bitmap.getHeight() : Math.max(1,d.getIntrinsicHeight());
        float scale=Math.max(target.width()/iw,target.height()/ih);
        int save=c.save(); c.clipRect(target);
        c.translate(target.centerX()-iw*scale/2,target.centerY()-ih*scale/2); c.scale(scale,scale);
        if(bitmap!=null) { paint.setColor(Color.WHITE); c.drawBitmap(bitmap,0,0,paint); }
        else { oldBounds.set(d.getBounds()); d.setBounds(0,0,iw,ih); d.draw(c); d.setBounds(oldBounds); }
        c.restoreToCount(save);
    }
    private Bitmap makeRecord() {
        Bitmap b=Bitmap.createBitmap(1200,1200,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(b); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(600,600,600,new int[]{0xFF080706,0xFF171310,0xFF070707,0xFF171514,0xFF050505},null,Shader.TileMode.CLAMP));
        c.drawCircle(600,600,600,p); p.setShader(null); p.setStyle(Paint.Style.STROKE);
        java.util.Random random=new java.util.Random(93019);
        for(float r=199;r<599;r+=1.35f) {
            p.setStrokeWidth(.35f+random.nextFloat()*.45f);
            int alpha=18+random.nextInt(35); p.setColor((alpha<<24)|0xC6B89E);
            c.drawCircle(600,600,r,p);
        }
        // Fine discontinuous groove glints give motion to the whole surface.
        for(int i=0;i<280;i++) {
            float r=201+random.nextFloat()*395;
            p.setStrokeWidth(.45f); p.setColor(0x24B2A18A);
            c.drawArc(new RectF(600-r,600-r,600+r,600+r),random.nextFloat()*360,3+random.nextFloat()*30,false,p);
        }
        p.setStrokeWidth(2);p.setColor(0xFF242320);c.drawCircle(600,600,598,p);
        return b;
    }
}
