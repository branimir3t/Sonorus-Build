package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;

public final class SonorusSettings {
    private static final String PREFS = "sonorus_settings";
    private SonorusSettings() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean crossfadeEnabled(Context c) { return p(c).getBoolean("crossfade_enabled", true); }
    public static void setCrossfadeEnabled(Context c, boolean v) { p(c).edit().putBoolean("crossfade_enabled", v).apply(); }

    public static int crossfadeSeconds(Context c) {
        int v = p(c).getInt("crossfade_seconds", 5);
        return v == 10 || v == 15 ? v : 5;
    }
    public static void setCrossfadeSeconds(Context c, int v) { p(c).edit().putInt("crossfade_seconds", v == 10 || v == 15 ? v : 5).apply(); }

    public static boolean fadeInOut(Context c) { return p(c).getBoolean("fade_in_out", true); }
    public static void setFadeInOut(Context c, boolean v) { p(c).edit().putBoolean("fade_in_out", v).apply(); }

    public static boolean smartCrossfade(Context c) { return p(c).getBoolean("smart_crossfade", false); }
    public static void setSmartCrossfade(Context c, boolean v) { p(c).edit().putBoolean("smart_crossfade", v).apply(); }


    public static int crossfadeMode(Context c) {
        int fallback = smartCrossfade(c) ? 1 : 0;
        int v = p(c).getInt("crossfade_mode", fallback);
        return v == 1 || v == 2 ? v : 0;
    }
    public static void setCrossfadeMode(Context c, int v) {
        int safe = v == 1 || v == 2 ? v : 0;
        p(c).edit().putInt("crossfade_mode", safe).putBoolean("smart_crossfade", safe != 0).apply();
    }

    public static boolean onlineMetadata(Context c) { return p(c).getBoolean("online_metadata", false); }
    public static void setOnlineMetadata(Context c, boolean v) { p(c).edit().putBoolean("online_metadata", v).apply(); }

    public static boolean wifiOnly(Context c) { return p(c).getBoolean("wifi_only", true); }
    public static void setWifiOnly(Context c, boolean v) { p(c).edit().putBoolean("wifi_only", v).apply(); }


    public static boolean loudnessNormalization(Context c) { return p(c).getBoolean("loudness_normalization", false); }
    public static void setLoudnessNormalization(Context c, boolean v) { p(c).edit().putBoolean("loudness_normalization", v).apply(); }

    public static boolean backgroundPlayback(Context c) { return p(c).getBoolean("background_playback", true); }
    public static void setBackgroundPlayback(Context c, boolean v) { p(c).edit().putBoolean("background_playback", v).apply(); }

    public static boolean dynamicNowPlaying(Context c) { return p(c).getBoolean("dynamic_now_playing", true); }
    public static void setDynamicNowPlaying(Context c, boolean v) { p(c).edit().putBoolean("dynamic_now_playing", v).apply(); }



    public static final int THEME_ORIGINAL = 0;
    public static final int THEME_AURORA = 1;
    public static final int THEME_COPPER = 2;
    public static final int THEME_VINYL = 3;
    public static final int THEME_OBSIDIAN = 4;
    public static final int THEME_CRIMSON = 5;

    public static int theme(Context c) {
        int v = p(c).getInt("app_theme", THEME_ORIGINAL);
        return v >= THEME_ORIGINAL && v <= THEME_CRIMSON ? v : THEME_ORIGINAL;
    }
    public static void setTheme(Context c, int v) {
        int safe = v >= THEME_ORIGINAL && v <= THEME_CRIMSON ? v : THEME_ORIGINAL;
        p(c).edit().putInt("app_theme", safe).apply();
    }

    public static boolean fullscreen(Context c) { return p(c).getBoolean("fullscreen", true); }
    public static void setFullscreen(Context c, boolean v) { p(c).edit().putBoolean("fullscreen", v).apply(); }

    public static boolean technicalInfo(Context c) { return p(c).getBoolean("technical_info", true); }
    public static void setTechnicalInfo(Context c, boolean v) { p(c).edit().putBoolean("technical_info", v).apply(); }
}
