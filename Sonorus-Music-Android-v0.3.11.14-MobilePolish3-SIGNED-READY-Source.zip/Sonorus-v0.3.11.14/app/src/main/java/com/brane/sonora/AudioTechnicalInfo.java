package com.brane.sonora;

import android.content.Context;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;

import java.util.Locale;

public final class AudioTechnicalInfo {
    public final String format;
    public final String mime;
    public final int bitrateBps;
    public final int sampleRateHz;
    public final int channels;
    public final int bitDepth;

    private AudioTechnicalInfo(String format, String mime, int bitrateBps, int sampleRateHz, int channels, int bitDepth) {
        this.format = format;
        this.mime = mime == null ? "" : mime;
        this.bitrateBps = Math.max(0, bitrateBps);
        this.sampleRateHz = Math.max(0, sampleRateHz);
        this.channels = Math.max(0, channels);
        this.bitDepth = Math.max(0, bitDepth);
    }

    public static AudioTechnicalInfo read(Context context, Track track) {
        if (context == null || track == null || track.uri == null) return new AudioTechnicalInfo("AUDIO", "", 0, 0, 0, 0);
        String mime = track.mimeType == null ? "" : track.mimeType.trim();
        int bitrate = 0;
        int sampleRate = 0;
        int channels = 0;
        int bitDepth = 0;
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(context, track.uri, null);
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String m = f.containsKey(MediaFormat.KEY_MIME) ? f.getString(MediaFormat.KEY_MIME) : "";
                if (m == null || !m.toLowerCase(Locale.ROOT).startsWith("audio/")) continue;
                if (mime.isEmpty()) mime = m;
                if (f.containsKey(MediaFormat.KEY_BIT_RATE)) bitrate = positive(f.getInteger(MediaFormat.KEY_BIT_RATE));
                if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = positive(f.getInteger(MediaFormat.KEY_SAMPLE_RATE));
                if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = positive(f.getInteger(MediaFormat.KEY_CHANNEL_COUNT));
                if (f.containsKey("bits-per-sample")) bitDepth = positive(f.getInteger("bits-per-sample"));
                break;
            }
        } catch (Exception ignored) {
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
        }

        if (bitrate <= 0) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(context, track.uri);
                String b = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE);
                if (b != null) bitrate = positive(Integer.parseInt(b));
            } catch (Exception ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) {}
            }
        }
        String lowerMime = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (bitDepth <= 0 && bitrate > 0 && sampleRate > 0 && channels > 0
                && (lowerMime.contains("wav") || lowerMime.contains("pcm") || lowerMime.contains("raw"))) {
            int estimated = Math.round(bitrate / (float) (sampleRate * channels));
            if (estimated == 8 || estimated == 16 || estimated == 24 || estimated == 32) bitDepth = estimated;
        }
        if (bitrate <= 0 && sampleRate > 0 && channels > 0 && bitDepth > 0
                && (lowerMime.contains("wav") || lowerMime.contains("pcm") || lowerMime.contains("raw"))) {
            long estimated = (long) sampleRate * channels * bitDepth;
            if (estimated <= Integer.MAX_VALUE) bitrate = (int) estimated;
        }
        return new AudioTechnicalInfo(formatLabel(mime), mime, bitrate, sampleRate, channels, bitDepth);
    }

    private static int positive(int value) { return Math.max(0, value); }

    private static String formatLabel(String mime) {
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.contains("flac")) return "FLAC";
        if (m.contains("mpeg")) return "MP3";
        if (m.contains("wav")) return "WAV";
        if (m.contains("aac")) return "AAC";
        if (m.contains("mp4") || m.contains("m4a")) return "M4A";
        if (m.contains("opus")) return "OPUS";
        if (m.contains("ogg")) return "OGG";
        if (m.contains("wma")) return "WMA";
        return m.startsWith("audio/") && m.length() > 6 ? m.substring(6).toUpperCase(Locale.ROOT) : "AUDIO";
    }

    public String bitrateLabel() {
        return bitrateBps > 0 ? Math.round(bitrateBps / 1000f) + " kbps" : "Nije dostupno";
    }

    public String sampleRateLabel() {
        if (sampleRateHz <= 0) return "Nije dostupno";
        float khz = sampleRateHz / 1000f;
        if (Math.abs(khz - Math.round(khz)) < 0.01f) return Math.round(khz) + " kHz";
        return String.format(Locale.US, "%.1f kHz", khz);
    }

    public String channelsLabel() {
        if (channels == 1) return "Mono";
        if (channels == 2) return "Stereo";
        if (channels > 2) return channels + " kanala";
        return "Nije dostupno";
    }
}
