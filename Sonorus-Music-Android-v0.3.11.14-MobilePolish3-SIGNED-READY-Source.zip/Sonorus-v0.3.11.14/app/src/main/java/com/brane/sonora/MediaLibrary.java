package com.brane.sonora;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MediaLibrary {
    public static final class GenreInfo {
        public final long id;
        public final String name;
        public final int count;
        public GenreInfo(long id, String name, int count) { this.id = id; this.name = name; this.count = count; }
    }

    private MediaLibrary() {}

    public static List<Track> queryTracks(Context context) {
        ArrayList<Track> result = new ArrayList<>();
        ContentResolver cr = context.getContentResolver();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

        ArrayList<String> cols = new ArrayList<>();
        cols.add(MediaStore.Audio.Media._ID);
        cols.add(MediaStore.Audio.Media.TITLE);
        cols.add(MediaStore.MediaColumns.DISPLAY_NAME);
        cols.add(MediaStore.Audio.Media.ARTIST);
        cols.add(MediaStore.Audio.Media.ALBUM);
        cols.add(MediaStore.Audio.Media.ALBUM_ID);
        cols.add(MediaStore.Audio.Media.DURATION);
        cols.add(MediaStore.Audio.Media.DATE_ADDED);
        cols.add(MediaStore.Audio.Media.SIZE);
        cols.add(MediaStore.Audio.Media.MIME_TYPE);
        cols.add(MediaStore.Audio.Media.YEAR);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) cols.add(MediaStore.Audio.Media.RELATIVE_PATH);
        else cols.add(MediaStore.Audio.Media.DATA);

        String selection = MediaStore.Audio.Media.IS_MUSIC + "!=0 AND " + MediaStore.Audio.Media.DURATION + ">0";
        String sort = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";

        try (Cursor c = cr.query(collection, cols.toArray(new String[0]), selection, null, sort)) {
            if (c == null) return result;
            int idIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            int titleIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
            int displayNameIx = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
            int artistIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
            int albumIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
            int albumIdIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID);
            int durationIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
            int dateIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED);
            int sizeIx = c.getColumnIndex(MediaStore.Audio.Media.SIZE);
            int mimeIx = c.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE);
            int yearIx = c.getColumnIndex(MediaStore.Audio.Media.YEAR);
            int pathIx = c.getColumnIndex(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ? MediaStore.Audio.Media.RELATIVE_PATH : MediaStore.Audio.Media.DATA);

            while (c.moveToNext()) {
                long id = c.getLong(idIx);
                Uri uri = ContentUris.withAppendedId(collection, id);
                String path = pathIx >= 0 ? c.getString(pathIx) : "";
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && path != null) {
                    File parent = new File(path).getParentFile();
                    path = parent == null ? "" : parent.getAbsolutePath();
                }
                String rawTitle = c.getString(titleIx);
                String rawArtist = c.getString(artistIx);
                String displayName = displayNameIx >= 0 ? c.getString(displayNameIx) : rawTitle;
                TrackNameParser.Parsed parsed = TrackNameParser.parse(rawTitle, displayName, rawArtist);
                String finalArtist = TrackNameParser.isUnknownArtist(rawArtist) && parsed.artist != null && !parsed.artist.trim().isEmpty() ? parsed.artist : rawArtist;
                String finalTitle = parsed.title == null || parsed.title.trim().isEmpty() ? rawTitle : parsed.title;
                finalArtist = TrackNameParser.cleanDisplayText(finalArtist);
                finalTitle = TrackNameParser.cleanDisplayText(finalTitle);
                Track track = new Track(
                        id,
                        finalTitle,
                        finalArtist,
                        c.getString(albumIx),
                        c.getLong(albumIdIx),
                        c.getLong(durationIx),
                        c.getLong(dateIx),
                        path,
                        uri,
                        sizeIx >= 0 ? c.getLong(sizeIx) : 0L,
                        mimeIx >= 0 ? c.getString(mimeIx) : "",
                        yearIx >= 0 ? c.getInt(yearIx) : 0
                );
                result.add(TrackMetadataStore.apply(context, track));
            }
        } catch (SecurityException ignored) {
        } catch (Exception ignored) {
            // Neki OEM MediaStoreovi mogu imati nepotpunu projekciju. Ne ruši aplikaciju.
        }
        return result;
    }

    public static List<GenreInfo> queryGenres(Context context) {
        ArrayList<GenreInfo> result = new ArrayList<>();
        ContentResolver cr = context.getContentResolver();
        Uri genres = MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI;
        String[] projection = { MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME };
        try (Cursor c = cr.query(genres, projection, null, null, MediaStore.Audio.Genres.NAME + " COLLATE NOCASE ASC")) {
            if (c == null) return result;
            int idIx = c.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID);
            int nameIx = c.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME);
            while (c.moveToNext()) {
                long id = c.getLong(idIx);
                String name = c.getString(nameIx);
                if (name == null || name.trim().isEmpty()) name = "Bez žanra";
                int count = countGenreMembers(cr, id);
                if (count > 0) result.add(new GenreInfo(id, name.trim(), count));
            }
        } catch (Exception ignored) {}
        return result;
    }

    private static int countGenreMembers(ContentResolver cr, long genreId) {
        Uri members = MediaStore.Audio.Genres.Members.getContentUri("external", genreId);
        String[] projection = { MediaStore.Audio.Genres.Members.AUDIO_ID };
        int count = 0;
        try (Cursor c = cr.query(members, projection, null, null, null)) { if (c != null) count = c.getCount(); }
        catch (Exception ignored) {}
        return count;
    }

    public static List<Long> queryGenreTrackIds(Context context, long genreId) {
        ArrayList<Long> ids = new ArrayList<>();
        Uri members = MediaStore.Audio.Genres.Members.getContentUri("external", genreId);
        String[] projection = { MediaStore.Audio.Genres.Members.AUDIO_ID };
        try (Cursor c = context.getContentResolver().query(members, projection, null, null, null)) {
            if (c != null) {
                int ix = c.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID);
                while (c.moveToNext()) ids.add(c.getLong(ix));
            }
        } catch (Exception ignored) {}
        return ids;
    }

    public static Map<Long, Track> mapById(List<Track> tracks) {
        HashMap<Long, Track> map = new HashMap<>();
        for (Track t : tracks) map.put(t.id, t);
        return map;
    }

    public static List<CatalogEntry> trackEntries(List<Track> tracks) {
        ArrayList<CatalogEntry> out = new ArrayList<>(tracks.size());
        for (Track t : tracks) out.add(CatalogEntry.track(t));
        return out;
    }

    public static List<CatalogEntry> artistEntries(List<Track> tracks) {
        LinkedHashMap<String, Integer> counts = new LinkedHashMap<>();
        for (Track t : tracks) counts.put(t.artist, counts.getOrDefault(t.artist, 0) + 1);
        ArrayList<CatalogEntry> out = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>(counts.keySet());
        names.sort(String.CASE_INSENSITIVE_ORDER);
        for (String n : names) out.add(CatalogEntry.artist(n, counts.get(n)));
        return out;
    }

    public static List<CatalogEntry> albumEntries(List<Track> tracks) {
        final class AlbumBucket { long id; String album; String artist; int count; }
        LinkedHashMap<String, AlbumBucket> map = new LinkedHashMap<>();
        for (Track t : tracks) {
            String key = t.albumId + "|" + t.album;
            AlbumBucket b = map.get(key);
            if (b == null) { b = new AlbumBucket(); b.id=t.albumId; b.album=t.album; b.artist=t.artist; map.put(key,b); }
            b.count++;
            if (!b.artist.equals(t.artist)) b.artist = "Razni izvođači";
        }
        ArrayList<AlbumBucket> buckets = new ArrayList<>(map.values());
        buckets.sort(Comparator.comparing(a -> a.album.toLowerCase(Locale.ROOT)));
        ArrayList<CatalogEntry> out = new ArrayList<>();
        for (AlbumBucket b : buckets) out.add(CatalogEntry.album(b.album,b.artist,b.id,b.count));
        return out;
    }

    public static List<CatalogEntry> genreEntries(List<GenreInfo> genres) {
        ArrayList<CatalogEntry> out = new ArrayList<>();
        for (GenreInfo g : genres) out.add(CatalogEntry.genre(g.name,g.id,g.count));
        return out;
    }

    public static List<CatalogEntry> folderEntries(List<Track> tracks) {
        LinkedHashMap<String, Integer> counts = new LinkedHashMap<>();
        for (Track t : tracks) {
            String p = t.relativePath == null || t.relativePath.isEmpty() ? "Interna memorija" : t.relativePath;
            counts.put(p, counts.getOrDefault(p, 0) + 1);
        }
        ArrayList<String> paths = new ArrayList<>(counts.keySet());
        paths.sort(String.CASE_INSENSITIVE_ORDER);
        ArrayList<CatalogEntry> out = new ArrayList<>();
        for (String p : paths) out.add(CatalogEntry.folder(folderName(p), p, counts.get(p)));
        return out;
    }

    private static String folderName(String path) {
        if (path == null || path.isEmpty() || "Interna memorija".equals(path)) return "Interna memorija";
        String p = path.replace('\\','/');
        while (p.endsWith("/") && p.length() > 1) p = p.substring(0,p.length()-1);
        int ix = p.lastIndexOf('/');
        String n = ix >= 0 ? p.substring(ix+1) : p;
        n = TrackNameParser.cleanDisplayText(n);
        return n.trim().isEmpty() ? "Glazba" : n;
    }

    public static List<Track> filterByArtist(List<Track> tracks, String artist) {
        ArrayList<Track> out = new ArrayList<>();
        for (Track t : tracks) if (t.artist.equals(artist)) out.add(t);
        return out;
    }

    public static List<Track> filterByAlbumId(List<Track> tracks, long albumId) {
        ArrayList<Track> out = new ArrayList<>();
        for (Track t : tracks) if (t.albumId == albumId) out.add(t);
        return out;
    }

    public static List<Track> filterByFolder(List<Track> tracks, String path) {
        ArrayList<Track> out = new ArrayList<>();
        String target = path == null ? "" : path;
        for (Track t : tracks) {
            String p = t.relativePath == null || t.relativePath.isEmpty() ? "Interna memorija" : t.relativePath;
            if (p.equals(target)) out.add(t);
        }
        out.sort(Comparator.comparing(t -> t.title.toLowerCase(Locale.ROOT)));
        return out;
    }

    public static List<Track> tracksFromIds(List<Long> ids, Map<Long, Track> byId) {
        ArrayList<Track> out = new ArrayList<>();
        for (Long id : ids) { Track t = byId.get(id); if (t != null) out.add(t); }
        return out;
    }

    public static List<Track> recentlyAdded(List<Track> tracks, int max) {
        ArrayList<Track> copy = new ArrayList<>(tracks);
        copy.sort((a,b) -> Long.compare(b.dateAddedSec,a.dateAddedSec));
        if (copy.size() > max) return new ArrayList<>(copy.subList(0,max));
        return copy;
    }
}
