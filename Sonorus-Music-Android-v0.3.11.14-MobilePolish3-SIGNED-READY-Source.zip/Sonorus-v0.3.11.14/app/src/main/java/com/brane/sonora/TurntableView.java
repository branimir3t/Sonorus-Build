package com.brane.sonora;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/** Grounded three-quarter turntable base. Vinyl and tonearm are separate overlay views. */
public final class TurntableView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint accentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path deckPath = new Path();
    private final Path frontPath = new Path();

    public TurntableView(Context context) { this(context, null); }
    public TurntableView(Context context, AttributeSet attrs) { this(context, attrs, 0); }
    public TurntableView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        paint.setStrokeCap(Paint.Cap.ROUND);
        accentPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0f || h <= 0f) return;

        // Ground contact: a soft, wide shadow makes the object sit on the surface.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x4D000000);
        RectF groundShadow = new RectF(w * 0.08f, h * 0.76f, w * 0.94f, h * 0.96f);
        canvas.drawOval(groundShadow, paint);

        // Three-quarter deck top: rear edge is narrower than the front edge.
        deckPath.reset();
        deckPath.moveTo(w * 0.12f, h * 0.15f);
        deckPath.lineTo(w * 0.88f, h * 0.15f);
        deckPath.lineTo(w * 0.96f, h * 0.76f);
        deckPath.lineTo(w * 0.05f, h * 0.76f);
        deckPath.close();
        paint.setShader(new LinearGradient(0f, h * 0.12f, 0f, h * 0.78f,
                new int[]{0xFF2B211B, 0xFF17171B, 0xFF101115}, null, Shader.TileMode.CLAMP));
        canvas.drawPath(deckPath, paint);
        paint.setShader(null);

        // Front fascia adds real thickness instead of a floating flat card.
        frontPath.reset();
        frontPath.moveTo(w * 0.05f, h * 0.76f);
        frontPath.lineTo(w * 0.96f, h * 0.76f);
        frontPath.lineTo(w * 0.91f, h * 0.88f);
        frontPath.lineTo(w * 0.09f, h * 0.88f);
        frontPath.close();
        paint.setShader(new LinearGradient(0f, h * 0.75f, 0f, h * 0.90f,
                0xFF201712, 0xFF0D0E11, Shader.TileMode.CLAMP));
        canvas.drawPath(frontPath, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(0x80636A73);
        canvas.drawPath(deckPath, paint);
        accentPaint.setStyle(Paint.Style.STROKE);
        accentPaint.setStrokeWidth(dp(1.5f));
        accentPaint.setColor(0x99FF9A2E);
        canvas.drawLine(w * 0.10f, h * 0.79f, w * 0.92f, h * 0.79f, accentPaint);

        // Platter is deliberately elliptical to match the three-quarter perspective.
        RectF platterShadow = new RectF(w * 0.26f, h * 0.29f, w * 0.82f, h * 0.69f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x66000000);
        platterShadow.offset(0f, dp(6f));
        canvas.drawOval(platterShadow, paint);
        platterShadow.offset(0f, -dp(6f));
        paint.setColor(0xFF090A0C);
        canvas.drawOval(platterShadow, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(3f));
        paint.setColor(0xFF555A61);
        canvas.drawOval(platterShadow, paint);
        RectF platterInner = new RectF(w * 0.285f, h * 0.315f, w * 0.795f, h * 0.665f);
        paint.setStrokeWidth(dp(1f));
        paint.setColor(0x665D626A);
        canvas.drawOval(platterInner, paint);

        // Front feet + a physical control knob.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF090A0C);
        canvas.drawRoundRect(new RectF(w * 0.12f, h * 0.86f, w * 0.20f, h * 0.92f), dp(4f), dp(4f), paint);
        canvas.drawRoundRect(new RectF(w * 0.80f, h * 0.86f, w * 0.88f, h * 0.92f), dp(4f), dp(4f), paint);
        paint.setColor(0xFF15171B);
        canvas.drawCircle(w * 0.13f, h * 0.68f, dp(15f), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2f));
        paint.setColor(0xFF777D86);
        canvas.drawCircle(w * 0.13f, h * 0.68f, dp(15f), paint);
        accentPaint.setStyle(Paint.Style.FILL);
        accentPaint.setColor(ThemeSupport.accent(getContext()));
        canvas.drawCircle(w * 0.13f, h * 0.68f, dp(3f), accentPaint);
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
}
