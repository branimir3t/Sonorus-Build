package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public final class HiddenTrackStore {
    private static final String PREFS = "sonorus_hidden_tracks";
    private static final String KEY = "ids";
    private HiddenTrackStore() {}

    public static boolean isHidden(Context context, long id) {
        return prefs(context).getStringSet(KEY, java.util.Collections.emptySet()).contains(String.valueOf(id));
    }

    public static void hide(Context context, long id) {
        Set<String> ids = new HashSet<>(prefs(context).getStringSet(KEY, java.util.Collections.emptySet()));
        ids.add(String.valueOf(id));
        prefs(context).edit().putStringSet(KEY, ids).apply();
    }

    public static void clear(Context context) {
        prefs(context).edit().remove(KEY).apply();
    }

    public static int count(Context context) {
        return prefs(context).getStringSet(KEY, java.util.Collections.emptySet()).size();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
