package com.brane.sonora;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TrackNameParser {
    public static final class Parsed {
        public final String artist;
        public final String title;
        Parsed(String artist, String title) { this.artist = artist; this.title = title; }
    }

    private static final Pattern LEADING_NUMBER = Pattern.compile("^\\s*\\d{1,3}\\s*[-._)]\\s*");
    private TrackNameParser() {}

    public static Parsed parse(String mediaTitle, String displayName, String currentArtist) {
        String candidate = stripExtension(clean(mediaTitle));
        String fileCandidate = stripExtension(clean(displayName));
        boolean artistMissing = isUnknownArtist(currentArtist);

        String source = candidate;
        if (!containsSeparator(source) && containsSeparator(fileCandidate)) source = fileCandidate;
        source = LEADING_NUMBER.matcher(source).replaceFirst("").trim();

        String[] parts = splitArtistTitle(source);
        if (parts != null && validPart(parts[0]) && validPart(parts[1])) {
            if (artistMissing) return new Parsed(parts[0].trim(), parts[1].trim());
            String artistNorm = norm(currentArtist);
            if (norm(parts[0]).equals(artistNorm)) return new Parsed(clean(currentArtist), parts[1].trim());
        }
        return new Parsed(clean(currentArtist), candidate.isEmpty() ? fileCandidate : candidate);
    }

    public static boolean isUnknownArtist(String artist) {
        String a = norm(artist);
        return a.isEmpty() || a.equals("unknown") || a.equals("unknown artist") || a.equals("nepoznat izvodac") || a.equals("nepoznati izvodac") || a.equals("<unknown>") || a.equals("quick share");
    }

    public static String cleanDisplayPath(String path) {
        if (path == null || path.trim().isEmpty()) return "";
        String[] parts = path.replace('\\', '/').split("/");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            String cleaned = cleanDisplayText(part);
            if (cleaned.isEmpty()) continue;
            if (out.length() > 0) out.append(" / ");
            out.append(cleaned);
        }
        return out.toString();
    }

    private static String[] splitArtistTitle(String s) {
        if (s == null) return null;
        String[] seps = {" - ", " – ", " — "};
        for (String sep : seps) {
            int ix = s.indexOf(sep);
            if (ix > 0 && ix < s.length() - sep.length()) {
                String left = s.substring(0, ix).trim();
                String right = s.substring(ix + sep.length()).trim();
                if (!left.matches("\\d{1,3}") && validPart(left) && validPart(right)) return new String[]{left,right};
            }
        }
        return null;
    }

    private static boolean containsSeparator(String s) {
        if (s == null) return false;
        return s.contains(" - ") || s.contains(" – ") || s.contains(" — ");
    }

    private static boolean validPart(String s) { return s != null && s.trim().length() >= 1; }
    private static String stripExtension(String s) { return s == null ? "" : s.replaceFirst("(?i)\\.(mp3|flac|wav|aac|m4a|ogg|opus|wma|aiff?)$", "").trim(); }
    public static String cleanDisplayText(String s) {
        if (s == null) return "";
        String x = s.trim();
        if (x.equalsIgnoreCase("<unknown>")) return "";
        x = x.replaceAll("(?i)^\\s*quick\\s+share\\s*[-–—_:|]*\\s*", "");
        x = x.replaceAll("(?i)\\s*[-–—_:|]*\\s*quick\\s+share\\s*$", "");
        x = x.replaceAll("(?i)\\bquick\\s+share\\b", " ");
        x = x.replaceAll("\\s*[-–—_:|]\\s*[-–—_:|]+\\s*", " - ");
        return x.trim().replaceAll("^[-–—_:|\\s]+|[-–—_:|\\s]+$", "").trim();
    }
    private static String clean(String s) { return cleanDisplayText(s); }
    private static String norm(String s) { return clean(s).toLowerCase(Locale.ROOT).replace('č','c').replace('ć','c').replace('ž','z').replace('š','s').replace('đ','d'); }
}
