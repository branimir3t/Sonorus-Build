package com.brane.sonora;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaDescription;
import android.media.browse.MediaBrowser;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.service.media.MediaBrowserService;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

public final class PlaybackService extends MediaBrowserService implements AudioEngine.Listener {
    public static final String ACTION_TOGGLE = "com.brane.sonora.TOGGLE";
    public static final String ACTION_NEXT = "com.brane.sonora.NEXT";
    public static final String ACTION_PREV = "com.brane.sonora.PREV";
    public static final String ACTION_STOP = "com.brane.sonora.STOP";
    public static final String ACTION_RADIO_TOGGLE = "com.brane.sonora.RADIO_TOGGLE";
    private static final String AUTO_ROOT = "sonorus:auto:root";
    private static final String AUTO_LOCAL = "sonorus:auto:local";
    private static final String AUTO_RADIO = "sonorus:auto:radio:old_school";
    private static final String AUTO_TRACK_PREFIX = "sonorus:auto:track:";

    private static final String CHANNEL_ID = "sonora_playback";
    private static final int NOTIFICATION_ID = 4107;
    // Isti Old School Radio zapis koji koristi RadioFlow katalog.
    private static final String[] OLD_SCHOOL_STREAMS = {
            "https://s3.free-shoutcast.com/stream/18026",
            "http://s3.free-shoutcast.com:18026/;"
    };
    private static final String OLD_SCHOOL_METADATA_PROXY = "https://oldschool.com.hr/radioflow/metadata.php?id=old_school_radio";
    private static final String OLD_SCHOOL_METADATA_DIRECT = "http://s3.free-shoutcast.com:18026/currentsong?sid=1";
    private static final int RADIO_RECONNECT_ATTEMPTS = 3;
    private static final long RADIO_RECONNECT_DELAY_MS = 1800L;
    private static final long RADIO_PREPARE_TIMEOUT_MS = 15000L;
    private static final long RADIO_METADATA_REFRESH_MS = 8000L;
    private static final long PLAYBACK_HEALTH_INTERVAL_MS = 3000L;
    private static final long CATALOG_PREVIEW_PROGRESS_MS = 500L;

    public interface RadioListener {
        void onRadioStateChanged(boolean playing, boolean preparing, String nowPlaying, String statusText);
    }

    public interface CatalogPreviewListener {
        void onCatalogPreviewChanged(long trackId, boolean active);
        default void onCatalogPreviewProgress(long trackId, long positionMs, long durationMs) {}
    }

    public final class LocalBinder extends Binder {
        public PlaybackService getService() { return PlaybackService.this; }
        public AudioEngine getEngine() { return engine; }
    }

    private final IBinder binder = new LocalBinder();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<RadioListener> radioListeners = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<CatalogPreviewListener> catalogPreviewListeners = new CopyOnWriteArrayList<>();
    private final ExecutorService radioNetworkExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService browserExecutor = Executors.newSingleThreadExecutor();
    private volatile List<Track> autoLibrary = new ArrayList<>();
    private long lastAutoPlayCommandMs;

    private AudioEngine engine;
    private NotificationManager notificationManager;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private MediaSession mediaSession;
    private PowerManager.WakeLock playbackWakeLock;
    private MediaPlayer radioPlayer;
    private MediaPlayer catalogPreviewPlayer;

    private boolean foreground;
    private boolean resumeAfterFocusGain;
    private boolean pausedForFocusLoss;
    private boolean focusHeld;
    private boolean duckedForFocus;
    private boolean noisyReceiverRegistered;
    private boolean screenReceiverRegistered;
    private boolean playbackHealthArmed;

    private boolean radioRequested;
    private boolean radioPreparing;
    private boolean radioPlaying;
    private boolean resumeRadioAfterFocusGain;
    private int radioGeneration;
    private int radioStreamIndex;
    private int radioReconnectAttempt;
    private Runnable radioPrepareTimeout;
    private Runnable radioRecoveryTask;
    private String radioNowPlaying = "Old School Radio";
    private String radioStatusText = "RADIO";

    private long catalogPreviewTrackId = -1L;
    private int catalogPreviewGeneration;
    private boolean catalogPreviewPreparing;
    private boolean catalogPreviewPlaying;
    private boolean previewResumeEngineAfterStop;
    private long previewEnginePositionMs;
    private long previewEngineTrackId = -1L;
    private boolean previewResumeRadioAfterStop;
    private boolean previewResumeAfterFocusGain;

    private final Runnable metadataTicker = new Runnable() {
        @Override public void run() {
            if (!radioRequested) return;
            fetchRadioMetadataAsync();
            mainHandler.postDelayed(this, RADIO_METADATA_REFRESH_MS);
        }
    };

    private final Runnable catalogPreviewProgressTicker = new Runnable() {
        @Override public void run() {
            if (!isCatalogPreviewActive()) return;
            notifyCatalogPreviewProgress();
            mainHandler.postDelayed(this, CATALOG_PREVIEW_PROGRESS_MS);
        }
    };

    private final Runnable playbackHealthTicker = new Runnable() {
        @Override public void run() {
            playbackHealthArmed = false;
            if (radioRequested) {
                if (SonorusSettings.backgroundPlayback(PlaybackService.this)) {
                    acquirePlaybackWakeLock();
                    ensureForeground();
                }
                if (radioPlaying && radioPlayer != null && focusHeld) {
                    if (!duckedForFocus) setRadioVolume(1f);
                    boolean active = true;
                    try { active = radioPlayer.isPlaying(); } catch (Exception ignored) { active = false; }
                    if (!active) {
                        radioPlaying = false;
                        radioPreparing = false;
                        scheduleRadioRecovery(radioGeneration, Math.max(0, radioStreamIndex));
                    }
                } else if (focusHeld && !radioPreparing && !radioPlaying && radioPlayer == null && radioRecoveryTask == null) {
                    scheduleRadioRecovery(radioGeneration, Math.max(0, radioStreamIndex));
                }
            } else if (engine != null && engine.isPlaying()) {
                if (SonorusSettings.backgroundPlayback(PlaybackService.this)) {
                    acquirePlaybackWakeLock();
                    ensureForeground();
                }
                if (focusHeld && !duckedForFocus) {
                    engine.setMasterVolume(1f);
                    engine.reassertOutputMix();
                    engine.verifyPlaybackActive();
                }
            }
            if (radioRequested || (engine != null && engine.isPlaying())) armPlaybackHealthTicker();
        }
    };

    private void armPlaybackHealthTicker() {
        if (playbackHealthArmed) return;
        playbackHealthArmed = true;
        mainHandler.postDelayed(playbackHealthTicker, PLAYBACK_HEALTH_INTERVAL_MS);
    }

    private void disarmPlaybackHealthTickerIfIdle() {
        if (radioRequested || (engine != null && engine.isPlaying())) return;
        playbackHealthArmed = false;
        mainHandler.removeCallbacks(playbackHealthTicker);
    }

    private final AudioManager.OnAudioFocusChangeListener focusListener = focus -> {
        if (engine == null) return;
        if (isCatalogPreviewActive()) {
            handleCatalogPreviewFocusChange(focus);
            return;
        }
        if (radioRequested) {
            handleRadioFocusChange(focus);
            return;
        }
        switch (focus) {
            case AudioManager.AUDIOFOCUS_GAIN:
                focusHeld = true;
                duckedForFocus = false;
                engine.setMasterVolume(1f);
                engine.reassertOutputMix();
                boolean shouldResume = resumeAfterFocusGain;
                resumeAfterFocusGain = false;
                pausedForFocusLoss = false;
                if (shouldResume) engine.resume();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                focusHeld = true;
                duckedForFocus = true;
                engine.setMasterVolume(0.40f);
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                focusHeld = false;
                duckedForFocus = false;
                resumeAfterFocusGain = engine.isPlaying();
                pausedForFocusLoss = true;
                engine.pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                focusHeld = false;
                duckedForFocus = false;
                resumeAfterFocusGain = false;
                pausedForFocusLoss = false;
                engine.pause();
                break;
        }
    };

    private final BroadcastReceiver noisyReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())) return;
            if (isCatalogPreviewActive()) {
                stopCatalogPreviewInternal(false);
                return;
            }
            if (radioRequested) stopOldSchoolRadio();
            else if (engine != null) engine.pause();
        }
    };

    private final BroadcastReceiver screenStateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!SonorusSettings.backgroundPlayback(PlaybackService.this)) return;
            if (radioRequested) {
                if (focusHeld) setRadioVolume(duckedForFocus ? 0.40f : 1f);
                acquirePlaybackWakeLock();
                ensureForeground();
                return;
            }
            if (engine == null || !engine.isPlaying()) return;
            if (focusHeld && !duckedForFocus) {
                engine.setMasterVolume(1f);
                engine.reassertOutputMix();
                engine.verifyPlaybackActive();
            }
            acquirePlaybackWakeLock();
            ensureForeground();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        engine = new AudioEngine(this);
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            playbackWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Sonorus:Playback");
            playbackWakeLock.setReferenceCounted(false);
        }
        createNotificationChannel();
        createMediaSession();
        setSessionToken(mediaSession.getSessionToken());
        registerNoisyReceiver();
        registerScreenStateReceiver();
        engine.addListener(this);
    }

    @Override public IBinder onBind(Intent intent) {
        if (intent != null && "android.media.browse.MediaBrowserService".equals(intent.getAction())) return super.onBind(intent);
        if (android.os.Binder.getCallingUid() == android.os.Process.myUid()) return binder;
        return null;
    }

    @Override public BrowserRoot onGetRoot(String clientPackageName, int clientUid, Bundle rootHints) {
        return new BrowserRoot(AUTO_ROOT, null);
    }

    @Override public void onLoadChildren(String parentId, Result<List<MediaBrowser.MediaItem>> result) {
        if (AUTO_ROOT.equals(parentId)) {
            ArrayList<MediaBrowser.MediaItem> items = new ArrayList<>();
            items.add(new MediaBrowser.MediaItem(new MediaDescription.Builder()
                    .setMediaId(AUTO_LOCAL)
                    .setTitle("Lokalna glazba")
                    .setSubtitle("Pjesme spremljene na uređaju")
                    .build(), MediaBrowser.MediaItem.FLAG_BROWSABLE));
            items.add(new MediaBrowser.MediaItem(new MediaDescription.Builder()
                    .setMediaId(AUTO_RADIO)
                    .setTitle("Old School Radio")
                    .setSubtitle("Dobre, stare stvari.")
                    .build(), MediaBrowser.MediaItem.FLAG_PLAYABLE));
            result.sendResult(items);
            return;
        }
        if (!AUTO_LOCAL.equals(parentId)) {
            result.sendResult(new ArrayList<>());
            return;
        }
        result.detach();
        browserExecutor.execute(() -> {
            List<Track> tracks = queryVisibleAutoTracks();
            autoLibrary = new ArrayList<>(tracks);
            ArrayList<MediaBrowser.MediaItem> items = new ArrayList<>();
            int limit = Math.min(autoLibrary.size(), 500);
            for (int i = 0; i < limit; i++) {
                Track t = autoLibrary.get(i);
                MediaDescription description = new MediaDescription.Builder()
                        .setMediaId(AUTO_TRACK_PREFIX + t.id)
                        .setTitle(t.title)
                        .setSubtitle(t.artist)
                        .build();
                items.add(new MediaBrowser.MediaItem(description, MediaBrowser.MediaItem.FLAG_PLAYABLE));
            }
            result.sendResult(items);
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_RADIO_TOGGLE:
                    toggleOldSchoolRadio();
                    break;
                case ACTION_TOGGLE:
                    if (radioRequested) stopOldSchoolRadio();
                    else if (engine.isPlaying()) engine.pause();
                    else if (prepareForPlayback()) engine.resume();
                    break;
                case ACTION_NEXT:
                    if (!radioRequested && prepareForPlayback()) engine.next();
                    break;
                case ACTION_PREV:
                    if (!radioRequested && prepareForPlayback()) engine.previous();
                    break;
                case ACTION_STOP:
                    stopRadioInternal(false);
                    resumeAfterFocusGain = false;
                    pausedForFocusLoss = false;
                    engine.pause();
                    abandonAudioFocus();
                    releasePlaybackWakeLock();
                    stopForeground(STOP_FOREGROUND_REMOVE);
                    foreground = false;
                    stopSelf();
                    break;
            }
        }
        if (SonorusSettings.backgroundPlayback(this) && (radioRequested || (engine != null && engine.isPlaying()))) ensureForeground();
        return SonorusSettings.backgroundPlayback(this) ? START_STICKY : START_NOT_STICKY;
    }

    public void addCatalogPreviewListener(CatalogPreviewListener listener) {
        if (listener == null) return;
        catalogPreviewListeners.addIfAbsent(listener);
        listener.onCatalogPreviewChanged(catalogPreviewTrackId, isCatalogPreviewActive());
        if (isCatalogPreviewActive()) {
            long[] progress = currentCatalogPreviewProgress();
            listener.onCatalogPreviewProgress(catalogPreviewTrackId, progress[0], progress[1]);
        }
    }

    public void removeCatalogPreviewListener(CatalogPreviewListener listener) {
        catalogPreviewListeners.remove(listener);
    }

    public long getCatalogPreviewTrackId() {
        return isCatalogPreviewActive() ? catalogPreviewTrackId : -1L;
    }

    public boolean isCatalogPreviewActive() {
        return catalogPreviewPlayer != null || catalogPreviewPreparing || catalogPreviewPlaying;
    }

    public void seekCatalogPreview(long trackId, long positionMs) {
        MediaPlayer p = catalogPreviewPlayer;
        if (p == null || catalogPreviewPreparing || trackId != catalogPreviewTrackId) return;
        try {
            long duration = Math.max(0L, p.getDuration());
            long target = Math.max(0L, duration > 0L ? Math.min(positionMs, duration) : positionMs);
            p.seekTo((int)Math.min(Integer.MAX_VALUE, target));
            notifyCatalogPreviewProgress();
        } catch (Exception ignored) {}
    }

    public void startCatalogPreview(Track track) {
        if (track == null || track.uri == null) return;
        if (isCatalogPreviewActive() && catalogPreviewTrackId == track.id) {
            stopCatalogPreview();
            return;
        }

        boolean switchingPreview = isCatalogPreviewActive();
        if (!switchingPreview) {
            Track current = engine == null ? null : engine.getCurrentTrack();
            previewResumeEngineAfterStop = engine != null && engine.isPlaying();
            previewEnginePositionMs = engine == null ? 0L : engine.getPosition();
            previewEngineTrackId = current == null ? -1L : current.id;
            previewResumeRadioAfterStop = radioRequested && radioPlaying;

            if (previewResumeRadioAfterStop && radioPlayer != null) {
                try { radioPlayer.pause(); } catch (Exception ignored) {}
                radioPlaying = false;
                radioStatusText = "PREVIEW";
                notifyRadioState();
                updateSessionState();
            }
            if (previewResumeEngineAfterStop && engine != null) engine.pause();
        } else {
            releaseCatalogPreviewPlayer();
            catalogPreviewTrackId = -1L;
            catalogPreviewPreparing = false;
            catalogPreviewPlaying = false;
        }

        if (!requestAudioFocus()) {
            catalogPreviewTrackId = -1L;
            catalogPreviewPreparing = false;
            catalogPreviewPlaying = false;
            notifyCatalogPreviewState();
            restorePlaybackAfterCatalogPreview();
            return;
        }

        catalogPreviewGeneration++;
        final int generation = catalogPreviewGeneration;
        catalogPreviewTrackId = track.id;
        catalogPreviewPreparing = true;
        catalogPreviewPlaying = false;
        previewResumeAfterFocusGain = false;
        notifyCatalogPreviewState();
        acquirePlaybackWakeLock();

        try {
            MediaPlayer player = new MediaPlayer();
            catalogPreviewPlayer = player;
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            try { player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK); } catch (Exception ignored) {}
            player.setDataSource(this, track.uri);
            player.setOnPreparedListener(mp -> {
                if (generation != catalogPreviewGeneration || mp != catalogPreviewPlayer) return;
                catalogPreviewPreparing = false;
                try {
                    float volume = duckedForFocus ? 0.40f : 1f;
                    mp.setVolume(volume, volume);
                    mp.start();
                    catalogPreviewPlaying = true;
                    startCatalogPreviewProgressTicker();
                    notifyCatalogPreviewProgress();
                } catch (Exception e) {
                    stopCatalogPreview();
                    return;
                }
                notifyCatalogPreviewState();
            });
            player.setOnCompletionListener(mp -> {
                if (generation == catalogPreviewGeneration && mp == catalogPreviewPlayer) stopCatalogPreview();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                if (generation == catalogPreviewGeneration && mp == catalogPreviewPlayer) stopCatalogPreview();
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            stopCatalogPreview();
        }
    }

    public void stopCatalogPreview() {
        stopCatalogPreviewInternal(true);
    }

    private void stopCatalogPreviewInternal(boolean restoreUnderlying) {
        if (!isCatalogPreviewActive() && catalogPreviewTrackId < 0L) return;
        catalogPreviewGeneration++;
        stopCatalogPreviewProgressTicker();
        releaseCatalogPreviewPlayer();
        catalogPreviewTrackId = -1L;
        catalogPreviewPreparing = false;
        catalogPreviewPlaying = false;
        previewResumeAfterFocusGain = false;
        notifyCatalogPreviewState();

        if (restoreUnderlying) restorePlaybackAfterCatalogPreview();
        else clearCatalogPreviewRestoreState();

        if (!radioPlaying && (engine == null || !engine.isPlaying())) {
            abandonAudioFocus();
            releasePlaybackWakeLock();
        }
    }

    private void releaseCatalogPreviewPlayer() {
        MediaPlayer p = catalogPreviewPlayer;
        catalogPreviewPlayer = null;
        if (p == null) return;
        try { p.setOnPreparedListener(null); p.setOnCompletionListener(null); p.setOnErrorListener(null); } catch (Exception ignored) {}
        try { p.stop(); } catch (Exception ignored) {}
        try { p.release(); } catch (Exception ignored) {}
    }

    private void restorePlaybackAfterCatalogPreview() {
        boolean resumeRadio = previewResumeRadioAfterStop;
        boolean resumeEngine = previewResumeEngineAfterStop;
        long savedPosition = previewEnginePositionMs;
        long savedTrackId = previewEngineTrackId;
        clearCatalogPreviewRestoreState();

        if (resumeRadio && radioRequested && radioPlayer != null) {
            if (!requestAudioFocus()) return;
            try {
                radioPlayer.setVolume(1f, 1f);
                radioPlayer.start();
                radioPlaying = true;
                radioStatusText = "UŽIVO";
                acquirePlaybackWakeLock();
                notifyRadioState();
                updateSessionState();
            } catch (Exception ignored) {}
            return;
        }

        Track current = engine == null ? null : engine.getCurrentTrack();
        if (resumeEngine && engine != null && current != null && current.id == savedTrackId) {
            engine.seekTo(savedPosition);
        }
    }

    private void clearCatalogPreviewRestoreState() {
        previewResumeEngineAfterStop = false;
        previewEnginePositionMs = 0L;
        previewEngineTrackId = -1L;
        previewResumeRadioAfterStop = false;
    }

    private void startCatalogPreviewProgressTicker() {
        mainHandler.removeCallbacks(catalogPreviewProgressTicker);
        mainHandler.post(catalogPreviewProgressTicker);
    }

    private void stopCatalogPreviewProgressTicker() {
        mainHandler.removeCallbacks(catalogPreviewProgressTicker);
    }

    private long[] currentCatalogPreviewProgress() {
        long position = 0L;
        long duration = 0L;
        MediaPlayer p = catalogPreviewPlayer;
        if (p != null && !catalogPreviewPreparing) {
            try { position = Math.max(0L, p.getCurrentPosition()); } catch (Exception ignored) {}
            try { duration = Math.max(0L, p.getDuration()); } catch (Exception ignored) {}
        }
        if (duration > 0L) position = Math.min(position, duration);
        return new long[]{position, duration};
    }

    private void notifyCatalogPreviewProgress() {
        if (!isCatalogPreviewActive() || catalogPreviewTrackId < 0L) return;
        long[] progress = currentCatalogPreviewProgress();
        for (CatalogPreviewListener listener : catalogPreviewListeners) {
            try { listener.onCatalogPreviewProgress(catalogPreviewTrackId, progress[0], progress[1]); } catch (Exception ignored) {}
        }
    }

    private void notifyCatalogPreviewState() {
        boolean active = isCatalogPreviewActive();
        long id = active ? catalogPreviewTrackId : -1L;
        for (CatalogPreviewListener listener : catalogPreviewListeners) {
            try { listener.onCatalogPreviewChanged(id, active); } catch (Exception ignored) {}
        }
    }

    private void setCatalogPreviewVolume(float volume) {
        MediaPlayer p = catalogPreviewPlayer;
        if (p == null) return;
        try { p.setVolume(volume, volume); } catch (Exception ignored) {}
    }

    private void handleCatalogPreviewFocusChange(int focus) {
        switch (focus) {
            case AudioManager.AUDIOFOCUS_GAIN:
                focusHeld = true;
                duckedForFocus = false;
                setCatalogPreviewVolume(1f);
                if (previewResumeAfterFocusGain && catalogPreviewPlayer != null && !catalogPreviewPreparing) {
                    try { catalogPreviewPlayer.start(); catalogPreviewPlaying = true; } catch (Exception ignored) {}
                }
                previewResumeAfterFocusGain = false;
                notifyCatalogPreviewState();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                focusHeld = true;
                duckedForFocus = true;
                setCatalogPreviewVolume(0.40f);
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                focusHeld = false;
                duckedForFocus = false;
                previewResumeAfterFocusGain = catalogPreviewPlaying;
                if (catalogPreviewPlayer != null && catalogPreviewPlaying) {
                    try { catalogPreviewPlayer.pause(); } catch (Exception ignored) {}
                    catalogPreviewPlaying = false;
                    notifyCatalogPreviewState();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                focusHeld = false;
                duckedForFocus = false;
                previewResumeAfterFocusGain = false;
                stopCatalogPreviewInternal(false);
                break;
        }
    }

    public void addRadioListener(RadioListener listener) {
        if (listener == null) return;
        radioListeners.addIfAbsent(listener);
        listener.onRadioStateChanged(radioPlaying, radioPreparing, radioNowPlaying, radioStatusText);
    }

    public void removeRadioListener(RadioListener listener) { radioListeners.remove(listener); }
    public boolean isOldSchoolRadioPlaying() { return radioPlaying; }
    public boolean isOldSchoolRadioActive() { return radioRequested; }

    public void toggleOldSchoolRadio() {
        if (radioRequested) stopOldSchoolRadio(); else playOldSchoolRadio();
    }

    public void playOldSchoolRadio() {
        if (radioRequested) return;
        cancelRadioRecovery();
        radioRequested = true;
        radioPreparing = false;
        radioPlaying = false;
        radioStreamIndex = 0;
        radioReconnectAttempt = 0;
        radioNowPlaying = "Old School Radio";
        radioStatusText = "SPAJANJE…";
        resumeRadioAfterFocusGain = false;
        if (engine != null && engine.isPlaying()) engine.pause();
        if (!requestAudioFocus()) {
            radioRequested = false;
            radioStatusText = "AUDIO FOKUS";
            notifyRadioState();
            return;
        }
        acquirePlaybackWakeLock();
        armPlaybackHealthTicker();
        radioGeneration++;
        updateSessionQueue();
        // RadioFlow dohvaća metadata i prije Play; UI zato može odmah pokazati
        // stvarnu pjesmu dok se audio stream još spaja.
        fetchRadioMetadataAsync();
        startRadioPlayerAttempt(radioGeneration, 0);
    }

    public void stopOldSchoolRadio() {
        stopRadioInternal(true);
        updateSessionQueue();
        updateSessionMetadata();
        updateSessionState();
        if (engine == null || !engine.isPlaying()) {
            if (foreground) {
                stopForeground(STOP_FOREGROUND_REMOVE);
                foreground = false;
            }
            stopSelf();
        } else updateNotification();
    }

    private void startRadioPlayerAttempt(final int generation, final int streamIndex) {
        if (!radioRequested || generation != radioGeneration) return;
        cancelRadioRecovery();
        radioStreamIndex = Math.max(0, Math.min(streamIndex, OLD_SCHOOL_STREAMS.length - 1));
        cancelRadioPrepareTimeout();
        releaseRadioPlayer();
        radioPreparing = true;
        radioPlaying = false;
        radioStatusText = radioReconnectAttempt == 0 ? "SPAJANJE…" : "PONOVNO SPAJANJE…";
        notifyRadioState();
        ensureForeground();

        try {
            MediaPlayer player = new MediaPlayer();
            radioPlayer = player;
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            try { player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK); } catch (Exception ignored) {}

            // RadioFlow koristi izravni streamUrl. Bez ICY request-headera na audio
            // konekciji jer dio SHOUTcast/Android kombinacija tada ne pripremi MediaPlayer.
            player.setDataSource(OLD_SCHOOL_STREAMS[radioStreamIndex]);

            player.setOnPreparedListener(mp -> {
                cancelRadioPrepareTimeout();
                if (!radioRequested || generation != radioGeneration || mp != radioPlayer) return;
                radioPreparing = false;
                try {
                    float volume = duckedForFocus ? 0.40f : 1f;
                    mp.setVolume(volume, volume);
                    mp.start();
                    radioPlaying = true;
                    radioReconnectAttempt = 0;
                    radioStatusText = "UŽIVO";
                    acquirePlaybackWakeLock();
                    ensureForeground();
                    startMetadataTicker();
                    fetchRadioMetadataAsync();
                } catch (Exception e) {
                    radioPlaying = false;
                    scheduleRadioRecovery(generation, radioStreamIndex);
                    return;
                }
                notifyRadioState();
                updateSessionMetadata();
                updateSessionState();
                updateNotification();
            });

            player.setOnErrorListener((mp, what, extra) -> {
                cancelRadioPrepareTimeout();
                if (generation != radioGeneration) return true;
                radioPreparing = false;
                radioPlaying = false;
                scheduleRadioRecovery(generation, radioStreamIndex);
                return true;
            });

            player.setOnCompletionListener(mp -> {
                cancelRadioPrepareTimeout();
                if (!radioRequested || generation != radioGeneration) return;
                radioPlaying = false;
                radioPreparing = false;
                scheduleRadioRecovery(generation, radioStreamIndex);
            });

            final MediaPlayer expectedPlayer = player;
            radioPrepareTimeout = () -> {
                if (!radioRequested || generation != radioGeneration || !radioPreparing || radioPlayer != expectedPlayer) return;
                radioPreparing = false;
                radioPlaying = false;
                releaseRadioPlayer();
                scheduleRadioRecovery(generation, radioStreamIndex);
            };
            mainHandler.postDelayed(radioPrepareTimeout, RADIO_PREPARE_TIMEOUT_MS);
            player.prepareAsync();
        } catch (Exception e) {
            cancelRadioPrepareTimeout();
            radioPreparing = false;
            radioPlaying = false;
            scheduleRadioRecovery(generation, radioStreamIndex);
        }
    }

    private void scheduleRadioRecovery(int generation, int failedStreamIndex) {
        cancelRadioPrepareTimeout();
        releaseRadioPlayer();
        if (!radioRequested || generation != radioGeneration) return;

        int nextStream = failedStreamIndex + 1;
        if (nextStream < OLD_SCHOOL_STREAMS.length) {
            radioStatusText = "REZERVNI STREAM…";
            notifyRadioState();
            scheduleRadioRecoveryTask(generation, nextStream);
            return;
        }

        if (radioReconnectAttempt < RADIO_RECONNECT_ATTEMPTS) {
            radioReconnectAttempt++;
            final int attempt = radioReconnectAttempt;
            radioStatusText = "PONOVNO " + attempt + "/" + RADIO_RECONNECT_ATTEMPTS;
            notifyRadioState();
            scheduleRadioRecoveryTask(generation, 0);
            return;
        }

        radioRequested = false;
        radioPreparing = false;
        radioPlaying = false;
        radioStatusText = "NIJE DOSTUPNO";
        radioNowPlaying = "Old School Radio";
        stopMetadataTicker();
        notifyRadioState();
        abandonAudioFocus();
        releasePlaybackWakeLock();
        updateSessionState();
        if (foreground && (engine == null || !engine.isPlaying())) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            foreground = false;
        }
        if (engine == null || !engine.isPlaying()) stopSelf();
    }

    private void scheduleRadioRecoveryTask(final int generation, final int streamIndex) {
        cancelRadioRecovery();
        radioRecoveryTask = () -> {
            radioRecoveryTask = null;
            if (radioRequested && generation == radioGeneration) startRadioPlayerAttempt(generation, streamIndex);
        };
        mainHandler.postDelayed(radioRecoveryTask, RADIO_RECONNECT_DELAY_MS);
    }

    private void cancelRadioRecovery() {
        if (radioRecoveryTask != null) {
            mainHandler.removeCallbacks(radioRecoveryTask);
            radioRecoveryTask = null;
        }
    }

    private void cancelRadioPrepareTimeout() {
        if (radioPrepareTimeout != null) {
            mainHandler.removeCallbacks(radioPrepareTimeout);
            radioPrepareTimeout = null;
        }
    }

    private void startMetadataTicker() {
        mainHandler.removeCallbacks(metadataTicker);
        mainHandler.post(metadataTicker);
    }

    private void stopMetadataTicker() { mainHandler.removeCallbacks(metadataTicker); }

    private void fetchRadioMetadataAsync() {
        final int generation = radioGeneration;
        radioNetworkExecutor.execute(() -> {
            String song = fetchCurrentSong();
            if (song == null || song.isEmpty()) return;
            mainHandler.post(() -> {
                if (!radioRequested || generation != radioGeneration) return;
                boolean changed = !song.equals(radioNowPlaying);
                radioNowPlaying = song;
                // Ponovno pošalji stanje i kada se pjesma nije promijenila. To drži
                // tablet/wide radio karticu sinkroniziranom nakon rotacije ili reconnecta.
                notifyRadioState();
                if (changed) updateSessionMetadata();
                updateNotification();
            });
        });
    }

    private String fetchCurrentSong() {
        String proxy = httpGetText(OLD_SCHOOL_METADATA_PROXY, 5500, 6500);
        String parsed = parseRadioFlowMetadata(proxy);
        if (isUsefulRadioMetadata(parsed)) return TrackNameParser.cleanDisplayText(parsed);

        String direct = httpGetText(OLD_SCHOOL_METADATA_DIRECT, 4500, 5000);
        if (direct == null) return null;
        direct = direct.replaceAll("<[^>]+>", " ")
                .replace("&amp;", "&")
                .replace("&#39;", "'")
                .replace("&quot;", "\"")
                .replaceAll("\\s+", " ").trim();
        return isUsefulRadioMetadata(direct) ? TrackNameParser.cleanDisplayText(direct) : null;
    }

    private String httpGetText(String address, int connectTimeout, int readTimeout) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(connectTimeout);
            c.setReadTimeout(readTimeout);
            c.setInstanceFollowRedirects(true);
            c.setUseCaches(false);
            c.setRequestProperty("User-Agent", "Sonorus/0.3.0 Android");
            c.setRequestProperty("Accept", "application/json,text/plain,*/*");
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) return null;
            try (InputStream in = c.getInputStream(); BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                StringBuilder b = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null && b.length() < 16384) b.append(line).append(' ');
                return b.toString().trim();
            }
        } catch (Exception ignored) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private String parseRadioFlowMetadata(String raw) {
        if (raw == null || raw.trim().isEmpty()) return null;
        String s = raw.trim();
        if (!s.startsWith("{") && !s.startsWith("[")) {
            s = s.replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").trim();
            return isUsefulRadioMetadata(s) ? TrackNameParser.cleanDisplayText(s) : null;
        }
        try {
            Object root = s.startsWith("[") ? new JSONArray(s) : new JSONObject(s);
            String value = extractRadioMetadata(root);
            return isUsefulRadioMetadata(value) ? TrackNameParser.cleanDisplayText(value) : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    private String extractRadioMetadata(Object node) {
        if (node instanceof JSONObject) return findMetadataString((JSONObject) node);
        if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) {
                String found = extractRadioMetadata(arr.opt(i));
                if (isUsefulRadioMetadata(found)) return found;
            }
        } else if (node instanceof String) {
            String value = TrackNameParser.cleanDisplayText(String.valueOf(node));
            if (isUsefulRadioMetadata(value)) return value;
        }
        return null;
    }

    private String findMetadataString(JSONObject o) {
        if (o == null) return null;
        String artist = firstJsonString(o, "artist", "performer", "author", "artist_name");
        String title = firstJsonString(o, "title", "song", "track", "currentSong", "current_song", "nowPlaying", "now_playing", "streamTitle", "stream_title", "songtitle");
        if (isUsefulRadioMetadata(artist) && isUsefulRadioMetadata(title) && !title.toLowerCase().contains(artist.toLowerCase())) {
            return artist.trim() + " - " + title.trim();
        }
        if (isUsefulRadioMetadata(title)) return title.trim();
        String[] nested = {"data", "metadata", "nowPlaying", "now_playing", "current", "result", "items", "trackInfo"};
        for (String key : nested) {
            try {
                String found = extractRadioMetadata(o.opt(key));
                if (isUsefulRadioMetadata(found)) return found;
            } catch (Exception ignored) {}
        }
        String fallback = firstJsonString(o, "text", "value", "name", "display", "label", "current");
        return isUsefulRadioMetadata(fallback) ? fallback.trim() : null;
    }

    private String firstJsonString(JSONObject o, String... keys) {
        for (String key : keys) {
            String v = o.optString(key, "").trim();
            if (isUsefulRadioMetadata(v)) return v;
        }
        return null;
    }

    private boolean isUsefulRadioMetadata(String value) {
        if (value == null) return false;
        String v = value.replaceAll("\\s+", " ").trim();
        if (v.length() < 2) return false;
        String lower = v.toLowerCase();
        return !lower.equals("null")
                && !lower.equals("unknown")
                && !lower.equals("nema podataka")
                && !lower.equals("old school radio")
                && !lower.equals("radio")
                && !lower.equals("uživo")
                && !lower.equals("uzivo");
    }

    private void stopRadioInternal(boolean releaseFocusIfIdle) {
        radioRequested = false;
        radioPreparing = false;
        radioPlaying = false;
        resumeRadioAfterFocusGain = false;
        radioGeneration++;
        radioStatusText = "RADIO";
        stopMetadataTicker();
        cancelRadioPrepareTimeout();
        cancelRadioRecovery();
        releaseRadioPlayer();
        notifyRadioState();
        if (releaseFocusIfIdle && (engine == null || !engine.isPlaying())) {
            abandonAudioFocus();
            releasePlaybackWakeLock();
        }
        disarmPlaybackHealthTickerIfIdle();
    }

    private void releaseRadioPlayer() {
        MediaPlayer p = radioPlayer;
        radioPlayer = null;
        if (p == null) return;
        try { p.setOnPreparedListener(null); p.setOnErrorListener(null); p.setOnCompletionListener(null); } catch (Exception ignored) {}
        try { p.stop(); } catch (Exception ignored) {}
        try { p.release(); } catch (Exception ignored) {}
    }

    private void setRadioVolume(float volume) {
        MediaPlayer p = radioPlayer;
        if (p == null) return;
        try { p.setVolume(volume, volume); } catch (Exception ignored) {}
    }

    private void handleRadioFocusChange(int focus) {
        switch (focus) {
            case AudioManager.AUDIOFOCUS_GAIN:
                focusHeld = true;
                duckedForFocus = false;
                setRadioVolume(1f);
                if (resumeRadioAfterFocusGain && radioPlayer != null && !radioPreparing) {
                    try { radioPlayer.start(); radioPlaying = true; radioStatusText = "UŽIVO"; } catch (Exception ignored) {}
                }
                resumeRadioAfterFocusGain = false;
                notifyRadioState();
                updateSessionState();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                focusHeld = true;
                duckedForFocus = true;
                setRadioVolume(0.40f);
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                focusHeld = false;
                duckedForFocus = false;
                resumeRadioAfterFocusGain = radioPlaying;
                if (radioPlayer != null && radioPlaying) {
                    try { radioPlayer.pause(); } catch (Exception ignored) {}
                    radioPlaying = false;
                    radioStatusText = "PAUZA AUDIO FOKUS";
                }
                notifyRadioState();
                updateSessionState();
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                focusHeld = false;
                duckedForFocus = false;
                resumeRadioAfterFocusGain = false;
                stopOldSchoolRadio();
                break;
        }
    }

    private void notifyRadioState() {
        for (RadioListener listener : radioListeners) {
            try { listener.onRadioStateChanged(radioPlaying, radioPreparing, radioNowPlaying, radioStatusText); } catch (Exception ignored) {}
        }
    }

    private void createNotificationChannel() {
        if (notificationManager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Sonorus reprodukcija", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Kontrole reprodukcije glazbe");
        channel.setShowBadge(false);
        notificationManager.createNotificationChannel(channel);
    }

    private List<Track> queryVisibleAutoTracks() {
        List<Track> all = MediaLibrary.queryTracks(this);
        ArrayList<Track> visible = new ArrayList<>();
        if (all != null) for (Track t : all) if (!HiddenTrackStore.isHidden(this, t.id)) visible.add(t);
        return visible;
    }

    private List<Track> ensureAutoLibrary() {
        List<Track> cached = autoLibrary;
        if (cached != null && !cached.isEmpty()) return cached;
        autoLibrary = queryVisibleAutoTracks();
        return autoLibrary;
    }

    private void playFromAutomotiveMediaId(String mediaId) {
        if (mediaId == null) return;
        if (AUTO_RADIO.equals(mediaId)) {
            if (!radioRequested) playOldSchoolRadio();
            else if (!radioPlaying && !radioPreparing) {
                stopRadioInternal(false);
                playOldSchoolRadio();
            }
            return;
        }
        if (!mediaId.startsWith(AUTO_TRACK_PREFIX)) return;
        long id;
        try { id = Long.parseLong(mediaId.substring(AUTO_TRACK_PREFIX.length())); }
        catch (Exception ignored) { return; }
        List<Track> tracks = ensureAutoLibrary();
        int index = -1;
        for (int i=0;i<tracks.size();i++) if (tracks.get(i).id == id) { index = i; break; }
        if (index < 0 || !prepareForPlayback()) return;
        engine.setQueue(tracks, false);
        engine.playIndex(index);
    }

    private void playFromAutomotiveSearch(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (q.contains("old school") || q.equals("radio") || q.contains("old school radio")) {
            if (!radioRequested) playOldSchoolRadio();
            return;
        }
        List<Track> tracks = ensureAutoLibrary();
        if (tracks.isEmpty()) return;
        int best = -1;
        for (int i=0;i<tracks.size();i++) {
            Track t = tracks.get(i);
            String title = t.title == null ? "" : t.title.toLowerCase(Locale.ROOT);
            String artist = t.artist == null ? "" : t.artist.toLowerCase(Locale.ROOT);
            if (q.isEmpty() || title.contains(q) || artist.contains(q) || (artist + " " + title).contains(q)) { best = i; break; }
        }
        if (best < 0 || !prepareForPlayback()) return;
        engine.setQueue(tracks, false);
        engine.playIndex(best);
    }

    private void createMediaSession() {
        mediaSession = new MediaSession(this, "SonorusSession");
        mediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        mediaSession.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() {
                long now = android.os.SystemClock.elapsedRealtime();
                if (now - lastAutoPlayCommandMs < 220L && (radioPlaying || (engine != null && engine.isPlaying()))) return;
                lastAutoPlayCommandMs = now;
                if (radioRequested) {
                    if (radioPreparing) return;
                    if (!requestAudioFocus()) return;
                    if (radioPlayer != null) {
                        try {
                            radioPlayer.setVolume(1f, 1f);
                            radioPlayer.start();
                            radioPlaying = true;
                            radioStatusText = "UŽIVO";
                            resumeRadioAfterFocusGain = false;
                            acquirePlaybackWakeLock();
                            ensureForeground();
                            notifyRadioState();
                            updateSessionState();
                        } catch (Exception ignored) { startRadioPlayerAttempt(radioGeneration, Math.max(0, radioStreamIndex)); }
                    } else startRadioPlayerAttempt(radioGeneration, Math.max(0, radioStreamIndex));
                } else if (prepareForPlayback()) engine.resume();
            }
            @Override public void onPlayFromMediaId(String mediaId, Bundle extras) {
                playFromAutomotiveMediaId(mediaId);
            }
            @Override public void onPlayFromSearch(String query, Bundle extras) {
                playFromAutomotiveSearch(query);
            }
            @Override public void onStop() {
                if (radioRequested) stopOldSchoolRadio();
                else if (engine != null) {
                    engine.pause();
                    abandonAudioFocus();
                    releasePlaybackWakeLock();
                }
                updateSessionState();
            }
            @Override public void onPause() {
                if (radioRequested) stopOldSchoolRadio();
                else {
                    resumeAfterFocusGain = false;
                    pausedForFocusLoss = false;
                    engine.pause();
                }
            }
            @Override public void onSkipToQueueItem(long id) {
                if (radioRequested || engine == null || !prepareForPlayback()) return;
                List<Track> q = engine.getQueueSnapshot();
                for (int i=0;i<q.size();i++) if (q.get(i).id == id) { engine.playIndex(i); return; }
            }
            @Override public void onSkipToNext() { if (!radioRequested && prepareForPlayback()) engine.next(); }
            @Override public void onSkipToPrevious() { if (!radioRequested && prepareForPlayback()) engine.previous(); }
            @Override public void onSeekTo(long pos) { if (!radioRequested) engine.seekTo(pos); }
        });
        mediaSession.setActive(true);
        updateSessionState();
    }

    private void registerNoisyReceiver() {
        IntentFilter filter = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(noisyReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(noisyReceiver, filter);
            noisyReceiverRegistered = true;
        } catch (RuntimeException ignored) {}
    }

    private void registerScreenStateReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(screenStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(screenStateReceiver, filter);
            screenReceiverRegistered = true;
        } catch (RuntimeException ignored) {}
    }

    private boolean requestAudioFocus() {
        if (audioManager == null) { focusHeld = true; return true; }
        if (focusHeld) return true;
        if (focusRequest == null) {
            focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setOnAudioFocusChangeListener(focusListener, mainHandler)
                    .setWillPauseWhenDucked(false)
                    .setAcceptsDelayedFocusGain(false)
                    .build();
        }
        int result = audioManager.requestAudioFocus(focusRequest);
        focusHeld = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        if (focusHeld) duckedForFocus = false;
        return focusHeld;
    }

    public boolean prepareForPlayback() {
        if (isCatalogPreviewActive()) stopCatalogPreviewInternal(false);
        if (radioRequested) stopRadioInternal(false);
        boolean granted = requestAudioFocus();
        if (!granted) {
            releasePlaybackWakeLock();
            return false;
        }
        resumeAfterFocusGain = false;
        pausedForFocusLoss = false;
        duckedForFocus = false;
        if (engine != null) {
            engine.setMasterVolume(1f);
            engine.reassertOutputMix();
        }
        acquirePlaybackWakeLock();
        if (SonorusSettings.backgroundPlayback(this)) ensureForeground();
        return true;
    }

    private void acquirePlaybackWakeLock() {
        if (playbackWakeLock == null) return;
        try { if (!playbackWakeLock.isHeld()) playbackWakeLock.acquire(); } catch (Exception ignored) {}
    }

    private void releasePlaybackWakeLock() {
        if (playbackWakeLock == null) return;
        try { if (playbackWakeLock.isHeld()) playbackWakeLock.release(); } catch (Exception ignored) {}
    }

    private void abandonAudioFocus() {
        if (audioManager != null && focusRequest != null) {
            try { audioManager.abandonAudioFocusRequest(focusRequest); } catch (Exception ignored) {}
        }
        focusHeld = false;
        duckedForFocus = false;
    }

    private PendingIntent serviceAction(String action, int requestCode) {
        Intent i = new Intent(this, PlaybackService.class).setAction(action);
        return PendingIntent.getService(this, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildNotification() {
        Intent launch = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (radioRequested) {
            Notification.MediaStyle style = new Notification.MediaStyle().setMediaSession(mediaSession.getSessionToken()).setShowActionsInCompactView(0);
            String text = radioPreparing ? "Spajanje…" : (radioNowPlaying == null || radioNowPlaying.isEmpty() ? "Dobre, stare stvari." : radioNowPlaying);
            return new Notification.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_sonorus)
                    .setContentTitle("Old School Radio")
                    .setContentText(text)
                    .setContentIntent(content)
                    .setOnlyAlertOnce(true)
                    .setCategory(Notification.CATEGORY_TRANSPORT)
                    .setOngoing(radioPlaying || radioPreparing)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "Stop", serviceAction(ACTION_TOGGLE, 12)).build())
                    .setStyle(style)
                    .build();
        }

        Track track = engine.getCurrentTrack();
        String title = track == null ? "Sonorus" : track.title;
        String text = track == null ? "Lokalni glazbeni player" : track.artist;
        int toggleIcon = engine.isPlaying() ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;
        String toggleLabel = engine.isPlaying() ? "Pauza" : "Pokreni";
        Notification.MediaStyle style = new Notification.MediaStyle().setMediaSession(mediaSession.getSessionToken()).setShowActionsInCompactView(0, 1, 2);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_sonorus)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(content)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .setOngoing(engine.isPlaying())
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, "Prethodna", serviceAction(ACTION_PREV, 11)).build())
                .addAction(new Notification.Action.Builder(toggleIcon, toggleLabel, serviceAction(ACTION_TOGGLE, 12)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, "Sljedeća", serviceAction(ACTION_NEXT, 13)).build())
                .setStyle(style)
                .build();
    }

    private void ensureForeground() {
        if (notificationManager == null || mediaSession == null || engine == null) return;
        Notification n = buildNotification();
        if (!foreground) {
            if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(NOTIFICATION_ID, n);
            foreground = true;
        } else notificationManager.notify(NOTIFICATION_ID, n);
    }

    private void updateNotification() {
        if (foreground && notificationManager != null && mediaSession != null && engine != null) notificationManager.notify(NOTIFICATION_ID, buildNotification());
    }

    private void updateSessionQueue() {
        if (mediaSession == null || engine == null) return;
        if (radioRequested) {
            mediaSession.setQueue(null);
            mediaSession.setQueueTitle("Old School Radio");
            return;
        }
        List<Track> queue = engine.getQueueSnapshot();
        ArrayList<MediaSession.QueueItem> items = new ArrayList<>();
        for (Track t : queue) {
            MediaDescription d = new MediaDescription.Builder()
                    .setMediaId(AUTO_TRACK_PREFIX + t.id)
                    .setTitle(t.title)
                    .setSubtitle(t.artist)
                    .build();
            items.add(new MediaSession.QueueItem(d, t.id));
        }
        mediaSession.setQueue(items);
        mediaSession.setQueueTitle("Red reprodukcije");
    }

    private void updateSessionMetadata() {
        if (mediaSession == null || engine == null) return;
        MediaMetadata.Builder b = new MediaMetadata.Builder();
        if (radioRequested) {
            b.putString(MediaMetadata.METADATA_KEY_MEDIA_ID, AUTO_RADIO)
                    .putString(MediaMetadata.METADATA_KEY_TITLE, radioNowPlaying == null || radioNowPlaying.isEmpty() ? "Old School Radio" : radioNowPlaying)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, "Old School Radio")
                    .putString(MediaMetadata.METADATA_KEY_ALBUM, "Dobre, stare stvari.");
        } else {
            Track track = engine.getCurrentTrack();
            if (track != null) {
                b.putString(MediaMetadata.METADATA_KEY_MEDIA_ID, AUTO_TRACK_PREFIX + track.id)
                        .putString(MediaMetadata.METADATA_KEY_TITLE, track.title)
                        .putString(MediaMetadata.METADATA_KEY_ARTIST, track.artist)
                        .putString(MediaMetadata.METADATA_KEY_ALBUM, track.album)
                        .putLong(MediaMetadata.METADATA_KEY_DURATION, track.durationMs);
            }
        }
        mediaSession.setMetadata(b.build());
    }

    private void updateSessionState() {
        if (mediaSession == null) return;
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_STOP | PlaybackState.ACTION_PLAY_FROM_MEDIA_ID | PlaybackState.ACTION_PLAY_FROM_SEARCH | PlaybackState.ACTION_SKIP_TO_QUEUE_ITEM;
        int state;
        long pos = 0L;
        float speed = 0f;
        if (radioRequested) {
            state = radioPreparing ? PlaybackState.STATE_BUFFERING : (radioPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED);
            speed = radioPlaying ? 1f : 0f;
        } else {
            actions |= PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO;
            state = engine != null && engine.isPlaying() ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
            pos = engine == null ? 0L : engine.getPosition();
            speed = engine != null && engine.isPlaying() ? 1f : 0f;
        }
        mediaSession.setPlaybackState(new PlaybackState.Builder().setActions(actions).setState(state, pos, speed).build());
    }

    @Override public void onQueueChanged() {
        updateSessionQueue();
        if (!radioRequested && engine != null && engine.getQueueSnapshot().isEmpty() && foreground) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            foreground = false;
        } else updateNotification();
    }

    @Override public void onTrackChanged(Track track, int index) {
        updateSessionMetadata();
        updateSessionState();
        updateNotification();
    }

    @Override public void onPlaybackChanged(boolean playing) {
        if (playing) {
            if (radioRequested) stopRadioInternal(false);
            if (!requestAudioFocus()) {
                engine.pause();
                return;
            }
            duckedForFocus = false;
            engine.setMasterVolume(1f);
            engine.reassertOutputMix();
            acquirePlaybackWakeLock();
            armPlaybackHealthTicker();
            if (SonorusSettings.backgroundPlayback(this)) ensureForeground(); else updateNotification();
        } else if (!radioRequested) {
            releasePlaybackWakeLock();
            if (!pausedForFocusLoss) abandonAudioFocus();
            updateNotification();
            disarmPlaybackHealthTickerIfIdle();
        }
        updateSessionState();
    }

    @Override public void onProgress(long positionMs, long durationMs) {
        if (radioRequested) return;
        if (positionMs % 1000L < 120L) updateSessionState();
    }

    @Override public void onModesChanged(boolean shuffle, int repeatMode, boolean crossfadeEnabled, int crossfadeSeconds, boolean fadeInOut, boolean smartCrossfade) {
        updateNotification();
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        if (SonorusSettings.backgroundPlayback(this) && radioRequested) {
            if (focusHeld) setRadioVolume(duckedForFocus ? 0.40f : 1f);
            acquirePlaybackWakeLock();
            ensureForeground();
        } else if (engine != null && engine.isPlaying() && SonorusSettings.backgroundPlayback(this)) {
            if (focusHeld && !duckedForFocus) {
                engine.setMasterVolume(1f);
                engine.reassertOutputMix();
                engine.verifyPlaybackActive();
            }
            acquirePlaybackWakeLock();
            ensureForeground();
        } else if (engine != null && !SonorusSettings.backgroundPlayback(this)) {
            stopRadioInternal(false);
            engine.pause();
            stopForeground(STOP_FOREGROUND_REMOVE);
            foreground = false;
            stopSelf();
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        mainHandler.removeCallbacks(playbackHealthTicker);
        playbackHealthArmed = false;
        cancelRadioRecovery();
        stopMetadataTicker();
        stopCatalogPreviewProgressTicker();
        stopCatalogPreviewInternal(false);
        stopRadioInternal(false);
        releasePlaybackWakeLock();
        abandonAudioFocus();
        if (noisyReceiverRegistered) {
            try { unregisterReceiver(noisyReceiver); } catch (Exception ignored) {}
        }
        if (screenReceiverRegistered) {
            try { unregisterReceiver(screenStateReceiver); } catch (Exception ignored) {}
        }
        if (mediaSession != null) mediaSession.release();
        if (engine != null) {
            engine.removeListener(this);
            engine.release();
        }
        radioNetworkExecutor.shutdownNow();
        browserExecutor.shutdownNow();
        super.onDestroy();
    }
}
