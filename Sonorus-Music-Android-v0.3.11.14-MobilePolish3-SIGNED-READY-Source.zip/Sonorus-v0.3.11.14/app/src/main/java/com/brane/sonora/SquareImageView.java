package com.brane.sonora;

import android.content.Context;
import android.util.AttributeSet;

public final class SquareImageView extends android.widget.ImageView {
    public SquareImageView(Context context) { super(context); }
    public SquareImageView(Context context, AttributeSet attrs) { super(context, attrs); }
    public SquareImageView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec);
        int size = getMeasuredWidth();
        setMeasuredDimension(size, size);
    }
}
