package com.brane.sonora;

public final class CatalogEntry {
    public enum Kind { TRACK, ARTIST, ALBUM, GENRE, FOLDER, PLAYLIST }

    public final Kind kind;
    public final String title;
    public final String subtitle;
    public final String meta;
    public final Track track;
    public final long numericKey;
    public final String textKey;
    public final int count;

    private CatalogEntry(Kind kind, String title, String subtitle, String meta, Track track,
                         long numericKey, String textKey, int count) {
        this.kind = kind;
        this.title = title;
        this.subtitle = subtitle;
        this.meta = meta;
        this.track = track;
        this.numericKey = numericKey;
        this.textKey = textKey;
        this.count = count;
    }

    public static CatalogEntry track(Track t) {
        String meta = TimeFormat.format(t.durationMs);
        return new CatalogEntry(Kind.TRACK, t.title, t.artist, meta, t, t.albumId, null, 1);
    }

    public static CatalogEntry artist(String artist, int count) {
        return new CatalogEntry(Kind.ARTIST, artist, count + (count == 1 ? " pjesma" : " pjesama"), "Izvođač", null, 0L, artist, count);
    }

    public static CatalogEntry album(String album, String artist, long albumId, int count) {
        return new CatalogEntry(Kind.ALBUM, album, artist, count + (count == 1 ? " pjesma" : " pjesama"), null, albumId, album, count);
    }

    public static CatalogEntry genre(String genre, long genreId, int count) {
        return new CatalogEntry(Kind.GENRE, genre, count + (count == 1 ? " pjesma" : " pjesama"), "Žanr", null, genreId, genre, count);
    }

    public static CatalogEntry folder(String name, String path, int count) {
        return new CatalogEntry(Kind.FOLDER, name, count + (count == 1 ? " pjesma" : " pjesama"), TrackNameParser.cleanDisplayPath(path), null, 0L, path, count);
    }

    public static CatalogEntry playlist(String name, int count) {
        return new CatalogEntry(Kind.PLAYLIST, name, count + (count == 1 ? " pjesma" : " pjesama"), "Spremljena playlista", null, 0L, name, count);
    }
}
