package com.brane.sonora;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Full-app theme background. Premium themes use real photographic backdrops.
 * Photos are downloaded once from fixed Unsplash photo URLs and kept in app files,
 * so after the first successful load the selected theme continues to work offline.
 */
public final class ThemeBackdropView extends View {
    private static final ExecutorService PHOTO_EXECUTOR = Executors.newSingleThreadExecutor();
    private static final long MAX_PHOTO_BYTES = 10L * 1024L * 1024L;

    private static final String URL_MIDNIGHT_STAGE =
            "https://images.unsplash.com/photo-1777398410361-a1bf3e83e60e?auto=format&fit=crop&w=2200&q=82";
    private static final String URL_COPPER_STUDIO =
            "https://images.unsplash.com/photo-1714347738034-f8280c00e97b?auto=format&fit=crop&w=2200&q=82";
    private static final String URL_VINYL_GOLD =
            "https://images.unsplash.com/photo-1630441099796-851705faa3ed?auto=format&fit=crop&w=2200&q=82";
    private static final String URL_OBSIDIAN =
            "https://images.unsplash.com/photo-1761998535969-11ca31e89f78?auto=format&fit=crop&w=2200&q=82";
    private static final String URL_CRIMSON =
            "https://images.unsplash.com/photo-1701460356742-deecc12da361?auto=format&fit=crop&w=2200&q=82";

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();
    private int themeId;
    private Bitmap photo;
    private int photoThemeId = -1;

    public ThemeBackdropView(Context c, AttributeSet a) {
        super(c, a);
        themeId = SonorusSettings.theme(c);
        setWillNotDraw(false);
        loadPhotoForTheme(themeId);
    }

    public void refreshTheme() {
        themeId = SonorusSettings.theme(getContext());
        loadPhotoForTheme(themeId);
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        c.drawColor(ThemeSupport.bg(getContext()));
        drawPhotoCenterCrop(c, w, h);
        drawThemeOverlay(c, w, h);
        if (themeId == SonorusSettings.THEME_VINYL) {
            drawVinylMotionOverlay(c, w, h);
            if (isShown()) postInvalidateDelayed(50L);
        }
    }

    private void drawPhotoCenterCrop(Canvas c, int w, int h) {
        Bitmap b = photo;
        if (b == null || b.isRecycled() || photoThemeId != themeId) return;
        int bw = b.getWidth(), bh = b.getHeight();
        if (bw <= 0 || bh <= 0) return;

        float scale = Math.max(w / (float) bw, h / (float) bh);
        float visibleW = w / scale;
        float visibleH = h / scale;
        int left = Math.max(0, Math.round((bw - visibleW) * 0.5f));
        int top = Math.max(0, Math.round((bh - visibleH) * 0.5f));
        int right = Math.min(bw, Math.round(left + visibleW));
        int bottom = Math.min(bh, Math.round(top + visibleH));
        src.set(left, top, right, bottom);
        dst.set(0, 0, w, h);

        paint.setShader(null);
        paint.setAlpha(themeId == SonorusSettings.THEME_VINYL ? 232 : 220);
        c.drawBitmap(b, src, dst, paint);
        paint.setAlpha(255);
    }

    private void drawThemeOverlay(Canvas c, int w, int h) {
        int top;
        int mid;
        int bottom;
        int glow;
        switch (themeId) {
            case SonorusSettings.THEME_AURORA: // UI name: Midnight Stage
                top = 0xA0040B17;
                mid = 0x78071325;
                bottom = 0xB8050A13;
                glow = 0x2554D7FF;
                break;
            case SonorusSettings.THEME_COPPER:
                top = 0x980C0705;
                mid = 0x701A0E08;
                bottom = 0xB40A0604;
                glow = 0x30F29A55;
                break;
            case SonorusSettings.THEME_VINYL:
                top = 0x90020806;
                mid = 0x68101B16;
                bottom = 0xAE050B09;
                glow = 0x2AD9B65E;
                break;
            case SonorusSettings.THEME_OBSIDIAN:
                top = 0xC0030305;
                mid = 0x8E0A0A0D;
                bottom = 0xD0040406;
                glow = 0x24D8A45B;
                break;
            case SonorusSettings.THEME_CRIMSON:
                top = 0xB90A0204;
                mid = 0x861B050B;
                bottom = 0xD0060103;
                glow = 0x36FF334D;
                break;
            default:
                top = 0xFF08090D;
                mid = 0xE80C0E14;
                bottom = 0xFF08090D;
                glow = 0x22FF8A2B;
                break;
        }

        paint.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{top, mid, bottom},
                new float[]{0f, 0.47f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);

        // Soft light only: no abstract drawn lines. The photograph remains the visual focus.
        float radius = Math.max(w, h) * 0.55f;
        paint.setShader(new RadialGradient(w * 0.70f, h * 0.18f, radius,
                new int[]{glow, glow & 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(w * 0.70f, h * 0.18f, radius, paint);
        paint.setShader(null);
    }

    private void drawVinylMotionOverlay(Canvas c, int w, int h) {
        float size = Math.min(w, h) * 0.34f;
        float cx = w * 0.80f;
        float cy = h * 0.70f;
        float angle = (SystemClock.uptimeMillis() % 48000L) * (360f / 48000f);

        c.save();
        c.rotate(angle, cx, cy);

        paint.setShader(new RadialGradient(cx, cy, size,
                new int[]{0x20F8E6B5, 0x14D9B65E, 0x3A0B0B0C, 0x6E030404},
                new float[]{0f, 0.16f, 0.76f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, size, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, size * 0.008f));
        for (int i = 0; i < 7; i++) {
            float groove = size * (0.34f + i * 0.085f);
            paint.setColor(i % 2 == 0 ? 0x19E7D08E : 0x106A5A34);
            c.drawCircle(cx, cy, groove, paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xC8D6B161);
        c.drawCircle(cx, cy, size * 0.18f, paint);
        paint.setColor(0x940B0B0C);
        c.drawCircle(cx, cy, size * 0.035f, paint);
        c.restore();

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(cx, cy, size * 1.05f,
                new int[]{0x14D9B65E, 0x00D9B65E}, null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, size * 1.05f, paint);
        paint.setShader(null);
    }

    private void loadPhotoForTheme(final int requestedTheme) {
        if (requestedTheme == photoThemeId && photo != null && !photo.isRecycled()) return;
        if (requestedTheme == SonorusSettings.THEME_ORIGINAL) {
            photoThemeId = requestedTheme;
            photo = null;
            invalidate();
            return;
        }
        final String url = photoUrl(requestedTheme);
        final String fileName = photoFileName(requestedTheme);
        if (url == null || fileName == null) return;

        PHOTO_EXECUTOR.execute(() -> {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); } catch (Exception ignored) {}
            File dir = new File(getContext().getApplicationContext().getFilesDir(), "theme_backdrops");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, fileName);
            Bitmap loaded = decodeSized(file);
            if (loaded == null) {
                if (downloadPhoto(url, file)) loaded = decodeSized(file);
            }
            final Bitmap result = loaded;
            post(() -> {
                if (requestedTheme != themeId || result == null) return;
                photo = result;
                photoThemeId = requestedTheme;
                invalidate();
            });
        });
    }

    private Bitmap decodeSized(File file) {
        if (file == null || !file.isFile() || file.length() < 4096L) return null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            int sample = 1;
            while (max / sample > 2300) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
        } catch (Exception ignored) {
            return null;
        }
    }

    private boolean downloadPhoto(String address, File target) {
        HttpURLConnection connection = null;
        File tmp = new File(target.getParentFile(), target.getName() + ".part");
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(15000);
            connection.setInstanceFollowRedirects(true);
            connection.setUseCaches(true);
            connection.setRequestProperty("User-Agent", "Sonorus/0.3.8 Android");
            connection.setRequestProperty("Accept", "image/avif,image/webp,image/jpeg,*/*");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return false;
            long length = connection.getContentLengthLong();
            if (length > MAX_PHOTO_BYTES) return false;

            long total = 0L;
            try (InputStream in = new BufferedInputStream(connection.getInputStream());
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(tmp))) {
                byte[] buffer = new byte[16 * 1024];
                int n;
                while ((n = in.read(buffer)) != -1) {
                    total += n;
                    if (total > MAX_PHOTO_BYTES) return false;
                    out.write(buffer, 0, n);
                }
                out.flush();
            }
            if (total < 4096L) return false;
            if (target.exists()) target.delete();
            return tmp.renameTo(target);
        } catch (Exception ignored) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
            if (tmp.exists() && !target.exists()) tmp.delete();
        }
    }

    private String photoUrl(int id) {
        switch (id) {
            case SonorusSettings.THEME_AURORA: return URL_MIDNIGHT_STAGE;
            case SonorusSettings.THEME_COPPER: return URL_COPPER_STUDIO;
            case SonorusSettings.THEME_VINYL: return URL_VINYL_GOLD;
            case SonorusSettings.THEME_OBSIDIAN: return URL_OBSIDIAN;
            case SonorusSettings.THEME_CRIMSON: return URL_CRIMSON;
            default: return null;
        }
    }

    private String photoFileName(int id) {
        switch (id) {
            case SonorusSettings.THEME_AURORA: return "midnight_stage.jpg";
            case SonorusSettings.THEME_COPPER: return "copper_studio.jpg";
            case SonorusSettings.THEME_VINYL: return "vinyl_gold.jpg";
            case SonorusSettings.THEME_OBSIDIAN: return "obsidian_3d.jpg";
            case SonorusSettings.THEME_CRIMSON: return "crimson_3d.jpg";
            default: return null;
        }
    }
}
