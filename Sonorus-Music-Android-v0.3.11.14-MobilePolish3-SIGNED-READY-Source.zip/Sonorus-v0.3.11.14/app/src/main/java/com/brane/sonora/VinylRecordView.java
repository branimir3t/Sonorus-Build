package com.brane.sonora;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/** Lightweight vinyl disc renderer. The parent view supplies the 3D tilt + rotation. */
public final class VinylRecordView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint groove = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint highlight = new Paint(Paint.ANTI_ALIAS_FLAG);
    private RadialGradient vinylGradient;

    public VinylRecordView(Context context) { this(context, null); }
    public VinylRecordView(Context context, AttributeSet attrs) { this(context, attrs, 0); }
    public VinylRecordView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        groove.setStyle(Paint.Style.STROKE);
        groove.setStrokeWidth(dp(0.7f));
        highlight.setStyle(Paint.Style.STROKE);
        highlight.setStrokeCap(Paint.Cap.ROUND);
        setLayerType(LAYER_TYPE_HARDWARE, null);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        float cx = w * 0.5f;
        float cy = h * 0.5f;
        float r = Math.min(w, h) * 0.49f;
        vinylGradient = new RadialGradient(
                cx - r * 0.18f, cy - r * 0.22f, r * 1.15f,
                new int[]{0xFF26272B, 0xFF111216, 0xFF050608, 0xFF17181C},
                new float[]{0f, 0.34f, 0.72f, 1f}, Shader.TileMode.CLAMP);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float cx = w * 0.5f;
        float cy = h * 0.5f;
        float r = Math.min(w, h) * 0.48f;

        fill.setShader(vinylGradient);
        canvas.drawCircle(cx, cy, r, fill);
        fill.setShader(null);

        // Fine concentric groove bands. Slight alpha variation keeps them visible in motion.
        for (int i = 0; i < 24; i++) {
            float rr = r * (0.34f + i * 0.026f);
            groove.setColor((i & 1) == 0 ? 0x2AFFFFFF : 0x18000000);
            RectF ring = new RectF(cx - rr, cy - rr, cx + rr, cy + rr);
            canvas.drawArc(ring, 8f, 154f, false, groove);
            canvas.drawArc(ring, 188f, 138f, false, groove);
        }

        // Soft specular arcs mimic room light crossing glossy vinyl.
        highlight.setStrokeWidth(Math.max(dp(1.2f), r * 0.012f));
        highlight.setColor(0x2EFFFFFF);
        RectF outer = new RectF(cx - r * 0.91f, cy - r * 0.91f, cx + r * 0.91f, cy + r * 0.91f);
        canvas.drawArc(outer, 210f, 64f, false, highlight);
        highlight.setStrokeWidth(Math.max(dp(0.8f), r * 0.007f));
        highlight.setColor(0x20FFB449);
        canvas.drawArc(outer, 26f, 48f, false, highlight);

        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFF08090B);
        canvas.drawCircle(cx, cy, r * 0.19f, fill);
        fill.setColor(ThemeSupport.accent(getContext()));
        canvas.drawCircle(cx, cy, Math.max(dp(2f), r * 0.018f), fill);
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
}
