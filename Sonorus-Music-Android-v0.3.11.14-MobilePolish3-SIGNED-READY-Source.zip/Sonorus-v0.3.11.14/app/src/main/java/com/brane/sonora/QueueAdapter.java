package com.brane.sonora;

import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public final class QueueAdapter extends BaseAdapter {
    public interface Callbacks {
        void onPlayIndex(int index);
        void onRemoveIndex(int index);
        void onDragStart(View source, int index);
        void onLongPressTrack(Track track);
    }

    private final android.content.Context context;
    private final LayoutInflater inflater;
    private final Callbacks callbacks;
    private final ArrayList<Track> queue = new ArrayList<>();
    private int currentIndex = -1;
    private int selectedIndex = -1;
    private int draggingIndex = -1;
    private int dropIndex = -1;
    private int lastTapIndex = -1;
    private long lastTapMs = 0L;

    public QueueAdapter(android.content.Context context, Callbacks callbacks) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.callbacks = callbacks;
    }

    public void setData(List<Track> tracks, int currentIndex) {
        queue.clear();
        if (tracks != null) queue.addAll(tracks);
        this.currentIndex = currentIndex;
        if (selectedIndex >= queue.size()) selectedIndex = -1;
        notifyDataSetChanged();
    }

    public void clearDropIndex() { endDrag(); }

    public void beginDrag(int index) {
        draggingIndex = index >= 0 && index < queue.size() ? index : -1;
        dropIndex = draggingIndex;
        notifyDataSetChanged();
    }

    public void updateDropIndex(int index) {
        int safe;
        if (index < 0 || queue.isEmpty()) safe = -1;
        else safe = Math.max(0, Math.min(index, queue.size() - 1));
        if (dropIndex != safe) {
            dropIndex = safe;
            notifyDataSetChanged();
        }
    }

    public void endDrag() {
        if (draggingIndex != -1 || dropIndex != -1) {
            draggingIndex = -1;
            dropIndex = -1;
            notifyDataSetChanged();
        }
    }

    public void selectIndex(int index) {
        selectedIndex = index >= 0 && index < queue.size() ? index : -1;
        notifyDataSetChanged();
    }

    public int getSelectedIndex() { return selectedIndex; }

    @Override public int getCount() { return queue.size(); }
    @Override public Track getItem(int position) { return queue.get(position); }
    @Override public long getItemId(int position) { return queue.get(position).id; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        Holder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.queue_item, parent, false);
            h = new Holder(convertView);
            convertView.setTag(h);
        } else h = (Holder) convertView.getTag();

        Track t = getItem(position);
        boolean active = position == currentIndex;
        boolean selected = position == selectedIndex;
        boolean dragging = position == draggingIndex;
        boolean dropTarget = draggingIndex >= 0 && position == dropIndex && position != draggingIndex;
        h.boundPosition = position;
        h.number.setText(String.valueOf(position + 1));
        h.number.setTextColor(active ? ThemeSupport.accent(context) : ThemeSupport.text3(context));
        h.title.setText(t.title);
        h.title.setTextColor(active ? ThemeSupport.accent(context) : ThemeSupport.text(context));
        h.title.getPaint().setFakeBoldText(active);
        h.artist.setText(t.artist);
        h.artist.setTextColor(active ? ThemeSupport.accent(context) : ThemeSupport.text2(context));
        h.artist.getPaint().setFakeBoldText(active);
        h.duration.setText(TimeFormat.format(t.durationMs));
        h.root.setBackgroundResource(active ? R.drawable.bg_queue_active : dropTarget ? R.drawable.bg_queue_drop : selected ? R.drawable.bg_queue_selected : android.R.color.transparent);
        h.root.setAlpha(dragging ? 0.38f : 1f);
        h.handle.setAlpha(dragging ? 0.60f : 1f);

        h.root.setOnClickListener(v -> {
            long now = SystemClock.elapsedRealtime();
            boolean doubleTap = position == lastTapIndex && now - lastTapMs <= 380L;
            selectedIndex = position;
            notifyDataSetChanged();
            if (doubleTap) {
                lastTapIndex = -1;
                lastTapMs = 0L;
                callbacks.onPlayIndex(position);
            } else {
                lastTapIndex = position;
                lastTapMs = now;
            }
        });
        h.remove.setOnClickListener(v -> callbacks.onRemoveIndex(position));
        h.root.setOnLongClickListener(v -> { callbacks.onLongPressTrack(t); return true; });

        final int slop = ViewConfiguration.get(h.handle.getContext()).getScaledTouchSlop();
        h.handle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            boolean started;
            final Runnable holdDrag = () -> {
                if (!started) {
                    started = true;
                    h.handle.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                    callbacks.onDragStart(h.root, position);
                }
            };
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getX(); downY = event.getY(); started = false;
                        v.postDelayed(holdDrag, 220L);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getX() - downX, dy = event.getY() - downY;
                        if (!started && (dx * dx + dy * dy) > slop * slop) {
                            v.removeCallbacks(holdDrag);
                            started = true;
                            v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                            callbacks.onDragStart(h.root, position);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.removeCallbacks(holdDrag);
                        started = false;
                        return true;
                }
                return true;
            }
        });
        return convertView;
    }

    private static final class Holder {
        final View root;
        final TextView handle, number, title, artist, duration, remove;
        int boundPosition = -1;
        Holder(View v) {
            root = v.findViewById(R.id.queueRoot);
            handle = v.findViewById(R.id.dragHandle);
            number = v.findViewById(R.id.queueNumber);
            title = v.findViewById(R.id.queueTitle);
            artist = v.findViewById(R.id.queueArtist);
            duration = v.findViewById(R.id.queueDuration);
            remove = v.findViewById(R.id.removeQueueButton);
        }
    }
}
