package com.brane.sonora;

import android.content.ContentUris;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ArtworkLoader {
    private final Context context;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final OnlineMetadataRepository online;
    private final File diskDir;
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(40 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount() / 1024; }
    };

    public ArtworkLoader(Context context) {
        this.context = context.getApplicationContext();
        this.online = OnlineMetadataRepository.get(this.context);
        this.diskDir = new File(this.context.getCacheDir(), "sonorus_artwork");
        if (!diskDir.exists()) diskDir.mkdirs();
    }

    public void load(Track track, ImageView target) {
        if (track == null) { target.setTag(null); target.setImageResource(R.drawable.sonorus_vinyl_art); return; }
        String key = "track:" + track.id;
        target.setTag(key);
        Bitmap hit = cache.get(key);
        if (hit != null) { target.setImageBitmap(hit); return; }
        target.setImageResource(R.drawable.sonorus_vinyl_art);
        executor.execute(() -> {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); } catch (Exception ignored) {}
            Bitmap bmp = loadLocalBitmap(track);
            if (bmp == null && SonorusSettings.onlineMetadata(context)) {
                OnlineMetadataRepository.Metadata m = online.resolveBlocking(track);
                if (m != null && !m.artworkUrl.isEmpty()) bmp = loadRemoteBitmap(m.artworkUrl);
            }
            if (bmp != null) cache.put(key, bmp);
            Bitmap finalBmp = bmp;
            main.post(() -> {
                Object tag = target.getTag();
                if (key.equals(tag)) {
                    if (finalBmp != null) target.setImageBitmap(finalBmp);
                    else target.setImageResource(R.drawable.sonorus_vinyl_art);
                }
            });
        });
    }

    public void loadArtist(String artist, Track localFallback, ImageView target) {
        String safeArtist = artist == null ? "" : artist.trim();
        String key = "artist:" + safeArtist.toLowerCase(Locale.ROOT);
        target.setTag(key);
        Bitmap hit = cache.get(key);
        if (hit != null) { target.setImageBitmap(hit); return; }
        target.setImageResource(R.drawable.sonorus_vinyl_art);
        executor.execute(() -> {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); } catch (Exception ignored) {}
            Bitmap bmp = null;
            if (SonorusSettings.onlineMetadata(context)) {
                String url = online.resolveArtistImageBlocking(safeArtist);
                if (url != null && !url.isEmpty()) bmp = loadRemoteBitmap(url);
            }
            if (bmp == null && localFallback != null) bmp = loadLocalBitmap(localFallback);
            if (bmp != null) cache.put(key, bmp);
            Bitmap finalBmp = bmp;
            main.post(() -> {
                if (key.equals(target.getTag())) {
                    if (finalBmp != null) target.setImageBitmap(finalBmp);
                    else target.setImageResource(R.drawable.sonorus_vinyl_art);
                }
            });
        });
    }

    private Bitmap loadLocalBitmap(Track track) {
        Bitmap override = LocalArtworkStore.load(context, track.id);
        if (override != null) return override;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                return context.getContentResolver().loadThumbnail(track.uri, new Size(320, 320), null);
            }
        } catch (Exception ignored) {}
        try {
            Uri albumArt = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), track.albumId);
            try (InputStream in = context.getContentResolver().openInputStream(albumArt)) {
                if (in != null) return BitmapFactory.decodeStream(in);
            }
        } catch (Exception ignored) {}
        return null;
    }

    private Bitmap loadRemoteBitmap(String url) {
        if (url == null || url.isEmpty()) return null;
        File file = new File(diskDir, sha256(url) + ".img");
        if (file.isFile() && file.length() > 0) {
            try (FileInputStream in = new FileInputStream(file)) { return BitmapFactory.decodeStream(in); }
            catch (Exception ignored) {}
        }
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(8000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "Sonorus/0.2 Android Music Player");
            try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(file)) {
                byte[] buffer = new byte[16384];
                int n;
                while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            }
            try (FileInputStream in = new FileInputStream(file)) { return BitmapFactory.decodeStream(in); }
        } catch (Exception ignored) {
            try { file.delete(); } catch (Exception ignored2) {}
            return null;
        } finally { if (c != null) c.disconnect(); }
    }

    public void invalidateTrack(long trackId) {
        cache.remove("track:" + trackId);
    }

    public void clearOnlineCache() {
        cache.evictAll();
        online.clearCache();
        File[] files = diskDir.listFiles();
        if (files != null) for (File f : files) try { f.delete(); } catch (Exception ignored) {}
    }

    private String sha256(String s) {
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            byte[] b = d.digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte x : b) out.append(String.format(Locale.US, "%02x", x));
            return out.toString();
        } catch (Exception e) { return Integer.toHexString(s.hashCode()); }
    }

    public void shutdown() { executor.shutdownNow(); }
}
