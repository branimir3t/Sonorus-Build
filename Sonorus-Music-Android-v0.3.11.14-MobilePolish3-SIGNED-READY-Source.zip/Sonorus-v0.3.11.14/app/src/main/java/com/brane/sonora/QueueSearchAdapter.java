package com.brane.sonora;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class QueueSearchAdapter extends BaseAdapter implements Filterable {
    public static final class Item {
        public final int index;
        public final Track track;
        Item(int index, Track track) { this.index = index; this.track = track; }
        @Override public String toString() { return track == null ? "" : track.title; }
    }

    private final LayoutInflater inflater;
    private final ArrayList<Item> all = new ArrayList<>();
    private final ArrayList<Item> visible = new ArrayList<>();
    private String currentQuery = "";

    public QueueSearchAdapter(Context context) { inflater = LayoutInflater.from(context); }

    public void setQueue(List<Track> queue) {
        all.clear();
        if (queue != null) {
            for (int i = 0; i < queue.size(); i++) all.add(new Item(i, queue.get(i)));
        }
        visible.clear();
        if (currentQuery.isEmpty()) visible.addAll(all);
        else applyFilter(currentQuery);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return visible.size(); }
    @Override public Item getItem(int position) { return visible.get(position); }
    @Override public long getItemId(int position) { return getItem(position).track.id; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        Holder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.queue_search_suggestion, parent, false);
            h = new Holder(convertView);
            convertView.setTag(h);
        } else h = (Holder) convertView.getTag();
        Item item = getItem(position);
        h.title.setText(String.format(Locale.getDefault(), "%02d · %s", item.index + 1, item.track.title));
        h.artist.setText(item.track.artist);
        return convertView;
    }

    @Override public Filter getFilter() {
        return new Filter() {
            @Override protected FilterResults performFiltering(CharSequence constraint) {
                String q = constraint == null ? "" : constraint.toString().trim().toLowerCase(Locale.ROOT);
                ArrayList<Item> matches = filterItems(q);
                FilterResults r = new FilterResults();
                r.values = matches;
                r.count = matches.size();
                return r;
            }

            @SuppressWarnings("unchecked")
            @Override protected void publishResults(CharSequence constraint, FilterResults results) {
                currentQuery = constraint == null ? "" : constraint.toString().trim().toLowerCase(Locale.ROOT);
                visible.clear();
                if (results != null && results.values instanceof List) visible.addAll((List<Item>) results.values);
                notifyDataSetChanged();
            }

            @Override public CharSequence convertResultToString(Object resultValue) {
                Item item = resultValue instanceof Item ? (Item) resultValue : null;
                return item == null || item.track == null ? "" : item.track.title;
            }
        };
    }

    private ArrayList<Item> filterItems(String query) {
        ArrayList<Item> matches = new ArrayList<>();
        if (query == null || query.isEmpty()) return matches;
        for (Item item : all) {
            String title = item.track.title == null ? "" : item.track.title.toLowerCase(Locale.ROOT);
            String artist = item.track.artist == null ? "" : item.track.artist.toLowerCase(Locale.ROOT);
            if (title.contains(query) || artist.contains(query)) matches.add(item);
        }
        return matches;
    }

    private void applyFilter(String query) {
        visible.addAll(filterItems(query));
    }

    private static final class Holder {
        final TextView title, artist;
        Holder(View v) {
            title = v.findViewById(R.id.searchSuggestionTitle);
            artist = v.findViewById(R.id.searchSuggestionArtist);
        }
    }
}
