package com.brane.sonora;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.media.RingtoneManager;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.animation.LinearInterpolator;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity implements AudioEngine.Listener, PlaybackService.RadioListener, PlaybackService.CatalogPreviewListener {
    private static final int REQUEST_AUDIO = 701;
    private static final int REQUEST_NOTIFICATIONS = 702;
    private static final int REQUEST_COVER_IMAGE = 703;
    private static final long PROGRESS_UI_INTERVAL_MS = 200L;
    private static final long VINYL_REVOLUTION_MS = 1800L; // 33 1/3 RPM ≈ 1.8 s per revolution

    private enum Section { HOME, MUSIC, ARTISTS, ALBUMS, GENRES, FOLDERS, PLAYLISTS, FAVORITES, SETTINGS }

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final ArrayList<Track> library = new ArrayList<>();
    private final ArrayList<MediaLibrary.GenreInfo> genres = new ArrayList<>();
    private final ArrayList<CatalogEntry> baseEntries = new ArrayList<>();
    private final HashMap<Long, Track> libraryById = new HashMap<>();
    private final HashMap<Long, String> technicalTextCache = new HashMap<>();
    private final HashSet<Long> technicalPending = new HashSet<>();
    private long activeCatalogPreviewTrackId = -1L;
    private long activeCatalogPreviewDurationMs;

    private ArtworkLoader artworkLoader;
    private OnlineMetadataRepository onlineMetadata;
    private TechnicalMetadataReader technicalMetadataReader;
    private LyricsRepository lyricsRepository;
    private CatalogAdapter catalogAdapter;
    private QueueAdapter queueAdapter;
    private QueueAdapter mobileQueueAdapter;
    private QueueSearchAdapter queueSearchAdapter;
    private QueueSearchAdapter mobileQueueSearchAdapter;
    private PlaybackService playbackService;
    private AudioEngine engine;
    private boolean bound;
    private boolean libraryLoaded;
    private boolean wideLayout;
    private boolean userSeeking;
    private boolean queueDragInProgress;
    private long lastQueueTouchMs;
    private long lastProgressUiMs;
    private long lastCatalogTapMs;
    private long lastCatalogTapTrackId = -1L;
    private Section section = Section.HOME;
    private Section detailParent = null;
    private long selectedCatalogTrackId = -1L;
    private boolean multiSelectMode;
    private final LinkedHashSet<Long> multiSelectedIds = new LinkedHashSet<>();

    private LinearLayout sideNav, queuePanel, mobileQueueOverlay, mobileQueueSearchRow;
    private LinearLayout fullscreenNowPlayingBody, fullscreenInfoColumn;
    private View fullscreenDesktopContent, mobileFullscreenContent, mobileFullscreenLyricsSheet;
    private FrameLayout fullscreenVisualColumn, fullscreenTurntableFrame, fullscreenCoverSleeve;
    private ScrollView fullscreenLyricsScroll, mobileFullscreenLyricsScroll;
    private View multiSelectBar, oldSchoolRadioCard, mobileRadioCard;
    private View fullscreenNowPlayingOverlay, fullscreenVinylGroup;
    private View playerBar;
    private NowPlayingGlowLayout heroPanel;
    private PlayingBarsView heroBars;
    private View mobileNav;
    private GridView catalogGrid;
    private ListView queueList, mobileQueueList;
    private EditText searchBox;
    private AutoCompleteTextView queueSearchBox, mobileQueueSearchBox;
    private Spinner sortSpinner;
    private View settingsPanel, permissionPanel;
    private Button openQueueButton, playButton, prevButton, nextButton, shuffleButton, repeatButton;
    private Button multiSelectAllButton, bulkEditButton, closeMultiSelectButton, oldSchoolRadioButton, mobileOldSchoolRadioButton;
    private Button mobileBottomPlayButton, mobileBottomPrevButton, mobileBottomNextButton, mobileBottomQueueButton;
    private Button mobileQueueSearchToggle, mobileQueuePrevButton, mobileQueuePlayButton, mobileQueueStopButton, mobileQueueNextButton;
    private Button repeatListModeButton, randomModeButton, repeatOneModeButton, mobileRepeatListModeButton, mobileRandomModeButton, mobileRepeatOneModeButton;
    private Button crossfadeButton, settingsCrossfadeButton, mobileCrossfadeButton, themePickerButton;
    private Button fullscreenCloseButton, fullscreenPrevButton, fullscreenPlayButton, fullscreenStopButton, fullscreenNextButton, fullscreenLyricsDownloadButton, fullscreenLyricsEditButton;
    private ImageButton mobileFullscreenCloseButton, mobileFullscreenQueueButton;
    private ImageButton mobileFullscreenFavoriteButton, mobileFullscreenAddPlaylistButton, mobileFullscreenLyricsButton;
    private Button mobileFullscreenShuffleButton, mobileFullscreenPrevButton, mobileFullscreenPlayButton, mobileFullscreenNextButton, mobileFullscreenRepeatButton;
    private Button mobileFullscreenLyricsDownloadButton, mobileFullscreenLyricsInputButton, mobileFullscreenLyricsEditButton, mobileFullscreenLyricsCloseButton;
    private TextView contextTitle, contextMeta, queueMeta, mobileQueueMeta, queueDurationTotal;
    private TextView mobileQueueCurrentTime, mobileQueueTotalTime;
    private TextView queueSearchClear, mobileQueueSearchClear;
    private TextView multiSelectCount, oldSchoolRadioState, mobileOldSchoolRadioState, oldSchoolRadioNowPlaying, oldSchoolRadioArtist, mobileOldSchoolRadioNowPlaying;
    private TextView oldSchoolLiveBadge, mobileOldSchoolLiveBadge;
    private TextView nowTitle, nowArtist, currentTime, totalTime, heroTitle, heroArtist, heroAlbum, heroTech;
    private TextView heroCurrentTime, heroTotalTime;
    private TextView fullscreenSourceBadge, fullscreenTitle, fullscreenArtist, fullscreenAlbumYear, fullscreenTech, fullscreenCurrentTime, fullscreenTotalTime, fullscreenLyricsStatus, fullscreenLyrics;
    private TextView mobileFullscreenTitle, mobileFullscreenArtist, mobileFullscreenAlbum, mobileFullscreenCurrentTime, mobileFullscreenTotalTime, mobileFullscreenLyricsStatus, mobileFullscreenLyricsText;
    private TextView themeNameText, themeDescriptionText;
    private TextView leftClockText, leftDateText;
    private Switch backgroundPlaybackSwitch, onlineMetadataSwitch, wifiOnlySwitch, dynamicNowPlayingSwitch, loudnessNormalizationSwitch, fullscreenSwitch;
    private ImageView nowArt, heroArt, fullscreenCover, fullscreenRecordLabel, mobileFullscreenBackdrop, mobileFullscreenCover;
    private SeekBar progressBar, heroProgressBar, mobileQueueProgress, fullscreenProgress, mobileFullscreenProgress;
    private ObjectAnimator fullscreenVinylAnimator;
    private boolean sceneActivityResumed;
    private boolean fullscreenUserSeeking;
    private long fullscreenLyricsTrackId = -1L;
    private long pendingCoverTrackId = -1L;
    private long pendingSystemSoundTrackId = -1L;
    private int pendingSystemSoundType;
    private String pendingSystemSoundLabel = "";

    private final Runnable clockTicker = new Runnable() {
        @Override public void run() {
            updateLeftClock();
            long now = System.currentTimeMillis();
            long delay = 60_000L - (now % 60_000L);
            clockHandler.postDelayed(this, Math.max(1_000L, delay));
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            PlaybackService.LocalBinder binder = (PlaybackService.LocalBinder) service;
            playbackService = binder.getService();
            engine = binder.getEngine();
            engine.addListener(MainActivity.this);
            playbackService.addRadioListener(MainActivity.this);
            playbackService.addCatalogPreviewListener(MainActivity.this);
            bound = true;
            restoreQueueIfPossible();
            refreshQueueViews();
            refreshPlayerViews();
        }

        @Override public void onServiceDisconnected(ComponentName name) {
            if (playbackService != null) {
                playbackService.removeRadioListener(MainActivity.this);
                playbackService.removeCatalogPreviewListener(MainActivity.this);
            }
            if (engine != null) engine.removeListener(MainActivity.this);
            engine = null;
            playbackService = null;
            bound = false;
        }
    };

    private static final class CatalogDragPayload {
        final ArrayList<Track> tracks;
        final String label;
        CatalogDragPayload(List<Track> tracks, String label) { this.tracks = new ArrayList<>(tracks); this.label = label; }
    }

    private static final class QueueDragPayload {
        final int originalIndex;
        int targetInsertionIndex;
        QueueDragPayload(int index) { this.originalIndex = index; this.targetInsertionIndex = index; }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        setTheme(themeStyleResId());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            int chrome = ThemeSupport.bg(this);
            getWindow().setStatusBarColor(chrome);
            getWindow().setNavigationBarColor(chrome);
        } catch (RuntimeException ignored) {}

        artworkLoader = new ArtworkLoader(this);
        onlineMetadata = OnlineMetadataRepository.get(this);
        technicalMetadataReader = new TechnicalMetadataReader(this);
        lyricsRepository = new LyricsRepository(this);
        bindViews();
        applySystemBarInsets();
        setupCatalog();
        setupQueue();
        setupControls();
        applyResponsiveLayout();
        selectSection(Section.HOME);

        View root = findViewById(R.id.rootFrame);
        if (root != null) root.post(this::applyFullscreenMode);
        try {
            bindService(new Intent(this, PlaybackService.class), connection, Context.BIND_AUTO_CREATE);
        } catch (RuntimeException ignored) { bound = false; }
        ensureAudioPermissionAndScan();
    }


    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (event != null && event.getActionMasked() == MotionEvent.ACTION_DOWN && !multiSelectMode) {
            float rawX = event.getRawX();
            float rawY = event.getRawY();

            // Jedan tap izvan kartice uklanja samo prolaznu selekciju; reprodukcija se ne dira.
            if (selectedCatalogTrackId >= 0L && !isPointInsideVisibleChild(catalogGrid, rawX, rawY)) {
                selectedCatalogTrackId = -1L;
                lastCatalogTapTrackId = -1L;
                lastCatalogTapMs = 0L;
                if (catalogAdapter != null) catalogAdapter.setSelectedTrackId(-1L);
            }

            boolean insideQueueRow = isPointInsideVisibleChild(queueList, rawX, rawY)
                    || isPointInsideVisibleChild(mobileQueueList, rawX, rawY);
            if (!insideQueueRow) {
                if (queueAdapter != null && queueAdapter.getSelectedIndex() >= 0) queueAdapter.selectIndex(-1);
                if (mobileQueueAdapter != null && mobileQueueAdapter.getSelectedIndex() >= 0) mobileQueueAdapter.selectIndex(-1);
            }
        }
        return super.dispatchTouchEvent(event);
    }

    private boolean isPointInsideVisibleChild(ViewGroup parent, float rawX, float rawY) {
        if (parent == null || !parent.isShown()) return false;
        int[] location = new int[2];
        parent.getLocationOnScreen(location);
        if (rawX < location[0] || rawX >= location[0] + parent.getWidth()
                || rawY < location[1] || rawY >= location[1] + parent.getHeight()) return false;
        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child == null || child.getVisibility() != View.VISIBLE) continue;
            child.getLocationOnScreen(location);
            if (rawX >= location[0] && rawX < location[0] + child.getWidth()
                    && rawY >= location[1] && rawY < location[1] + child.getHeight()) return true;
        }
        return false;
    }

    private int themeStyleResId() {
        switch (SonorusSettings.theme(this)) {
            case SonorusSettings.THEME_AURORA: return R.style.AppThemeAurora;
            case SonorusSettings.THEME_COPPER: return R.style.AppThemeCopper;
            case SonorusSettings.THEME_VINYL: return R.style.AppThemeVinyl;
            case SonorusSettings.THEME_OBSIDIAN: return R.style.AppThemeObsidian;
            case SonorusSettings.THEME_CRIMSON: return R.style.AppThemeCrimson;
            default: return R.style.AppTheme;
        }
    }

    private void refreshThemeSettingsUi() {
        if (themeNameText == null || themeDescriptionText == null) return;
        switch (SonorusSettings.theme(this)) {
            case SonorusSettings.THEME_AURORA:
                themeNameText.setText("Midnight Stage");
                themeDescriptionText.setText("Tamna koncertna fotografija, stage rasvjeta i premium stakleni paneli u plavo-cijan tonovima.");
                break;
            case SonorusSettings.THEME_COPPER:
                themeNameText.setText("Copper Studio");
                themeDescriptionText.setText("Prava studijska fotografija s mikrofonom i opremom, duboki 3D paneli i topli bakreno-jantarni detalji.");
                break;
            case SonorusSettings.THEME_VINYL:
                themeNameText.setText("Vinyl Gold");
                themeDescriptionText.setText("Vinyl Gold sada koristi čišću premium tipografiju, profinjeniju analognu pozadinu i diskretno animirani vinyl u pozadini.");
                break;
            case SonorusSettings.THEME_OBSIDIAN:
                themeNameText.setText("Obsidian 3D");
                themeDescriptionText.setText("Elegantna crna koncertna fotografija, grafitni 3D paneli, metalni odsjaj i diskretni champagne detalji.");
                break;
            case SonorusSettings.THEME_CRIMSON:
                themeNameText.setText("Crimson 3D");
                themeDescriptionText.setText("Tamna koncertna fotografija s dubokim crvenim svjetlom, rubin 3D paneli i elegantan premium izgled.");
                break;
            default:
                themeNameText.setText("Sonorus Original");
                themeDescriptionText.setText("Čista grafitna hi-fi tema s toplim narančastim naglascima i premium dubinom kartica.");
                break;
        }
    }

    private void showThemePickerDialog() {
        final String[] names = {"Sonorus Original", "Midnight Stage", "Copper Studio", "Vinyl Gold", "Obsidian 3D", "Crimson 3D"};
        final String[] details = {
                "Grafit + narančasti premium hi-fi detalji",
                "Prava koncertna fotografija + plavo-cijan staklo",
                "Prava studijska fotografija + bakar i jantar",
                "Prava fotografija vinila/gramofona + zeleno i zlato",
                "Crna koncertna fotografija + grafit, metal i champagne 3D",
                "Tamna crvena koncertna fotografija + rubin premium 3D"
        };
        int current = SonorusSettings.theme(this);
        String[] labels = new String[names.length];
        for (int i=0;i<names.length;i++) labels[i] = names[i] + "\n" + details[i];
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Odaberi temu Sonorusa")
                .setSingleChoiceItems(labels, current, (d, which) -> {
                    if (which == SonorusSettings.theme(MainActivity.this)) { d.dismiss(); return; }
                    SonorusSettings.setTheme(MainActivity.this, which);
                    d.dismiss();
                    recreate();
                })
                .setNegativeButton("Odustani", null)
                .create();
        showPremiumDialog(dialog);
    }

    private void applySystemBarInsets() {
        View root = findViewById(R.id.rootFrame);
        if (root == null) return;
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            try {
                int left = 0, top = 0, right = 0, bottom = 0;
                boolean fullscreen = isFullscreenEnabled();
                if (Build.VERSION.SDK_INT >= 30) {
                    int type = fullscreen ? WindowInsets.Type.displayCutout() : WindowInsets.Type.systemBars();
                    android.graphics.Insets safe = insets.getInsets(type);
                    left = safe.left; top = safe.top; right = safe.right; bottom = safe.bottom;
                } else if (!fullscreen) {
                    left = insets.getSystemWindowInsetLeft();
                    top = insets.getSystemWindowInsetTop();
                    right = insets.getSystemWindowInsetRight();
                    bottom = insets.getSystemWindowInsetBottom();
                } else if (Build.VERSION.SDK_INT >= 28 && insets.getDisplayCutout() != null) {
                    android.view.DisplayCutout cutout = insets.getDisplayCutout();
                    left = cutout.getSafeInsetLeft(); top = cutout.getSafeInsetTop();
                    right = cutout.getSafeInsetRight(); bottom = cutout.getSafeInsetBottom();
                }
                v.setPadding(left, top, right, bottom);
            } catch (RuntimeException ignored) {
                v.setPadding(0, 0, 0, 0);
            }
            return insets;
        });
        try { root.requestApplyInsets(); } catch (RuntimeException ignored) {}
    }

    private void applyFullscreenMode() {
        boolean fullscreen = isFullscreenEnabled();
        Window window = getWindow();
        if (window == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                android.view.WindowManager.LayoutParams lp = window.getAttributes();
                lp.layoutInDisplayCutoutMode = fullscreen
                        ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
                window.setAttributes(lp);
            }
            if (Build.VERSION.SDK_INT >= 30) {
                window.setDecorFitsSystemWindows(!fullscreen);
                WindowInsetsController controller = window.getInsetsController();
                if (controller != null) {
                    if (fullscreen) {
                        controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                        controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    } else {
                        controller.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    }
                }
            } else {
                int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
                if (fullscreen) {
                    flags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
                }
                window.getDecorView().setSystemUiVisibility(flags);
            }
        } catch (RuntimeException ignored) {
            // Fullscreen ne smije spriječiti pokretanje aplikacije.
        }
        View root = findViewById(R.id.rootFrame);
        if (root != null) {
            try { root.requestApplyInsets(); } catch (RuntimeException ignored) {}
        }
    }

    private boolean isFullscreenEnabled() {
        try { return SonorusSettings.fullscreen(this); }
        catch (RuntimeException ignored) { return true; }
    }

    @Override protected void onResume() {
        super.onResume();
        sceneActivityResumed = true;
        View root = findViewById(R.id.rootFrame);
        if (root != null) root.post(this::applyFullscreenMode);
        clockHandler.removeCallbacks(clockTicker);
        clockTicker.run();
        if (playbackService != null) playbackService.addRadioListener(this);
        if (fullscreenNowPlayingOverlay != null && fullscreenNowPlayingOverlay.getVisibility() == View.VISIBLE) {
            refreshFullscreenNowPlaying();
            updateFullscreenVinylMotion();
        }
        applyPendingSystemSoundIfAllowed();
    }

    @Override protected void onPause() {
        sceneActivityResumed = false;
        clockHandler.removeCallbacks(clockTicker);
        if (fullscreenVinylAnimator != null && fullscreenVinylAnimator.isStarted()) {
            try { fullscreenVinylAnimator.pause(); } catch (Exception ignored) {}
        }
        if (fullscreenTurntableFrame instanceof PhotographicVinylScene)
            ((PhotographicVinylScene) fullscreenTurntableFrame).setPlaying(false);
        super.onPause();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && isFullscreenEnabled()) {
            View root = findViewById(R.id.rootFrame);
            if (root != null) root.post(this::applyFullscreenMode);
        }
    }

    private void bindViews() {
        sideNav = findViewById(R.id.sideNav);
        multiSelectBar = findViewById(R.id.multiSelectBar);
        oldSchoolRadioCard = findViewById(R.id.oldSchoolRadioCard);
        mobileRadioCard = findViewById(R.id.mobileRadioCard);
        mobileNav = findViewById(R.id.mobileNav);
        queuePanel = findViewById(R.id.queuePanel);
        mobileQueueOverlay = findViewById(R.id.mobileQueueOverlay);
        mobileQueueSearchRow = findViewById(R.id.mobileQueueSearchRow);
        heroPanel = findViewById(R.id.heroPanel);
        heroBars = findViewById(R.id.heroBars);
        catalogGrid = findViewById(R.id.catalogGrid);
        queueList = findViewById(R.id.queueList);
        mobileQueueList = findViewById(R.id.mobileQueueList);
        searchBox = findViewById(R.id.searchBox);
        queueSearchBox = findViewById(R.id.queueSearchBox);
        mobileQueueSearchBox = findViewById(R.id.mobileQueueSearchBox);
        queueSearchClear = findViewById(R.id.queueSearchClear);
        mobileQueueSearchClear = findViewById(R.id.mobileQueueSearchClear);
        mobileQueueSearchToggle = findViewById(R.id.mobileQueueSearchToggle);
        sortSpinner = findViewById(R.id.sortSpinner);
        settingsPanel = findViewById(R.id.settingsPanel);
        permissionPanel = findViewById(R.id.permissionPanel);
        openQueueButton = findViewById(R.id.openQueueButton);
        multiSelectAllButton = findViewById(R.id.multiSelectAllButton);
        bulkEditButton = findViewById(R.id.bulkEditButton);
        closeMultiSelectButton = findViewById(R.id.closeMultiSelectButton);
        oldSchoolRadioButton = findViewById(R.id.oldSchoolRadioButton);
        mobileOldSchoolRadioButton = findViewById(R.id.mobileOldSchoolRadioButton);
        playerBar = findViewById(R.id.playerBar);
        playButton = findViewById(R.id.playButton);
        prevButton = findViewById(R.id.prevButton);
        nextButton = findViewById(R.id.nextButton);
        shuffleButton = findViewById(R.id.shuffleButton);
        repeatButton = findViewById(R.id.repeatButton);
        mobileBottomPlayButton = findViewById(R.id.mobileBottomPlayButton);
        mobileBottomPrevButton = findViewById(R.id.mobileBottomPrevButton);
        mobileBottomNextButton = findViewById(R.id.mobileBottomNextButton);
        mobileBottomQueueButton = findViewById(R.id.mobileBottomQueueButton);
        mobileQueuePrevButton = findViewById(R.id.mobileQueuePrevButton);
        mobileQueuePlayButton = findViewById(R.id.mobileQueuePlayButton);
        mobileQueueStopButton = findViewById(R.id.mobileQueueStopButton);
        mobileQueueNextButton = findViewById(R.id.mobileQueueNextButton);
        crossfadeButton = findViewById(R.id.crossfadeButton);
        settingsCrossfadeButton = findViewById(R.id.settingsCrossfadeButton);
        mobileCrossfadeButton = findViewById(R.id.mobileCrossfadeButton);
        contextTitle = findViewById(R.id.contextTitle);
        multiSelectCount = findViewById(R.id.multiSelectCount);
        oldSchoolRadioState = findViewById(R.id.oldSchoolRadioState);
        oldSchoolRadioArtist = findViewById(R.id.oldSchoolRadioArtist);
        mobileOldSchoolRadioState = findViewById(R.id.mobileOldSchoolRadioState);
        oldSchoolRadioNowPlaying = findViewById(R.id.oldSchoolRadioNowPlaying);
        mobileOldSchoolRadioNowPlaying = findViewById(R.id.mobileOldSchoolRadioNowPlaying);
        oldSchoolLiveBadge = findViewById(R.id.oldSchoolLiveBadge);
        mobileOldSchoolLiveBadge = findViewById(R.id.mobileOldSchoolLiveBadge);
        contextMeta = findViewById(R.id.contextMeta);
        queueMeta = findViewById(R.id.queueMeta);
        mobileQueueMeta = findViewById(R.id.mobileQueueMeta);
        mobileQueueCurrentTime = findViewById(R.id.mobileQueueCurrentTime);
        mobileQueueTotalTime = findViewById(R.id.mobileQueueTotalTime);
        queueDurationTotal = findViewById(R.id.queueDurationTotal);
        nowTitle = findViewById(R.id.nowTitle);
        nowArtist = findViewById(R.id.nowArtist);
        currentTime = findViewById(R.id.currentTime);
        totalTime = findViewById(R.id.totalTime);
        heroTitle = findViewById(R.id.heroTitle);
        heroArtist = findViewById(R.id.heroArtist);
        heroAlbum = findViewById(R.id.heroAlbum);
        heroTech = findViewById(R.id.heroTech);
        nowArt = findViewById(R.id.nowArt);
        heroArt = findViewById(R.id.heroArt);
        progressBar = findViewById(R.id.progressBar);
        heroProgressBar = findViewById(R.id.heroProgressBar);
        mobileQueueProgress = findViewById(R.id.mobileQueueProgress);
        heroCurrentTime = findViewById(R.id.heroCurrentTime);
        heroTotalTime = findViewById(R.id.heroTotalTime);
        fullscreenNowPlayingOverlay = findViewById(R.id.fullscreenNowPlayingOverlay);
        fullscreenDesktopContent = findViewById(R.id.fullscreenDesktopContent);
        mobileFullscreenContent = findViewById(R.id.mobileFullscreenContent);
        mobileFullscreenLyricsSheet = findViewById(R.id.mobileFullscreenLyricsSheet);
        fullscreenNowPlayingBody = findViewById(R.id.fullscreenNowPlayingBody);
        fullscreenVisualColumn = findViewById(R.id.fullscreenVisualColumn);
        fullscreenInfoColumn = findViewById(R.id.fullscreenInfoColumn);
        fullscreenTurntableFrame = findViewById(R.id.fullscreenTurntableFrame);
        fullscreenCoverSleeve = findViewById(R.id.fullscreenCoverSleeve);
        fullscreenLyricsScroll = findViewById(R.id.fullscreenLyricsScroll);
        mobileFullscreenLyricsScroll = findViewById(R.id.mobileFullscreenLyricsScroll);
        fullscreenVinylGroup = findViewById(R.id.fullscreenVinylGroup);
        fullscreenCloseButton = findViewById(R.id.fullscreenCloseButton);
        fullscreenPrevButton = findViewById(R.id.fullscreenPrevButton);
        fullscreenPlayButton = findViewById(R.id.fullscreenPlayButton);
        fullscreenStopButton = findViewById(R.id.fullscreenStopButton);
        fullscreenNextButton = findViewById(R.id.fullscreenNextButton);
        fullscreenLyricsDownloadButton = findViewById(R.id.fullscreenLyricsDownloadButton);
        fullscreenLyricsEditButton = findViewById(R.id.fullscreenLyricsEditButton);
        fullscreenSourceBadge = findViewById(R.id.fullscreenSourceBadge);
        fullscreenTitle = findViewById(R.id.fullscreenTitle);
        fullscreenArtist = findViewById(R.id.fullscreenArtist);
        fullscreenAlbumYear = findViewById(R.id.fullscreenAlbumYear);
        fullscreenTech = findViewById(R.id.fullscreenTech);
        fullscreenCurrentTime = findViewById(R.id.fullscreenCurrentTime);
        fullscreenTotalTime = findViewById(R.id.fullscreenTotalTime);
        fullscreenLyricsStatus = findViewById(R.id.fullscreenLyricsStatus);
        fullscreenLyrics = findViewById(R.id.fullscreenLyrics);
        fullscreenCover = findViewById(R.id.fullscreenCover);
        fullscreenRecordLabel = findViewById(R.id.fullscreenRecordLabel);
        fullscreenProgress = findViewById(R.id.fullscreenProgress);
        mobileFullscreenBackdrop = findViewById(R.id.mobileFullscreenBackdrop);
        mobileFullscreenCover = findViewById(R.id.mobileFullscreenCover);
        mobileFullscreenTitle = findViewById(R.id.mobileFullscreenTitle);
        mobileFullscreenArtist = findViewById(R.id.mobileFullscreenArtist);
        mobileFullscreenAlbum = findViewById(R.id.mobileFullscreenAlbum);
        mobileFullscreenCurrentTime = findViewById(R.id.mobileFullscreenCurrentTime);
        mobileFullscreenTotalTime = findViewById(R.id.mobileFullscreenTotalTime);
        mobileFullscreenLyricsStatus = findViewById(R.id.mobileFullscreenLyricsStatus);
        mobileFullscreenLyricsText = findViewById(R.id.mobileFullscreenLyricsText);
        mobileFullscreenProgress = findViewById(R.id.mobileFullscreenProgress);
        mobileFullscreenCloseButton = findViewById(R.id.mobileFullscreenCloseButton);
        mobileFullscreenQueueButton = findViewById(R.id.mobileFullscreenQueueButton);
        mobileFullscreenFavoriteButton = findViewById(R.id.mobileFullscreenFavoriteButton);
        mobileFullscreenAddPlaylistButton = findViewById(R.id.mobileFullscreenAddPlaylistButton);
        mobileFullscreenLyricsButton = findViewById(R.id.mobileFullscreenLyricsButton);
        mobileFullscreenShuffleButton = findViewById(R.id.mobileFullscreenShuffleButton);
        mobileFullscreenPrevButton = findViewById(R.id.mobileFullscreenPrevButton);
        mobileFullscreenPlayButton = findViewById(R.id.mobileFullscreenPlayButton);
        mobileFullscreenNextButton = findViewById(R.id.mobileFullscreenNextButton);
        mobileFullscreenRepeatButton = findViewById(R.id.mobileFullscreenRepeatButton);
        mobileFullscreenLyricsDownloadButton = findViewById(R.id.mobileFullscreenLyricsDownloadButton);
        mobileFullscreenLyricsInputButton = findViewById(R.id.mobileFullscreenLyricsInputButton);
        mobileFullscreenLyricsEditButton = findViewById(R.id.mobileFullscreenLyricsEditButton);
        mobileFullscreenLyricsCloseButton = findViewById(R.id.mobileFullscreenLyricsCloseButton);
        repeatListModeButton = findViewById(R.id.repeatListModeButton);
        randomModeButton = findViewById(R.id.randomModeButton);
        repeatOneModeButton = findViewById(R.id.repeatOneModeButton);
        mobileRepeatListModeButton = findViewById(R.id.mobileRepeatListModeButton);
        mobileRandomModeButton = findViewById(R.id.mobileRandomModeButton);
        mobileRepeatOneModeButton = findViewById(R.id.mobileRepeatOneModeButton);
        backgroundPlaybackSwitch = findViewById(R.id.backgroundPlaybackSwitch);
        onlineMetadataSwitch = findViewById(R.id.onlineMetadataSwitch);
        wifiOnlySwitch = findViewById(R.id.wifiOnlySwitch);
        dynamicNowPlayingSwitch = findViewById(R.id.dynamicNowPlayingSwitch);
        loudnessNormalizationSwitch = findViewById(R.id.loudnessNormalizationSwitch);
        fullscreenSwitch = findViewById(R.id.fullscreenSwitch);
        themePickerButton = findViewById(R.id.themePickerButton);
        themeNameText = findViewById(R.id.themeNameText);
        themeDescriptionText = findViewById(R.id.themeDescriptionText);
        leftClockText = findViewById(R.id.leftClockText);
        leftDateText = findViewById(R.id.leftDateText);
        styleMobileMiniPlayer();
        refreshThemeSettingsUi();
        updateLeftClock();
    }

    private void setupCatalog() {
        catalogAdapter = new CatalogAdapter(this, artworkLoader, new CatalogAdapter.Callbacks() {
            @Override public void onEntryClick(CatalogEntry entry) { handleEntryClick(entry); }

            @Override public void onEntryLongPress(CatalogEntry entry, View source) {
                if (entry == null) return;
                if (entry.kind == CatalogEntry.Kind.TRACK && entry.track != null) {
                    showTrackOptions(entry.track, true);
                } else if (entry.kind == CatalogEntry.Kind.FOLDER) {
                    addEntryToQueue(entry, true);
                } else if (entry.kind == CatalogEntry.Kind.PLAYLIST) {
                    showPlaylistOptions(entry.textKey);
                }
            }

            @Override public void onEntryDragStart(CatalogEntry entry, View source) {
                if (!wideLayout || entry == null) return;
                List<Track> tracks = tracksForEntry(entry);
                String label = entry.kind == CatalogEntry.Kind.FOLDER ? entry.title : (entry.track == null ? entry.title : entry.track.title);
                startCatalogDrag(source, tracks, label);
            }

            @Override public void onEntryAdd(CatalogEntry entry) { addEntryToQueue(entry, false); }

            @Override public void onEntryPreview(Track track) {
                if (playbackService == null || track == null) return;
                playbackService.startCatalogPreview(track);
            }


            @Override public void onFavoriteToggle(Track track) {
                boolean favorite = IdStore.toggleFavorite(MainActivity.this, track.id);
                catalogAdapter.refreshFavorites();
                if (section == Section.FAVORITES) showFavorites();
                Toast.makeText(MainActivity.this, favorite ? "Dodano u favorite" : "Maknuto iz favorita", Toast.LENGTH_SHORT).show();
            }
        });
        catalogGrid.setAdapter(catalogAdapter);

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { applySearchAndSort(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        String[] sortItems = { "Naslov A–Ž", "Izvođač", "Album", "Najnovije" };
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, sortItems);
        spinnerAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        sortSpinner.setAdapter(spinnerAdapter);
        sortSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { applySearchAndSort(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    private void setupQueue() {
        QueueAdapter.Callbacks queueCallbacks = new QueueAdapter.Callbacks() {
            @Override public void onPlayIndex(int index) {
                if (engine == null || !preparePlayback()) return;
                engine.playIndex(index);
            }
            @Override public void onRemoveIndex(int index) { if (engine != null) engine.removeAt(index); }
            @Override public void onDragStart(View source, int index) { startQueueDrag(source, index); }
            @Override public void onLongPressTrack(Track track) { showTrackOptions(track, false); }
        };
        queueAdapter = new QueueAdapter(this, queueCallbacks);
        mobileQueueAdapter = new QueueAdapter(this, queueCallbacks);
        queueList.setAdapter(queueAdapter);
        mobileQueueList.setAdapter(mobileQueueAdapter);
        installQueueDropTarget(queueList, queuePanel);
        installQueueDropTarget(mobileQueueList, mobileQueueOverlay);
        View.OnTouchListener queueTouch = (v, event) -> { lastQueueTouchMs = android.os.SystemClock.elapsedRealtime(); return false; };
        queueList.setOnTouchListener(queueTouch);
        mobileQueueList.setOnTouchListener((v, event) -> {
            lastQueueTouchMs = android.os.SystemClock.elapsedRealtime();
            if (event.getActionMasked() == android.view.MotionEvent.ACTION_DOWN) setMobileQueueSearchOpen(false, false);
            return false;
        });

        queueSearchAdapter = new QueueSearchAdapter(this);
        mobileQueueSearchAdapter = new QueueSearchAdapter(this);
        setupQueueSearch(queueSearchBox, queueSearchClear, queueSearchAdapter);
        setupQueueSearch(mobileQueueSearchBox, mobileQueueSearchClear, mobileQueueSearchAdapter);
    }

    private void setupQueueSearch(AutoCompleteTextView box, TextView clear, QueueSearchAdapter adapter) {
        if (box == null || clear == null || adapter == null) return;
        box.setAdapter(adapter);
        box.setThreshold(1);
        box.setOnItemClickListener((parent, view, position, id) -> {
            Object selected = parent.getItemAtPosition(position);
            if (selected instanceof QueueSearchAdapter.Item) {
                QueueSearchAdapter.Item item = (QueueSearchAdapter.Item) selected;
                focusQueueSearchResult(item.index, box);
            }
        });
        box.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                clear.setVisibility(s != null && s.length() > 0 ? View.VISIBLE : View.INVISIBLE);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        clear.setOnClickListener(v -> {
            box.setText("");
            box.dismissDropDown();
            box.requestFocus();
        });
    }

    private void focusQueueSearchResult(int index, AutoCompleteTextView source) {
        if (queueAdapter != null) queueAdapter.selectIndex(index);
        if (mobileQueueAdapter != null) mobileQueueAdapter.selectIndex(index);
        scrollListToCurrent(queueList, index);
        scrollListToCurrent(mobileQueueList, index);
        if (source != null) {
            source.dismissDropDown();
            source.clearFocus();
            if (source == mobileQueueSearchBox) setMobileQueueSearchOpen(false, false);
        }
    }

    private void setupControls() {
        attachNav(R.id.navHome, R.id.mNavHome, Section.HOME);
        attachNav(R.id.navMusic, R.id.mNavMusic, Section.MUSIC);
        attachNav(R.id.navArtists, R.id.mNavArtists, Section.ARTISTS);
        attachNav(R.id.navAlbums, R.id.mNavAlbums, Section.ALBUMS);
        attachNav(R.id.navGenres, R.id.mNavGenres, Section.GENRES);
        attachNav(R.id.navFolders, R.id.mNavFolders, Section.FOLDERS);
        attachNav(R.id.navPlaylists, R.id.mNavPlaylists, Section.PLAYLISTS);
        attachNav(R.id.navFavorites, R.id.mNavFavorites, Section.FAVORITES);
        attachNav(R.id.navSettings, R.id.mNavSettings, Section.SETTINGS);

        playButton.setOnClickListener(v -> {
            if (activeCatalogPreviewTrackId >= 0L && playbackService != null) {
                if (engine != null) engine.pause();
                playbackService.stopCatalogPreview();
                return;
            }
            if (engine == null) return;
            if (engine.isPlaying()) engine.pause();
            else if (preparePlayback()) engine.togglePlayPause();
        });
        prevButton.setOnClickListener(v -> { if (engine != null && preparePlayback()) engine.previous(); });
        nextButton.setOnClickListener(v -> { if (engine != null && preparePlayback()) engine.next(); });
        mobileBottomPlayButton.setOnClickListener(v -> {
            if (engine == null) return;
            if (engine.isPlaying()) engine.pause();
            else if (preparePlayback()) engine.togglePlayPause();
        });
        mobileBottomPrevButton.setOnClickListener(v -> { if (engine != null && preparePlayback()) engine.previous(); });
        mobileBottomNextButton.setOnClickListener(v -> { if (engine != null && preparePlayback()) engine.next(); });
        mobileBottomQueueButton.setOnClickListener(v -> {
            setMobileQueueSearchOpen(false, false);
            mobileQueueOverlay.setVisibility(View.VISIBLE);
            mobileQueueOverlay.bringToFront();
        });
        playerBar.setOnClickListener(v -> showFullscreenNowPlaying());
        shuffleButton.setOnClickListener(v -> { if (engine != null) engine.toggleShuffle(); });
        repeatButton.setOnClickListener(v -> { if (engine != null) engine.cycleRepeatMode(); });

        View.OnClickListener crossfadeOpen = v -> showCrossfadeDialog();
        crossfadeButton.setOnClickListener(crossfadeOpen);
        settingsCrossfadeButton.setOnClickListener(crossfadeOpen);
        mobileCrossfadeButton.setOnClickListener(crossfadeOpen);

        openQueueButton.setOnClickListener(v -> {
            setMobileQueueSearchOpen(false, false);
            mobileQueueOverlay.setVisibility(View.VISIBLE);
        });
        findViewById(R.id.closeMobileQueueButton).setOnClickListener(v -> {
            setMobileQueueSearchOpen(false, false);
            mobileQueueOverlay.setVisibility(View.GONE);
        });
        mobileQueueSearchToggle.setOnClickListener(v -> setMobileQueueSearchOpen(mobileQueueSearchRow.getVisibility() != View.VISIBLE, true));

        mobileQueuePrevButton.setOnClickListener(v -> { if (engine != null && preparePlayback()) engine.previous(); });
        mobileQueuePlayButton.setOnClickListener(v -> {
            if (engine == null) return;
            if (engine.isPlaying()) engine.pause();
            else if (preparePlayback()) engine.togglePlayPause();
        });
        mobileQueueStopButton.setOnClickListener(v -> {
            if (engine == null) return;
            engine.pause();
            engine.seekTo(0L);
            onProgress(0L, engine.getDuration());
        });
        mobileQueueNextButton.setOnClickListener(v -> { if (engine != null && preparePlayback()) engine.next(); });

        findViewById(R.id.clearQueueButton).setOnClickListener(v -> confirmClearQueue());
        findViewById(R.id.mobileClearQueueButton).setOnClickListener(v -> confirmClearQueue());
        findViewById(R.id.saveQueueButton).setOnClickListener(v -> showSavePlaylistDialog());
        findViewById(R.id.mobileSaveQueueButton).setOnClickListener(v -> showSavePlaylistDialog());
                findViewById(R.id.rescanButton).setOnClickListener(v -> scanLibrary());
        findViewById(R.id.restoreHiddenTracksButton).setOnClickListener(v -> {
            int count = HiddenTrackStore.count(this);
            if (count == 0) {
                Toast.makeText(this, "Nema uklonjenih stavki", Toast.LENGTH_SHORT).show();
            } else {
                HiddenTrackStore.clear(this);
                scanLibrary();
                Toast.makeText(this, "Vraćeno " + count + " stavki", Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.permissionButton).setOnClickListener(v -> requestAudioPermission());

        repeatListModeButton.setOnClickListener(v -> toggleRepeatList());
        mobileRepeatListModeButton.setOnClickListener(v -> toggleRepeatList());
        randomModeButton.setOnClickListener(v -> { if (engine != null) engine.toggleShuffle(); });
        mobileRandomModeButton.setOnClickListener(v -> { if (engine != null) engine.toggleShuffle(); });
        repeatOneModeButton.setOnClickListener(v -> toggleRepeatOne());
        mobileRepeatOneModeButton.setOnClickListener(v -> toggleRepeatOne());

        oldSchoolRadioButton.setOnClickListener(v -> toggleOldSchoolRadio());
        mobileOldSchoolRadioButton.setOnClickListener(v -> toggleOldSchoolRadio());
        multiSelectAllButton.setOnClickListener(v -> selectAllVisibleTracks());
        bulkEditButton.setOnClickListener(v -> showBulkEditDialog());
        closeMultiSelectButton.setOnClickListener(v -> exitMultiSelectMode());

        backgroundPlaybackSwitch.setChecked(SonorusSettings.backgroundPlayback(this));
        onlineMetadataSwitch.setChecked(SonorusSettings.onlineMetadata(this));
        wifiOnlySwitch.setChecked(SonorusSettings.wifiOnly(this));
        dynamicNowPlayingSwitch.setChecked(SonorusSettings.dynamicNowPlaying(this));
        loudnessNormalizationSwitch.setChecked(SonorusSettings.loudnessNormalization(this));
        fullscreenSwitch.setChecked(SonorusSettings.fullscreen(this));
        wifiOnlySwitch.setEnabled(onlineMetadataSwitch.isChecked());
        backgroundPlaybackSwitch.setOnCheckedChangeListener((b, checked) -> SonorusSettings.setBackgroundPlayback(this, checked));
        onlineMetadataSwitch.setOnCheckedChangeListener((b, checked) -> { SonorusSettings.setOnlineMetadata(this, checked); wifiOnlySwitch.setEnabled(checked); catalogAdapter.notifyDataSetChanged(); refreshPlayerViews(); });
        wifiOnlySwitch.setOnCheckedChangeListener((b, checked) -> SonorusSettings.setWifiOnly(this, checked));
        dynamicNowPlayingSwitch.setOnCheckedChangeListener((b, checked) -> { SonorusSettings.setDynamicNowPlaying(this, checked); heroPanel.setEffectsEnabled(checked); heroBars.setEffectsEnabled(checked); });
        fullscreenSwitch.setOnCheckedChangeListener((b, checked) -> {
            SonorusSettings.setFullscreen(this, checked);
            b.post(() -> { applyFullscreenMode(); applySystemBarInsets(); });
        });
        loudnessNormalizationSwitch.setOnCheckedChangeListener((b, checked) -> {
            SonorusSettings.setLoudnessNormalization(this, checked);
            if (engine != null) engine.setLoudnessNormalizationEnabled(checked);
        });
        findViewById(R.id.clearArtworkCacheButton).setOnClickListener(v -> { artworkLoader.clearOnlineCache(); Toast.makeText(this, "Cache je očišćen", Toast.LENGTH_SHORT).show(); catalogAdapter.notifyDataSetChanged(); refreshPlayerViews(); });
        if (themePickerButton != null) themePickerButton.setOnClickListener(v -> showThemePickerDialog());
        heroPanel.setEffectsEnabled(SonorusSettings.dynamicNowPlaying(this));
        heroBars.setEffectsEnabled(SonorusSettings.dynamicNowPlaying(this));
        heroTech.setVisibility(View.VISIBLE);

        SeekBar.OnSeekBarChangeListener seekListener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            @Override public void onStartTrackingTouch(SeekBar seekBar) { userSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                userSeeking = false;
                if (activeCatalogPreviewTrackId >= 0L && playbackService != null) {
                    long duration = Math.max(0L, activeCatalogPreviewDurationMs);
                    if (duration > 0L) {
                        playbackService.seekCatalogPreview(activeCatalogPreviewTrackId, duration * seekBar.getProgress() / 1000L);
                    }
                } else if (engine != null) {
                    long duration = engine.getDuration();
                    engine.seekTo(duration * seekBar.getProgress() / 1000L);
                }
            }
        };
        progressBar.setOnSeekBarChangeListener(seekListener);
        if (heroProgressBar != null) heroProgressBar.setOnSeekBarChangeListener(seekListener);
        if (mobileQueueProgress != null) mobileQueueProgress.setOnSeekBarChangeListener(seekListener);
        setupFullscreenNowPlayingControls();
    }

    private void setupFullscreenNowPlayingControls() {
        heroArt.setOnClickListener(v -> showFullscreenNowPlaying());
        nowArt.setOnClickListener(v -> showFullscreenNowPlaying());
        fullscreenCloseButton.setOnClickListener(v -> hideFullscreenNowPlaying());

        fullscreenPrevButton.setOnClickListener(v -> {
            if (activeCatalogPreviewTrackId >= 0L || engine == null) return;
            if (preparePlayback()) engine.previous();
        });
        fullscreenNextButton.setOnClickListener(v -> {
            if (activeCatalogPreviewTrackId >= 0L || engine == null) return;
            if (preparePlayback()) engine.next();
        });
        fullscreenPlayButton.setOnClickListener(v -> {
            if (activeCatalogPreviewTrackId >= 0L || engine == null) return;
            if (engine.isPlaying()) engine.pause();
            else if (preparePlayback()) engine.togglePlayPause();
            refreshFullscreenNowPlaying();
        });
        fullscreenStopButton.setOnClickListener(v -> {
            if (activeCatalogPreviewTrackId >= 0L && playbackService != null) {
                if (engine != null) engine.pause();
                playbackService.stopCatalogPreview();
                return;
            }
            if (engine == null) return;
            engine.pause();
            engine.seekTo(0L);
            updateFullscreenProgress(0L, engine.getDuration());
            refreshFullscreenNowPlaying();
        });
        fullscreenProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            @Override public void onStartTrackingTouch(SeekBar seekBar) { fullscreenUserSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                fullscreenUserSeeking = false;
                if (activeCatalogPreviewTrackId >= 0L && playbackService != null) {
                    long duration = Math.max(0L, activeCatalogPreviewDurationMs);
                    if (duration > 0L) playbackService.seekCatalogPreview(activeCatalogPreviewTrackId, duration * seekBar.getProgress() / 1000L);
                } else if (engine != null) {
                    long duration = Math.max(0L, engine.getDuration());
                    if (duration > 0L) engine.seekTo(duration * seekBar.getProgress() / 1000L);
                }
            }
        });
        fullscreenLyricsDownloadButton.setOnClickListener(v -> downloadFullscreenLyrics());
        fullscreenLyricsEditButton.setOnClickListener(v -> showFullscreenLyricsEditor());

        mobileFullscreenCloseButton.setOnClickListener(v -> hideFullscreenNowPlaying());
        mobileFullscreenQueueButton.setOnClickListener(v -> {
            setMobileQueueSearchOpen(false, false);
            mobileQueueOverlay.setVisibility(View.VISIBLE);
            mobileQueueOverlay.bringToFront();
        });
        mobileFullscreenPrevButton.setOnClickListener(v -> {
            if (activeCatalogPreviewTrackId >= 0L || engine == null) return;
            if (preparePlayback()) engine.previous();
        });
        mobileFullscreenNextButton.setOnClickListener(v -> {
            if (activeCatalogPreviewTrackId >= 0L || engine == null) return;
            if (preparePlayback()) engine.next();
        });
        mobileFullscreenPlayButton.setOnClickListener(v -> {
            if (activeCatalogPreviewTrackId >= 0L || engine == null) return;
            if (engine.isPlaying()) engine.pause();
            else if (preparePlayback()) engine.togglePlayPause();
            refreshFullscreenNowPlaying();
        });
        mobileFullscreenShuffleButton.setOnClickListener(v -> { if (engine != null) engine.toggleShuffle(); });
        mobileFullscreenRepeatButton.setOnClickListener(v -> { if (engine != null) engine.cycleRepeatMode(); });
        mobileFullscreenFavoriteButton.setOnClickListener(v -> {
            Track track = getFullscreenNowPlayingTrack();
            if (track == null) return;
            IdStore.toggleFavorite(MainActivity.this, track.id);
            if (catalogAdapter != null) catalogAdapter.refreshFavorites();
            updateMobileFullscreenFavorite(track);
        });
        mobileFullscreenAddPlaylistButton.setOnClickListener(v -> {
            Track track = getFullscreenNowPlayingTrack();
            if (track != null) showAddToPlaylistDialog(java.util.Collections.singletonList(track));
        });
        mobileFullscreenLyricsButton.setOnClickListener(v -> {
            if (mobileFullscreenLyricsSheet != null) {
                mobileFullscreenLyricsSheet.setVisibility(View.VISIBLE);
                mobileFullscreenLyricsSheet.bringToFront();
            }
        });
        mobileFullscreenLyricsCloseButton.setOnClickListener(v -> mobileFullscreenLyricsSheet.setVisibility(View.GONE));
        mobileFullscreenLyricsDownloadButton.setOnClickListener(v -> downloadFullscreenLyrics());
        mobileFullscreenLyricsInputButton.setOnClickListener(v -> showFullscreenLyricsEditor(true));
        mobileFullscreenLyricsEditButton.setOnClickListener(v -> showFullscreenLyricsEditor(false));
        mobileFullscreenProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            @Override public void onStartTrackingTouch(SeekBar seekBar) { fullscreenUserSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                fullscreenUserSeeking = false;
                if (activeCatalogPreviewTrackId >= 0L && playbackService != null) {
                    long duration = Math.max(0L, activeCatalogPreviewDurationMs);
                    if (duration > 0L) playbackService.seekCatalogPreview(activeCatalogPreviewTrackId, duration * seekBar.getProgress() / 1000L);
                } else if (engine != null) {
                    long duration = Math.max(0L, engine.getDuration());
                    if (duration > 0L) engine.seekTo(duration * seekBar.getProgress() / 1000L);
                }
            }
        });
    }

    private Track getFullscreenNowPlayingTrack() {
        if (activeCatalogPreviewTrackId >= 0L) return libraryById.get(activeCatalogPreviewTrackId);
        if (playbackService != null && playbackService.isOldSchoolRadioActive()) return null;
        return engine == null ? null : engine.getCurrentTrack();
    }

    private void showFullscreenNowPlaying() {
        Track track = getFullscreenNowPlayingTrack();
        if (track == null || fullscreenNowPlayingOverlay == null) return;
        fullscreenLyricsTrackId = -1L;
        fullscreenNowPlayingOverlay.setVisibility(View.VISIBLE);
        fullscreenNowPlayingOverlay.bringToFront();
        updateMobileMiniPlayerVisibility();
        applyFullscreenNowPlayingLayout();
        refreshFullscreenNowPlaying();
    }

    private void hideFullscreenNowPlaying() {
        if (fullscreenNowPlayingOverlay == null) return;
        fullscreenNowPlayingOverlay.setVisibility(View.GONE);
        updateFullscreenVinylMotion();
        updateMobileMiniPlayerVisibility();
    }

    private void applyFullscreenNowPlayingLayout() {
        Configuration config = getResources().getConfiguration();
        int widthDp = Math.max(1, config.screenWidthDp);
        int heightDp = Math.max(1, config.screenHeightDp);
        boolean phoneFullscreen = config.smallestScreenWidthDp > 0 ? config.smallestScreenWidthDp < 600 : Math.min(widthDp, heightDp) < 600;

        if (fullscreenDesktopContent != null) fullscreenDesktopContent.setVisibility(phoneFullscreen ? View.GONE : View.VISIBLE);
        if (mobileFullscreenContent != null) mobileFullscreenContent.setVisibility(phoneFullscreen ? View.VISIBLE : View.GONE);
        if (phoneFullscreen) {
            int coverDp = Math.max(220, Math.min(340, widthDp - 46));
            setViewSizeDp(mobileFullscreenCover, coverDp, coverDp);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && mobileFullscreenBackdrop != null) {
                try { mobileFullscreenBackdrop.setRenderEffect(RenderEffect.createBlurEffect(dp(18), dp(18), Shader.TileMode.CLAMP)); }
                catch (RuntimeException ignored) {}
            }
            return;
        }

        if (fullscreenNowPlayingBody == null || fullscreenVisualColumn == null || fullscreenInfoColumn == null) return;
        boolean wide = widthDp >= 700 || (widthDp > heightDp && widthDp >= 560);
        fullscreenNowPlayingBody.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        LinearLayout.LayoutParams visualLp = (LinearLayout.LayoutParams) fullscreenVisualColumn.getLayoutParams();
        LinearLayout.LayoutParams infoLp = (LinearLayout.LayoutParams) fullscreenInfoColumn.getLayoutParams();
        if (wide) {
            visualLp.width = 0;
            visualLp.height = ViewGroup.LayoutParams.MATCH_PARENT;
            visualLp.weight = 1.12f;
            infoLp.width = 0;
            infoLp.height = ViewGroup.LayoutParams.MATCH_PARENT;
            infoLp.weight = 0.88f;
            infoLp.setMarginStart(dp(12));
        } else {
            int visualHeight = Math.max(220, Math.min(330, Math.round(heightDp * 0.40f)));
            visualLp.width = ViewGroup.LayoutParams.MATCH_PARENT;
            visualLp.height = dp(visualHeight);
            visualLp.weight = 0f;
            infoLp.width = ViewGroup.LayoutParams.MATCH_PARENT;
            infoLp.height = 0;
            infoLp.weight = 1f;
            infoLp.setMarginStart(0);
        }
        fullscreenVisualColumn.setLayoutParams(visualLp);
        fullscreenInfoColumn.setLayoutParams(infoLp);
        layoutFullscreenPhotographicStage(wide, widthDp, heightDp);
    }

    private void layoutFullscreenPhotographicStage(boolean wide, int widthDp, int heightDp) {
        if (fullscreenTurntableFrame != null) fullscreenTurntableFrame.invalidate();
    }

    private void refreshFullscreenNowPlaying() {
        if (fullscreenNowPlayingOverlay == null || fullscreenNowPlayingOverlay.getVisibility() != View.VISIBLE) return;
        Track track = getFullscreenNowPlayingTrack();
        if (track == null) {
            updateFullscreenVinylMotion();
            return;
        }
        boolean preview = activeCatalogPreviewTrackId >= 0L;
        fullscreenSourceBadge.setText(preview ? "KATALOG PREVIEW" : "PLAYER");
        fullscreenTitle.setText(track.title);
        fullscreenArtist.setText(track.artist);
        String album = track.album == null ? "" : track.album.trim();
        String year = track.year > 0 ? String.valueOf(track.year) : "";
        if (!album.isEmpty() && !year.isEmpty()) fullscreenAlbumYear.setText(album + " · " + year);
        else if (!album.isEmpty()) fullscreenAlbumYear.setText(album);
        else if (!year.isEmpty()) fullscreenAlbumYear.setText(year);
        else fullscreenAlbumYear.setText("Lokalna glazbena datoteka");
        updateFullscreenTechnicalInfo(track);
        artworkLoader.load(track, fullscreenCover);
        artworkLoader.load(track, fullscreenRecordLabel);
        if (mobileFullscreenTitle != null) mobileFullscreenTitle.setText(track.title);
        if (mobileFullscreenArtist != null) mobileFullscreenArtist.setText(track.artist);
        if (mobileFullscreenAlbum != null) mobileFullscreenAlbum.setText(album.isEmpty() ? "Nepoznat album" : (year.isEmpty() ? album : album + " · " + year));
        if (mobileFullscreenCover != null) artworkLoader.load(track, mobileFullscreenCover);
        if (mobileFullscreenBackdrop != null) artworkLoader.load(track, mobileFullscreenBackdrop);
        updateMobileFullscreenFavorite(track);

        fullscreenPrevButton.setVisibility(preview ? View.GONE : View.VISIBLE);
        fullscreenPlayButton.setVisibility(preview ? View.GONE : View.VISIBLE);
        fullscreenNextButton.setVisibility(preview ? View.GONE : View.VISIBLE);
        fullscreenStopButton.setVisibility(View.VISIBLE);
        if (!preview && engine != null) fullscreenPlayButton.setText(engine.isPlaying() ? "❚❚" : "▶");
        if (mobileFullscreenPrevButton != null) mobileFullscreenPrevButton.setVisibility(preview ? View.INVISIBLE : View.VISIBLE);
        if (mobileFullscreenNextButton != null) mobileFullscreenNextButton.setVisibility(preview ? View.INVISIBLE : View.VISIBLE);
        if (mobileFullscreenPlayButton != null) {
            mobileFullscreenPlayButton.setVisibility(preview ? View.INVISIBLE : View.VISIBLE);
            if (!preview && engine != null) mobileFullscreenPlayButton.setText(engine.isPlaying() ? "❚❚" : "▶");
        }

        if (preview) {
            long duration = Math.max(0L, activeCatalogPreviewDurationMs);
            int p = heroProgressBar == null ? 0 : heroProgressBar.getProgress();
            updateFullscreenProgress(duration * p / 1000L, duration);
        } else if (engine != null) {
            updateFullscreenProgress(engine.getPosition(), engine.getDuration());
        } else {
            updateFullscreenProgress(0L, 0L);
        }
        loadFullscreenLyrics(track);
        updateFullscreenVinylMotion();
    }

    private void updateMobileFullscreenFavorite(Track track) {
        if (mobileFullscreenFavoriteButton == null || track == null) return;
        boolean favorite = IdStore.getFavorites(this).contains(track.id);
        mobileFullscreenFavoriteButton.setImageResource(favorite ? R.drawable.ic_mobile_favorite_filled : R.drawable.ic_mobile_favorite_outline);
        mobileFullscreenFavoriteButton.setColorFilter(favorite ? ThemeSupport.accent(this) : ThemeSupport.text(this));
    }

    private void updateFullscreenTechnicalInfo(Track track) {
        if (fullscreenTech == null || track == null) return;
        String cached = technicalTextCache.get(track.id);
        if (cached != null && !cached.isEmpty()) { fullscreenTech.setText(cached); return; }
        fullscreenTech.setText(audioFormatLabel(track));
        if (technicalMetadataReader == null || technicalPending.contains(track.id)) return;
        technicalPending.add(track.id);
        technicalMetadataReader.read(track, (readTrack, info) -> {
            technicalPending.remove(readTrack.id);
            String text = technicalLabel(info, readTrack);
            technicalTextCache.put(readTrack.id, text);
            Track current = getFullscreenNowPlayingTrack();
            if (current != null && current.id == readTrack.id && fullscreenTech != null) fullscreenTech.setText(text);
        });
    }

    private void updateFullscreenProgress(long positionMs, long durationMs) {
        if (fullscreenNowPlayingOverlay == null || fullscreenNowPlayingOverlay.getVisibility() != View.VISIBLE || fullscreenProgress == null) return;
        long safeDuration = Math.max(0L, durationMs);
        long safePosition = Math.max(0L, safeDuration > 0L ? Math.min(positionMs, safeDuration) : positionMs);
        if (!fullscreenUserSeeking) {
            int p = safeDuration > 0L ? (int)Math.min(1000L, safePosition * 1000L / safeDuration) : 0;
            fullscreenProgress.setProgress(p);
            fullscreenCurrentTime.setText(TimeFormat.format(safePosition));
            fullscreenTotalTime.setText(TimeFormat.format(safeDuration));
            if (mobileFullscreenProgress != null) mobileFullscreenProgress.setProgress(p);
            if (mobileFullscreenCurrentTime != null) mobileFullscreenCurrentTime.setText(TimeFormat.format(safePosition));
            if (mobileFullscreenTotalTime != null) mobileFullscreenTotalTime.setText(TimeFormat.format(safeDuration));
        }
    }

    private void updateFullscreenVinylMotion() {
        updateFullscreenTurntableState();
    }

    private void updateFullscreenTurntableState() {
        boolean visible = fullscreenNowPlayingOverlay != null && fullscreenNowPlayingOverlay.getVisibility() == View.VISIBLE;
        boolean preview = activeCatalogPreviewTrackId >= 0L;
        boolean playing = preview || (engine != null && engine.isPlaying());
        if (fullscreenTurntableFrame instanceof PhotographicVinylScene) {
            ((PhotographicVinylScene) fullscreenTurntableFrame).setPlaying(sceneActivityResumed && visible && playing);
        }
    }

    private void loadFullscreenLyrics(Track track) {
        if (track == null || lyricsRepository == null || fullscreenLyrics == null) return;
        if (fullscreenLyricsTrackId == track.id) return;
        fullscreenLyricsTrackId = track.id;
        if (fullscreenLyricsScroll != null) fullscreenLyricsScroll.post(() -> fullscreenLyricsScroll.scrollTo(0, 0));
        String cached = lyricsRepository.getCached(track);
        if (cached != null && !cached.trim().isEmpty()) {
            fullscreenLyrics.setText(cached);
            fullscreenLyricsStatus.setText("");
            fullscreenLyricsStatus.setVisibility(View.GONE);
            fullscreenLyricsEditButton.setText("Uredi tekst");
            fullscreenLyricsDownloadButton.setVisibility(View.GONE);
            updateMobileFullscreenLyrics(cached, "", true, false);
        } else {
            fullscreenLyrics.setText("Tekst pjesme nije spremljen. Preuzmi ga samo kada ga želiš.");
            fullscreenLyricsStatus.setVisibility(View.VISIBLE);
            fullscreenLyricsStatus.setText("Tekst nije spremljen");
            fullscreenLyricsEditButton.setText("Unesi / uredi");
            fullscreenLyricsDownloadButton.setEnabled(true);
            fullscreenLyricsDownloadButton.setVisibility(View.VISIBLE);
            updateMobileFullscreenLyrics("Tekst pjesme nije spremljen. Preuzmi ga samo kada ga želiš.", "Tekst nije spremljen", false, false);
        }
    }

    private void updateMobileFullscreenLyrics(String text, String status, boolean hasLyrics, boolean downloading) {
        if (mobileFullscreenLyricsText != null) mobileFullscreenLyricsText.setText(text == null ? "" : text);
        if (mobileFullscreenLyricsStatus != null) {
            mobileFullscreenLyricsStatus.setText(status == null ? "" : status);
            mobileFullscreenLyricsStatus.setVisibility(status == null || status.isEmpty() ? View.GONE : View.VISIBLE);
        }
        if (mobileFullscreenLyricsDownloadButton != null) {
            mobileFullscreenLyricsDownloadButton.setEnabled(!downloading);
            mobileFullscreenLyricsDownloadButton.setVisibility(hasLyrics ? View.GONE : View.VISIBLE);
            mobileFullscreenLyricsDownloadButton.setText(downloading ? "Preuzimam…" : "Preuzmi");
        }
        if (mobileFullscreenLyricsInputButton != null) mobileFullscreenLyricsInputButton.setVisibility(View.VISIBLE);
        if (mobileFullscreenLyricsEditButton != null) {
            mobileFullscreenLyricsEditButton.setText("Uredi");
            mobileFullscreenLyricsEditButton.setEnabled(hasLyrics);
        }
        if (mobileFullscreenLyricsScroll != null) mobileFullscreenLyricsScroll.post(() -> mobileFullscreenLyricsScroll.scrollTo(0, 0));
    }

    private void showFullscreenLyricsEditor() {
        showFullscreenLyricsEditor(false);
    }

    private void showFullscreenLyricsEditor(boolean startBlank) {
        Track track = getFullscreenNowPlayingTrack();
        if (track == null || lyricsRepository == null || fullscreenLyrics == null) return;

        String existing = startBlank ? "" : lyricsRepository.getCached(track);
        EditText input = new EditText(this);
        input.setHint("Upiši ili uredi tekst pjesme");
        input.setText(existing == null ? "" : existing);
        input.setTextColor(ThemeSupport.text(this));
        input.setHintTextColor(ThemeSupport.text3(this));
        input.setTextSize(14);
        input.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setMinLines(8);
        input.setMaxLines(18);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        input.setBackgroundResource(R.drawable.bg_search);
        if (input.getText() != null) input.setSelection(input.getText().length());

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(6), dp(16), dp(4));
        box.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(startBlank ? "Unesi tekst pjesme" : "Uredi tekst pjesme")
                .setView(box)
                .setPositiveButton("Spremi", (d, which) -> {
                    String text = input.getText() == null ? "" : input.getText().toString().trim();
                    if (text.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Tekst je prazan", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!lyricsRepository.saveLocal(track, text)) {
                        Toast.makeText(MainActivity.this, "Tekst nije moguće spremiti", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    fullscreenLyrics.setText(text);
                    fullscreenLyricsTrackId = track.id;
                    fullscreenLyricsStatus.setText("");
                    fullscreenLyricsStatus.setVisibility(View.GONE);
                    fullscreenLyricsEditButton.setText("Uredi tekst");
                    fullscreenLyricsDownloadButton.setVisibility(View.GONE);
                    updateMobileFullscreenLyrics(text, "", true, false);
                    if (fullscreenLyricsScroll != null) fullscreenLyricsScroll.post(() -> fullscreenLyricsScroll.scrollTo(0, 0));
                })
                .setNegativeButton("Odustani", null)
                .create();
        showPremiumDialog(dialog);
    }

    private void downloadFullscreenLyrics() {
        Track track = getFullscreenNowPlayingTrack();
        if (track == null || lyricsRepository == null) return;
        final long requestedId = track.id;
        fullscreenLyricsDownloadButton.setEnabled(false);
        fullscreenLyricsStatus.setVisibility(View.VISIBLE);
        fullscreenLyricsStatus.setText("PREUZIMAM TEKST…");
        updateMobileFullscreenLyrics(mobileFullscreenLyricsText == null ? "" : mobileFullscreenLyricsText.getText().toString(), "PREUZIMAM TEKST…", false, true);
        lyricsRepository.fetchAndCache(track, (resultTrack, status, lyrics, message) -> {
            Track current = getFullscreenNowPlayingTrack();
            if (current == null || current.id != requestedId || fullscreenNowPlayingOverlay.getVisibility() != View.VISIBLE) return;
            if (status == LyricsRepository.Status.FOUND && lyrics != null && !lyrics.trim().isEmpty()) {
                fullscreenLyrics.setText(lyrics);
                if (fullscreenLyricsScroll != null) fullscreenLyricsScroll.post(() -> fullscreenLyricsScroll.scrollTo(0, 0));
                fullscreenLyricsStatus.setText("");
                fullscreenLyricsStatus.setVisibility(View.GONE);
                fullscreenLyricsEditButton.setText("Uredi tekst");
                fullscreenLyricsDownloadButton.setVisibility(View.GONE);
                updateMobileFullscreenLyrics(lyrics, "", true, false);
            } else {
                fullscreenLyricsStatus.setVisibility(View.VISIBLE);
                fullscreenLyricsStatus.setText(message == null || message.trim().isEmpty() ? "Tekst nije pronađen" : message);
                fullscreenLyricsEditButton.setText("Unesi / uredi");
                fullscreenLyricsDownloadButton.setEnabled(true);
                fullscreenLyricsDownloadButton.setVisibility(View.VISIBLE);
                updateMobileFullscreenLyrics(fullscreenLyrics.getText().toString(), fullscreenLyricsStatus.getText().toString(), false, false);
            }
        });
    }

    private void setMobileQueueSearchOpen(boolean open, boolean requestKeyboard) {
        if (mobileQueueSearchRow == null || mobileQueueSearchToggle == null) return;
        mobileQueueSearchRow.animate().cancel();
        mobileQueueSearchToggle.setText(open ? "×" : "Traži");
        if (open) {
            mobileQueueSearchRow.setAlpha(0f);
            mobileQueueSearchRow.setTranslationY(-dp(6));
            mobileQueueSearchRow.setVisibility(View.VISIBLE);
            mobileQueueSearchRow.animate().alpha(1f).translationY(0f).setDuration(150L).start();
            if (mobileQueueSearchBox != null) {
                mobileQueueSearchBox.requestFocus();
                if (requestKeyboard) {
                    mobileQueueSearchBox.postDelayed(() -> {
                        try {
                            android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                            if (imm != null) imm.showSoftInput(mobileQueueSearchBox, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
                        } catch (Exception ignored) {}
                    }, 90L);
                }
            }
        } else {
            if (mobileQueueSearchBox != null) {
                mobileQueueSearchBox.dismissDropDown();
                mobileQueueSearchBox.clearFocus();
            }
            if (mobileQueueSearchRow.getVisibility() == View.VISIBLE) {
                mobileQueueSearchRow.animate().alpha(0f).translationY(-dp(4)).setDuration(120L).withEndAction(() -> {
                    mobileQueueSearchRow.setVisibility(View.GONE);
                    mobileQueueSearchRow.setAlpha(1f);
                    mobileQueueSearchRow.setTranslationY(0f);
                }).start();
            } else {
                mobileQueueSearchRow.setVisibility(View.GONE);
                mobileQueueSearchRow.setAlpha(1f);
                mobileQueueSearchRow.setTranslationY(0f);
            }
            try {
                android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(mobileQueueOverlay.getWindowToken(), 0);
            } catch (Exception ignored) {}
        }
    }

    private void attachNav(int desktopId, int mobileId, Section target) {
        findViewById(desktopId).setOnClickListener(v -> selectSection(target));
        findViewById(mobileId).setOnClickListener(v -> selectSection(target));
    }

    private void selectSection(Section target) {
        if (multiSelectMode) exitMultiSelectMode();
        section = target;
        detailParent = null;
        updateNavSelection(target);
        settingsPanel.setVisibility(target == Section.SETTINGS ? View.VISIBLE : View.GONE);
        catalogGrid.setVisibility(target == Section.SETTINGS ? View.GONE : View.VISIBLE);
        searchBox.setVisibility(target == Section.SETTINGS ? View.INVISIBLE : View.VISIBLE);
        sortSpinner.setVisibility(target == Section.SETTINGS ? View.INVISIBLE : View.VISIBLE);

        switch (target) {
            case HOME: showHome(); break;
            case MUSIC: showMusic(); break;
            case ARTISTS: showArtists(); break;
            case ALBUMS: showAlbums(); break;
            case GENRES: showGenres(); break;
            case FOLDERS: showFolders(); break;
            case PLAYLISTS: showPlaylists(); break;
            case FAVORITES: showFavorites(); break;
            case SETTINGS:
                contextTitle.setText("Postavke");
                contextMeta.setText("Player i biblioteka");
                baseEntries.clear();
                catalogAdapter.setEntries(baseEntries);
                break;
        }
        applyResponsiveLayout();
    }

    private void updateNavSelection(Section target) {
        int[] desktop = {R.id.navHome,R.id.navMusic,R.id.navArtists,R.id.navAlbums,R.id.navGenres,R.id.navFolders,R.id.navPlaylists,R.id.navFavorites,R.id.navSettings};
        int[] mobile = {R.id.mNavHome,R.id.mNavMusic,R.id.mNavArtists,R.id.mNavAlbums,R.id.mNavGenres,R.id.mNavFolders,R.id.mNavPlaylists,R.id.mNavFavorites,R.id.mNavSettings};
        Section[] sections = Section.values();
        for (int i = 0; i < sections.length; i++) {
            boolean selected = sections[i] == target;
            View d = findViewById(desktop[i]);
            View m = findViewById(mobile[i]);
            d.setSelected(selected); m.setSelected(selected);
            if (d instanceof Button) ((Button) d).setTextColor(selected ? ThemeSupport.text(this) : ThemeSupport.text2(this));
            if (m instanceof Button) ((Button) m).setTextColor(selected ? ThemeSupport.text(this) : ThemeSupport.text2(this));
        }
    }

    private void showHome() {
        contextTitle.setText("Nedavno dodano");
        List<Track> tracks = MediaLibrary.recentlyAdded(library, 60);
        setBaseEntries(MediaLibrary.trackEntries(tracks));
    }

    private void showMusic() {
        contextTitle.setText("Glazba");
        setBaseEntries(MediaLibrary.trackEntries(library));
    }

    private void showArtists() {
        contextTitle.setText("Izvođači");
        setBaseEntries(MediaLibrary.artistEntries(library));
    }

    private void showAlbums() {
        contextTitle.setText("Albumi");
        setBaseEntries(MediaLibrary.albumEntries(library));
    }

    private void showGenres() {
        contextTitle.setText("Žanrovi");
        setBaseEntries(MediaLibrary.genreEntries(genres));
    }

    private void showFolders() {
        contextTitle.setText("Mape");
        setBaseEntries(MediaLibrary.folderEntries(library));
    }

    private void showPlaylists() {
        contextTitle.setText("Playliste");
        ArrayList<CatalogEntry> entries = new ArrayList<>();
        for (String name : PlaylistStore.names(this)) entries.add(CatalogEntry.playlist(name, PlaylistStore.count(this, name)));
        setBaseEntries(entries);
    }

    private void showFavorites() {
        contextTitle.setText("Favoriti");
        Set<Long> fav = IdStore.getFavorites(this);
        ArrayList<Track> tracks = new ArrayList<>();
        for (Track t : library) if (fav.contains(t.id)) tracks.add(t);
        setBaseEntries(MediaLibrary.trackEntries(tracks));
    }

    private void setBaseEntries(List<CatalogEntry> entries) {
        baseEntries.clear();
        if (entries != null) baseEntries.addAll(entries);
        applySearchAndSort();
        if (catalogAdapter != null) {
            catalogAdapter.setSelectedTrackId(selectedCatalogTrackId);
            catalogAdapter.setMultiSelection(multiSelectMode, multiSelectedIds);
        }
    }

    private void applySearchAndSort() {
        if (catalogAdapter == null || section == Section.SETTINGS) return;
        String q = searchBox.getText() == null ? "" : searchBox.getText().toString().trim().toLowerCase(Locale.ROOT);
        ArrayList<CatalogEntry> filtered = new ArrayList<>();
        for (CatalogEntry e : baseEntries) {
            String hay = (e.title + " " + e.subtitle + " " + e.meta).toLowerCase(Locale.ROOT);
            if (q.isEmpty() || hay.contains(q)) filtered.add(e);
        }

        // Na glavnom popisu spremljenih playlista poštuj ručno složen redoslijed.
        if (!(section == Section.PLAYLISTS && detailParent == null)) {
            int sort = sortSpinner.getSelectedItemPosition();
            Comparator<CatalogEntry> comp;
            if (sort == 1) {
                comp = Comparator.comparing(e -> (e.track != null ? e.track.artist : e.subtitle).toLowerCase(Locale.ROOT));
            } else if (sort == 2) {
                comp = Comparator.comparing(e -> (e.track != null ? e.track.album : e.title).toLowerCase(Locale.ROOT));
            } else if (sort == 3) {
                comp = (a, b) -> Long.compare(b.track == null ? 0L : b.track.dateAddedSec, a.track == null ? 0L : a.track.dateAddedSec);
            } else {
                comp = Comparator.comparing(e -> e.title.toLowerCase(Locale.ROOT));
            }
            filtered.sort(comp);
        }
        catalogAdapter.setEntries(filtered);
        contextMeta.setText(filtered.size() + (filtered.size() == 1 ? " stavka" : " stavki"));
    }

    private void handleEntryClick(CatalogEntry entry) {
        if (entry == null) return;
        switch (entry.kind) {
            case TRACK:
                if (multiSelectMode && entry.track != null) {
                    toggleMultiSelection(entry.track.id);
                } else {
                    selectedCatalogTrackId = entry.track != null ? entry.track.id : -1L;
                    if (catalogAdapter != null) catalogAdapter.setSelectedTrackId(selectedCatalogTrackId);
                    contextMeta.setText("Odabrana pjesma");
                    if (entry.track != null) {
                        long now = android.os.SystemClock.elapsedRealtime();
                        boolean doubleTap = lastCatalogTapTrackId == entry.track.id && now - lastCatalogTapMs <= 380L;
                        if (doubleTap) {
                            lastCatalogTapTrackId = -1L;
                            lastCatalogTapMs = 0L;
                            if (engine != null && preparePlayback()) {
                                engine.playTrackNow(entry.track);
                                updateMobileMiniPlayerVisibility();
                            }
                        } else {
                            lastCatalogTapTrackId = entry.track.id;
                            lastCatalogTapMs = now;
                        }
                    }
                }
                break;
            case ARTIST:
                detailParent = Section.ARTISTS;
                contextTitle.setText(entry.title);
                setBaseEntries(MediaLibrary.trackEntries(MediaLibrary.filterByArtist(library, entry.textKey)));
                break;
            case ALBUM:
                detailParent = Section.ALBUMS;
                contextTitle.setText(entry.title);
                if (catalogAdapter != null) catalogAdapter.setAlbumGridMode(false);
                setBaseEntries(MediaLibrary.trackEntries(MediaLibrary.filterByAlbumId(library, entry.numericKey)));
                applyResponsiveLayout();
                break;
            case GENRE:
                detailParent = Section.GENRES;
                contextTitle.setText(entry.title);
                loadGenreTracks(entry.numericKey);
                break;
            case FOLDER:
                detailParent = Section.FOLDERS;
                contextTitle.setText(entry.title);
                setBaseEntries(MediaLibrary.trackEntries(MediaLibrary.filterByFolder(library, entry.textKey)));
                break;
            case PLAYLIST:
                detailParent = Section.PLAYLISTS;
                contextTitle.setText(entry.title);
                List<Track> tracks = MediaLibrary.tracksFromIds(PlaylistStore.loadIds(this, entry.textKey), libraryById);
                setBaseEntries(MediaLibrary.trackEntries(tracks));
                break;
        }
    }

    private void loadGenreTracks(long genreId) {
        contextMeta.setText("Učitavam…");
        executor.execute(() -> {
            List<Long> ids = MediaLibrary.queryGenreTrackIds(this, genreId);
            List<Track> tracks = MediaLibrary.tracksFromIds(ids, libraryById);
            runOnUiThread(() -> setBaseEntries(MediaLibrary.trackEntries(tracks)));
        });
    }

    private List<Track> tracksForEntry(CatalogEntry entry) {
        if (entry == null) return new ArrayList<>();
        if (entry.kind == CatalogEntry.Kind.TRACK && entry.track != null) return java.util.Collections.singletonList(entry.track);
        if (entry.kind == CatalogEntry.Kind.FOLDER) return MediaLibrary.filterByFolder(library, entry.textKey);
        return new ArrayList<>();
    }

    private void addEntryToQueue(CatalogEntry entry, boolean fromLongPress) {
        if (engine == null || entry == null) return;
        List<Track> tracks = tracksForEntry(entry);
        if (tracks.isEmpty()) return;
        addTracksToPlayerWithDuplicateCheck(tracks, -1, entry.kind == CatalogEntry.Kind.FOLDER ? entry.title : null);
    }

    private void showTrackOptions(Track track, boolean fromCatalog) {
        if (track == null) return;
        LinearLayout panel = buildCompactTrackOptionsPanel(track);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel).create();
        addCompactMenuItem(panel, R.drawable.ic_menu_add, "Dodaj u playlistu", () -> {
            dialog.dismiss();
            showAddToPlaylistDialog(java.util.Collections.singletonList(track));
        });
        addCompactMenuItem(panel, R.drawable.ic_menu_queue, "Dodaj u red", () -> {
            dialog.dismiss();
            addTracksToPlayerWithDuplicateCheck(java.util.Collections.singletonList(track), -1, null);
        });
        addCompactMenuItem(panel, R.drawable.ic_menu_edit, "Uredi podatke", () -> {
            dialog.dismiss();
            showEditTrackDialog(track);
        });
        addCompactMenuItem(panel, R.drawable.ic_menu_bell, "Postavi kao…", () -> {
            dialog.dismiss();
            showSetAsSystemSoundMenu(track);
        });
        addCompactMenuItem(panel, R.drawable.ic_menu_share, "Podijeli", () -> {
            dialog.dismiss();
            shareTrack(track);
        });
        addCompactMenuItem(panel, R.drawable.ic_menu_info, "Detalji", () -> {
            dialog.dismiss();
            showTrackDetails(track);
        });
        if (fromCatalog) {
            addCompactMenuItem(panel, R.drawable.ic_menu_multiselect, "Odaberi više", () -> {
                dialog.dismiss();
                enterMultiSelectMode(track.id);
            });
            addCompactMenuItem(panel, R.drawable.ic_menu_delete, "Ukloni iz Sonorusa", () -> {
                dialog.dismiss();
                confirmHideTrack(track);
            });
        }
        showCompactTrackMenuDialog(dialog);
    }

    private void showSetAsSystemSoundMenu(Track track) {
        if (track == null) return;
        LinearLayout panel = buildCompactTrackOptionsPanel(track);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel).create();
        addCompactMenuItem(panel, R.drawable.ic_menu_ringtone, "Melodija zvona", () -> {
            dialog.dismiss();
            requestSetAsSystemSound(track, RingtoneManager.TYPE_RINGTONE, "Melodija zvona");
        });
        addCompactMenuItem(panel, R.drawable.ic_menu_alarm, "Alarm", () -> {
            dialog.dismiss();
            requestSetAsSystemSound(track, RingtoneManager.TYPE_ALARM, "Alarm");
        });
        addCompactMenuItem(panel, R.drawable.ic_menu_notification, "Zvuk obavijesti", () -> {
            dialog.dismiss();
            requestSetAsSystemSound(track, RingtoneManager.TYPE_NOTIFICATION, "Zvuk obavijesti");
        });
        showCompactTrackMenuDialog(dialog);
    }

    private void shareTrack(Track track) {
        if (track == null || track.uri == null) {
            Toast.makeText(this, "Pjesmu nije moguće podijeliti", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            String mime = track.mimeType == null ? "" : track.mimeType.trim();
            shareIntent.setType(mime.startsWith("audio/") ? mime : "audio/*");
            shareIntent.putExtra(Intent.EXTRA_STREAM, track.uri);
            shareIntent.putExtra(Intent.EXTRA_TITLE, track.title);
            shareIntent.setClipData(ClipData.newRawUri("Sonorus audio", track.uri));
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Podijeli pjesmu"));
        } catch (Exception e) {
            Toast.makeText(this, "Nema dostupne aplikacije za dijeljenje", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestSetAsSystemSound(Track track, int type, String label) {
        if (track == null) return;
        if (!SystemSoundSetter.canWriteSettings(this)) {
            pendingSystemSoundTrackId = track.id;
            pendingSystemSoundType = type;
            pendingSystemSoundLabel = label == null ? "sistemski zvuk" : label;
            Toast.makeText(this, "Dopusti Sonorusu promjenu sistemskih zvukova pa će se odabir primijeniti.", Toast.LENGTH_LONG).show();
            SystemSoundSetter.openWriteSettings(this);
            return;
        }
        applySystemSound(track, type, label);
    }

    private void applyPendingSystemSoundIfAllowed() {
        if (pendingSystemSoundTrackId < 0L || !SystemSoundSetter.canWriteSettings(this)) return;
        Track track = libraryById.get(pendingSystemSoundTrackId);
        long id = pendingSystemSoundTrackId;
        int type = pendingSystemSoundType;
        String label = pendingSystemSoundLabel;
        pendingSystemSoundTrackId = -1L;
        pendingSystemSoundType = 0;
        pendingSystemSoundLabel = "";
        if (track == null) {
            Toast.makeText(this, "Pjesma više nije dostupna u katalogu", Toast.LENGTH_SHORT).show();
            return;
        }
        applySystemSound(track, type, label);
    }

    private void applySystemSound(Track track, int type, String label) {
        boolean ok = SystemSoundSetter.setAs(this, track, type);
        if (ok) Toast.makeText(this, (label == null ? "Sistemski zvuk" : label) + " postavljeno", Toast.LENGTH_SHORT).show();
        else Toast.makeText(this, "Android nije dopustio postavljanje ove pjesme kao sistemskog zvuka", Toast.LENGTH_LONG).show();
    }

    private LinearLayout buildCompactTrackOptionsPanel(Track track) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(9), dp(14), dp(7));

        TextView title = premiumDialogTitle(track.title);
        title.setTextSize(15);
        title.setTextColor(ThemeSupport.accent(this));
        title.setMaxLines(2);
        panel.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View divider = new View(this);
        divider.setBackgroundColor(ThemeSupport.divider(this));
        LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dividerLp.topMargin = dp(7);
        dividerLp.bottomMargin = dp(3);
        panel.addView(divider, dividerLp);
        return panel;
    }

    private void addCompactMenuItem(LinearLayout panel, int iconResId, String label, Runnable action) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextColor(ThemeSupport.text(this));
        item.setTextSize(13);
        item.setGravity(android.view.Gravity.CENTER_VERTICAL);
        item.setMinHeight(dp(34));
        item.setPadding(dp(5), dp(3), dp(5), dp(3));
        if (iconResId != 0) {
            android.graphics.drawable.Drawable icon = getDrawable(iconResId);
            if (icon != null) {
                icon = icon.mutate();
                icon.setTint(ThemeSupport.text2(this));
                item.setCompoundDrawablesWithIntrinsicBounds(icon, null, null, null);
                item.setCompoundDrawablePadding(dp(9));
            }
        }
        TypedValue out = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.selectableItemBackground, out, true) && out.resourceId != 0) {
            item.setBackgroundResource(out.resourceId);
        }
        item.setOnClickListener(v -> action.run());
        panel.addView(item, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private int playerDuplicateCount(List<Track> tracks) {
        if (engine == null || tracks == null || tracks.isEmpty()) return 0;
        HashSet<Long> seen = new HashSet<>();
        for (Track t : engine.getQueueSnapshot()) seen.add(t.id);
        int count = 0;
        for (Track t : tracks) {
            if (!seen.add(t.id)) count++;
        }
        return count;
    }

    private List<Track> onlyNewForPlayer(List<Track> tracks) {
        ArrayList<Track> out = new ArrayList<>();
        if (engine == null || tracks == null) return out;
        HashSet<Long> seen = new HashSet<>();
        for (Track t : engine.getQueueSnapshot()) seen.add(t.id);
        for (Track t : tracks) if (seen.add(t.id)) out.add(t);
        return out;
    }

    private void commitTracksToPlayer(List<Track> tracks, int insertAt, String label) {
        if (engine == null || tracks == null || tracks.isEmpty()) return;
        if (insertAt >= 0) engine.insertTracks(insertAt, tracks); else engine.addTracks(tracks);
        String msg = tracks.size() == 1 ? "Dodano u red reprodukcije" : "Dodano " + tracks.size() + " pjesama u red reprodukcije";
        if (label != null && !label.isEmpty()) msg += " · " + label;
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void addTracksToPlayerWithDuplicateCheck(List<Track> tracks, int insertAt, String label) {
        if (engine == null || tracks == null || tracks.isEmpty()) return;
        int duplicates = playerDuplicateCount(tracks);
        if (duplicates <= 0) {
            commitTracksToPlayer(tracks, insertAt, label);
            return;
        }
        if (tracks.size() == 1) {
            Track track = tracks.get(0);
            LinearLayout panel = premiumDialogPanel();
            panel.addView(premiumDialogTitle("Pjesma je već u Playeru"));
            panel.addView(premiumDialogBody("‘" + track.title + "’ već se nalazi u redu reprodukcije. Želiš li je dodati još jednom?", false));
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setView(panel)
                    .setNegativeButton("ODUSTANI", null)
                    .setPositiveButton("DODAJ PONOVNO", (d,w) -> commitTracksToPlayer(tracks, insertAt, label))
                    .create();
            showPremiumDialog(dialog);
            return;
        }
        LinearLayout panel = premiumDialogPanel();
        panel.addView(premiumDialogTitle("Neke pjesme su već u Playeru"));
        panel.addView(premiumDialogBody(duplicates + " od " + tracks.size() + " pjesama već se nalazi u redu reprodukcije.", false));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .setNegativeButton("ODUSTANI", null)
                .setNeutralButton("DODAJ SAMO NOVE", (d,w) -> {
                    List<Track> fresh = onlyNewForPlayer(tracks);
                    if (!fresh.isEmpty()) commitTracksToPlayer(fresh, insertAt, label);
                    else Toast.makeText(this, "Sve odabrane pjesme već su u Playeru", Toast.LENGTH_SHORT).show();
                })
                .setPositiveButton("DODAJ SVE", (d,w) -> commitTracksToPlayer(tracks, insertAt, label))
                .create();
        showPremiumDialog(dialog);
    }

    private void enterMultiSelectMode(long initialTrackId) {
        multiSelectMode = true;
        selectedCatalogTrackId = -1L;
        if (catalogAdapter != null) catalogAdapter.setSelectedTrackId(-1L);
        multiSelectedIds.clear();
        if (initialTrackId >= 0) multiSelectedIds.add(initialTrackId);
        updateMultiSelectUi();
    }

    private void toggleMultiSelection(long trackId) {
        if (!multiSelectMode) return;
        if (multiSelectedIds.contains(trackId)) multiSelectedIds.remove(trackId); else multiSelectedIds.add(trackId);
        updateMultiSelectUi();
    }

    private void selectAllVisibleTracks() {
        if (!multiSelectMode || catalogAdapter == null) return;
        for (CatalogEntry e : catalogAdapter.getEntriesSnapshot()) {
            if (e.kind == CatalogEntry.Kind.TRACK && e.track != null) multiSelectedIds.add(e.track.id);
        }
        updateMultiSelectUi();
    }

    private void updateMultiSelectUi() {
        if (multiSelectBar != null) multiSelectBar.setVisibility(multiSelectMode ? View.VISIBLE : View.GONE);
        if (multiSelectCount != null) multiSelectCount.setText(multiSelectedIds.size() + " odabrano");
        if (bulkEditButton != null) bulkEditButton.setEnabled(!multiSelectedIds.isEmpty());
        if (catalogAdapter != null) catalogAdapter.setMultiSelection(multiSelectMode, multiSelectedIds);
    }

    private void exitMultiSelectMode() {
        multiSelectMode = false;
        multiSelectedIds.clear();
        updateMultiSelectUi();
    }

    private List<Track> selectedTracksForBulkEdit() {
        ArrayList<Track> tracks = new ArrayList<>();
        for (Long id : multiSelectedIds) {
            Track t = libraryById.get(id);
            if (t != null) tracks.add(t);
        }
        return tracks;
    }

    private void showBulkEditDialog() {
        List<Track> tracks = selectedTracksForBulkEdit();
        if (tracks.isEmpty()) return;
        int pad = dp(18);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, dp(8), pad, 0);
        TextView note = premiumDialogBody("Prazno polje ostavlja postojeću vrijednost svake pjesme. Upiši samo ono što želiš postaviti svima.", false);
        note.setPadding(0, 0, 0, dp(10));
        box.addView(note);
        EditText titleInput = createEditorField("Isti naziv pjesme za sve (opcionalno)", "");
        EditText artistInput = createEditorField("Izvođač", "");
        EditText albumInput = createEditorField("Album", "");
        EditText yearInput = createEditorField("Godina", "");
        yearInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        box.addView(titleInput); box.addView(artistInput); box.addView(albumInput); box.addView(yearInput);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Uredi " + tracks.size() + " pjesama")
                .setView(box)
                .setPositiveButton("Spremi svima", (d,w) -> {
                    String commonTitle = titleInput.getText().toString().trim();
                    String commonArtist = artistInput.getText().toString().trim();
                    String commonAlbum = albumInput.getText().toString().trim();
                    String y = yearInput.getText().toString().trim();
                    Integer commonYear = null;
                    if (!y.isEmpty()) try { commonYear = Integer.parseInt(y); } catch (Exception ignored) {}
                    for (Track track : tracks) {
                        String title = commonTitle.isEmpty() ? track.title : commonTitle;
                        String artist = commonArtist.isEmpty() ? track.artist : commonArtist;
                        String album = commonAlbum.isEmpty() ? track.album : commonAlbum;
                        int year = commonYear == null ? track.year : Math.max(0, commonYear);
                        TrackMetadataStore.save(this, track, title, artist, album, year);
                        Track updated = TrackMetadataStore.apply(this, track);
                        if (engine != null) engine.refreshTrackMetadata(updated);
                    }
                    exitMultiSelectMode();
                    scanLibrary();
                    Toast.makeText(this, "Ažurirano " + tracks.size() + " pjesama", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Odustani", null)
                .create();
        showPremiumDialog(dialog);
    }

    private void showTrackDetails(Track track) {
        if (track == null) return;
        executor.execute(() -> {
            AudioTechnicalInfo tech = AudioTechnicalInfo.read(MainActivity.this, track);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                StringBuilder details = new StringBuilder();
                details.append("Izvođač: ").append(track.artist).append("\n");
                details.append("Album: ").append(track.album).append("\n");
                if (track.year > 0) details.append("Godina: ").append(track.year).append("\n");
                details.append("\nTEHNIČKI PODACI\n");
                details.append("Format: ").append(tech.format).append("\n");
                details.append("Bitrate: ").append(tech.bitrateLabel()).append("\n");
                details.append("Sample rate: ").append(tech.sampleRateLabel()).append("\n");
                details.append("Kanali: ").append(tech.channelsLabel()).append("\n");
                if (tech.bitDepth > 0) details.append("Bit depth: ").append(tech.bitDepth).append("-bit\n");
                details.append("Trajanje: ").append(TimeFormat.format(track.durationMs)).append("\n");
                if (track.sizeBytes > 0) details.append("Veličina: ").append(formatFileSize(track.sizeBytes)).append("\n");
                if (!tech.mime.isEmpty()) details.append("MIME: ").append(tech.mime).append("\n");
                details.append(track.relativePath == null || track.relativePath.isEmpty()
                        ? "Lokacija: Interna memorija"
                        : "Mapa: " + TrackNameParser.cleanDisplayPath(track.relativePath));
                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle(track.title)
                        .setMessage(details.toString())
                        .setPositiveButton("U redu", null)
                        .create();
                showPremiumDialog(dialog);
            });
        });
    }

    private String formatFileSize(long bytes) {
        if (bytes <= 0) return "Nije dostupno";
        double mb = bytes / (1024.0 * 1024.0);
        if (mb >= 1.0) return String.format(Locale.US, "%.1f MB", mb);
        return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
    }

    private void showEditTrackDialog(Track track) {
        if (track == null) return;
        int pad = dp(16);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, dp(6), pad, 0);

        EditText titleInput = createEditorField("Naziv pjesme", track.title);
        EditText artistInput = createEditorField("Izvođač", track.artist);
        EditText albumInput = createEditorField("Album", track.album);
        EditText yearInput = createEditorField("Godina", track.year > 0 ? String.valueOf(track.year) : "");
        yearInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        box.addView(titleInput); box.addView(artistInput); box.addView(albumInput); box.addView(yearInput);

        Button coverButton = new Button(this);
        coverButton.setAllCaps(false);
        coverButton.setMinHeight(0);
        coverButton.setText(LocalArtworkStore.has(this, track.id) ? "Promijeni lokalni cover" : "Odaberi cover s uređaja");
        coverButton.setTextColor(ThemeSupport.accent(this));
        coverButton.setTextSize(13);
        coverButton.setBackgroundResource(R.drawable.bg_chip);
        LinearLayout.LayoutParams coverLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        coverLp.topMargin = dp(2);
        coverLp.bottomMargin = dp(4);
        box.addView(coverButton, coverLp);
        coverButton.setOnClickListener(v -> openCoverPicker(track));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Uredi podatke")
                .setView(box)
                .setPositiveButton("Spremi", (d, w) -> {
                    int year = 0;
                    try { year = Integer.parseInt(yearInput.getText().toString().trim()); } catch (Exception ignored) {}
                    TrackMetadataStore.save(this, track, titleInput.getText().toString(), artistInput.getText().toString(), albumInput.getText().toString(), year);
                    Track updated = TrackMetadataStore.apply(this, track);
                    if (engine != null) engine.refreshTrackMetadata(updated);
                    scanLibrary();
                    Toast.makeText(this, "Podaci su spremljeni", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Odustani", null)
                .create();
        showPremiumDialog(dialog);
    }

    private void openCoverPicker(Track track) {
        if (track == null) return;
        pendingCoverTrackId = track.id;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_COVER_IMAGE);
    }

    private void applyPickedCover(Uri uri) {
        long trackId = pendingCoverTrackId;
        pendingCoverTrackId = -1L;
        if (uri == null || trackId < 0L) return;
        executor.execute(() -> {
            boolean saved = LocalArtworkStore.save(MainActivity.this, trackId, uri);
            runOnUiThread(() -> {
                if (!saved) {
                    Toast.makeText(MainActivity.this, "Cover se nije mogao učitati", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (artworkLoader != null) artworkLoader.invalidateTrack(trackId);
                if (catalogAdapter != null) catalogAdapter.notifyDataSetChanged();
                if (queueAdapter != null) queueAdapter.notifyDataSetChanged();
                if (mobileQueueAdapter != null) mobileQueueAdapter.notifyDataSetChanged();
                refreshPlayerViews();
                if (fullscreenNowPlayingOverlay != null && fullscreenNowPlayingOverlay.getVisibility() == View.VISIBLE) refreshFullscreenNowPlaying();
                Toast.makeText(MainActivity.this, "Lokalni cover je spremljen", Toast.LENGTH_SHORT).show();
            });
        });
    }

    private EditText createEditorField(String hint, String value) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setText(value == null ? "" : value);
        input.setTextColor(ThemeSupport.text(this));
        input.setHintTextColor(ThemeSupport.text3(this));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        input.setLayoutParams(lp);
        return input;
    }

    private void showAddToPlaylistDialog(List<Track> tracks) {
        if (tracks == null || tracks.isEmpty()) return;
        ArrayList<String> names = new ArrayList<>(PlaylistStore.names(this));
        names.add(0, "+ Nova playlista");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Dodaj u spremljenu playlistu")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    if (which == 0) showCreatePlaylistDialog(tracks);
                    else {
                        String name = names.get(which);
                        addTracksToNamedPlaylistWithDuplicateCheck(name, tracks);
                    }
                })
                .create();
        showPremiumDialog(dialog);
    }

    private void addTracksToNamedPlaylistWithDuplicateCheck(String name, List<Track> tracks) {
        if (name == null || tracks == null || tracks.isEmpty()) return;
        int duplicates = PlaylistStore.duplicateCount(this, name, tracks);
        if (duplicates <= 0) {
            PlaylistStore.append(this, name, tracks);
            Toast.makeText(this, "Dodano u playlistu: " + name, Toast.LENGTH_SHORT).show();
            if (section == Section.PLAYLISTS && detailParent == null) showPlaylists();
            return;
        }
        if (tracks.size() == 1) {
            Track track = tracks.get(0);
            showDuplicateTrackDialog(name, track);
        } else {
            showDuplicateBatchDialog(name, tracks, duplicates);
        }
    }

    private void showDuplicateTrackDialog(String playlistName, Track track) {
        LinearLayout panel = premiumDialogPanel();
        TextView title = premiumDialogTitle("Pjesma je već u playlisti");
        panel.addView(title);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(12), 0, dp(8));
        ImageView art = new ImageView(this);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        row.addView(art, new LinearLayout.LayoutParams(dp(56), dp(56)));
        artworkLoader.load(track, art);
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(12),0,0,0);
        TextView song = premiumDialogBody(track.title, true); info.addView(song);
        TextView artist = premiumDialogBody(track.artist, false); artist.setTextColor(ThemeSupport.text2(this)); info.addView(artist);
        row.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(row);
        TextView message = premiumDialogBody("Ova pjesma se već nalazi u playlisti ‘" + playlistName + "’. Želiš li je dodati ponovno?", false);
        panel.addView(message);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .setNegativeButton("ODUSTANI", null)
                .setPositiveButton("DODAJ PONOVNO", (d,w) -> { PlaylistStore.append(this, playlistName, java.util.Collections.singletonList(track)); Toast.makeText(this, "Dodano ponovno", Toast.LENGTH_SHORT).show(); })
                .create();
        showPremiumDialog(dialog);
    }

    private void showDuplicateBatchDialog(String playlistName, List<Track> tracks, int duplicates) {
        LinearLayout panel = premiumDialogPanel();
        panel.addView(premiumDialogTitle("Neke pjesme već postoje"));
        panel.addView(premiumDialogBody(duplicates + " od " + tracks.size() + " pjesama već se nalazi u playlisti ‘" + playlistName + "’.", false));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .setNegativeButton("ODUSTANI", null)
                .setNeutralButton("DODAJ SAMO NOVE", (d,w) -> {
                    List<Track> fresh = PlaylistStore.onlyNew(this, playlistName, tracks);
                    if (!fresh.isEmpty()) PlaylistStore.append(this, playlistName, fresh);
                    Toast.makeText(this, "Dodano " + fresh.size() + " novih pjesama", Toast.LENGTH_SHORT).show();
                })
                .setPositiveButton("DODAJ SVE", (d,w) -> { PlaylistStore.append(this, playlistName, tracks); Toast.makeText(this, "Dodane sve pjesme", Toast.LENGTH_SHORT).show(); })
                .create();
        showPremiumDialog(dialog);
    }

    private LinearLayout premiumDialogPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(14), dp(18), dp(8));
        return panel;
    }

    private TextView premiumDialogTitle(String text) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(ThemeSupport.text(this)); v.setTextSize(17); v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        return v;
    }

    private TextView premiumDialogBody(String text, boolean strong) {
        TextView v = new TextView(this); v.setText(text); v.setTextColor(ThemeSupport.text2(this)); v.setTextSize(strong ? 15 : 13);
        if (strong) v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        v.setPadding(0, dp(4), 0, dp(4));
        return v;
    }

    private void styleMobileMiniPlayer() {
        if (playerBar == null) return;
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{colorWithAlpha(ThemeSupport.card(this), 242), colorWithAlpha(ThemeSupport.panel(this), 235)});
        bg.setCornerRadius(dp(24));
        bg.setStroke(dp(1), colorWithAlpha(ThemeSupport.accent(this), 150));
        playerBar.setBackground(bg);
    }

    private int colorWithAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((Math.max(0, Math.min(255, alpha))) << 24);
    }

    private int compactDialogWidthPx() {
        int screen = getResources().getDisplayMetrics().widthPixels;
        return Math.max(dp(280), Math.min(dp(470), screen - dp(28)));
    }

    private int compactTrackMenuWidthPx() {
        int screen = getResources().getDisplayMetrics().widthPixels;
        return Math.max(dp(260), Math.min(dp(360), screen - dp(52)));
    }

    private void showCompactTrackMenuDialog(AlertDialog dialog) {
        showPremiumDialog(dialog, compactTrackMenuWidthPx());
    }

    private void showPremiumDialog(AlertDialog dialog) {
        showPremiumDialog(dialog, compactDialogWidthPx());
    }

    private void showPremiumDialog(AlertDialog dialog, int dialogWidthPx) {
        dialog.setOnShowListener(d -> {
            Window window = dialog.getWindow();
            if (window != null) {
                GradientDrawable dialogBackground = new GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        new int[]{colorWithAlpha(ThemeSupport.card(this), 232), colorWithAlpha(ThemeSupport.panel(this), 216)});
                dialogBackground.setCornerRadius(dp(20));
                dialogBackground.setStroke(dp(1), colorWithAlpha(ThemeSupport.accent(this), 118));
                dialogBackground.setAlpha(246);
                window.setBackgroundDrawable(dialogBackground);
                android.view.WindowManager.LayoutParams lp = window.getAttributes();
                lp.dimAmount = 0.34f;
                window.setAttributes(lp);
                window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                window.setLayout(dialogWidthPx, ViewGroup.LayoutParams.WRAP_CONTENT);
            }

            int alertTitleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView alertTitle = alertTitleId == 0 ? null : dialog.findViewById(alertTitleId);
            if (alertTitle != null) {
                alertTitle.setTextColor(ThemeSupport.accent(this));
                alertTitle.setTextSize(16);
            }
            TextView message = dialog.findViewById(android.R.id.message);
            if (message != null) {
                message.setTextColor(ThemeSupport.text2(this));
                message.setTextSize(13);
                message.setLineSpacing(0f, 1.08f);
            }
            ListView list = dialog.getListView();
            if (list != null) {
                list.setDividerHeight(0);
                list.setPadding(dp(4), 0, dp(4), dp(4));
                list.setBackgroundColor(Color.TRANSPARENT);
            }
            Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            if (positive != null) { positive.setTextColor(ThemeSupport.accent(this)); positive.setTextSize(12); }
            Button neutral = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
            if (neutral != null) { neutral.setTextColor(ThemeSupport.text(this)); neutral.setTextSize(12); }
            Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            if (negative != null) { negative.setTextColor(ThemeSupport.text2(this)); negative.setTextSize(12); }
        });
        dialog.show();
    }

    private void showCreatePlaylistDialog(List<Track> tracks) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Naziv playliste");
        input.setTextColor(ThemeSupport.text(this));
        input.setHintTextColor(ThemeSupport.text3(this));
        int pad = dp(18);
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(pad, dp(8), pad, 0);
        wrapper.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Nova playlista")
                .setView(wrapper)
                .setPositiveButton("Spremi", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) return;
                    PlaylistStore.save(this, name, tracks);
                    Toast.makeText(this, "Spremljeno: " + name, Toast.LENGTH_SHORT).show();
                    if (section == Section.PLAYLISTS && detailParent == null) showPlaylists();
                })
                .setNegativeButton("Odustani", null)
                .create();
        showPremiumDialog(dialog);
    }

    private void startCatalogDrag(View source, List<Track> tracks, String label) {
        if (tracks == null || tracks.isEmpty()) return;
        ClipData data = ClipData.newPlainText("sonorus-catalog", label == null ? "glazba" : label);
        source.startDragAndDrop(data, new View.DragShadowBuilder(source), new CatalogDragPayload(tracks, label), 0);
    }

    private void startQueueDrag(View source, int index) {
        queueDragInProgress = true;
        ClipData data = ClipData.newPlainText("sonorus-player-queue", String.valueOf(index));
        boolean started = source.startDragAndDrop(data, new View.DragShadowBuilder(source), new QueueDragPayload(index), 0);
        if (!started) queueDragInProgress = false;
    }

    private void installQueueDropTarget(ListView list, View panel) {
        list.setOnDragListener((v, event) -> {
            if (engine == null) return false;
            Object payload = event.getLocalState();
            if (!(payload instanceof CatalogDragPayload) && !(payload instanceof QueueDragPayload)) return false;
            QueueAdapter adapter = list == mobileQueueList ? mobileQueueAdapter : queueAdapter;
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    if (adapter != null) {
                        adapter.endDrag();
                        if (payload instanceof QueueDragPayload) adapter.beginDrag(((QueueDragPayload) payload).originalIndex);
                    }
                    return true;
                case DragEvent.ACTION_DRAG_ENTERED:
                    return true;
                case DragEvent.ACTION_DRAG_LOCATION: {
                    int insertion = rowAt(list, event.getX(), event.getY(), true);
                    int queueSize = engine.getQueueSnapshot().size();
                    if (insertion < 0) insertion = queueSize;
                    if (payload instanceof QueueDragPayload) {
                        QueueDragPayload q = (QueueDragPayload) payload;
                        q.targetInsertionIndex = insertion;
                        if (adapter != null) {
                            int preview = insertion > q.originalIndex ? insertion - 1 : insertion;
                            preview = Math.max(0, Math.min(preview, Math.max(0, queueSize - 1)));
                            adapter.updateDropIndex(preview);
                        }
                    }

                    float edge = dp(56);
                    if (event.getY() < edge) list.smoothScrollBy(-dp(34), 70);
                    else if (event.getY() > list.getHeight() - edge) list.smoothScrollBy(dp(34), 70);
                    return true;
                }
                case DragEvent.ACTION_DROP:
                    if (payload instanceof CatalogDragPayload) {
                        int target = rowAt(list, event.getX(), event.getY(), true);
                        if (target < 0) target = engine.getQueueSnapshot().size();
                        CatalogDragPayload cp = (CatalogDragPayload) payload;
                        addTracksToPlayerWithDuplicateCheck(cp.tracks, target, cp.label);
                    } else {
                        QueueDragPayload q = (QueueDragPayload) payload;
                        int queueSize = engine.getQueueSnapshot().size();
                        int insertion = rowAt(list, event.getX(), event.getY(), true);
                        if (insertion < 0) insertion = q.targetInsertionIndex;
                        if (insertion < 0) insertion = queueSize;
                        int target = Math.max(0, Math.min(insertion, queueSize));
                        int finalIndex = target > q.originalIndex ? target - 1 : target;
                        finalIndex = Math.max(0, Math.min(finalIndex, Math.max(0, queueSize - 1)));
                        if (finalIndex != q.originalIndex) engine.moveItem(q.originalIndex, finalIndex);
                    }
                    if (adapter != null) adapter.endDrag();
                    return true;
                case DragEvent.ACTION_DRAG_EXITED:
                    if (adapter != null) adapter.updateDropIndex(-1);
                    return true;
                case DragEvent.ACTION_DRAG_ENDED:
                    queueDragInProgress = false;
                    if (queueAdapter != null) queueAdapter.endDrag();
                    if (mobileQueueAdapter != null) mobileQueueAdapter.endDrag();
                    return true;
            }
            return false;
        });
    }

    private int rowAt(ListView list, float x, float y, boolean insertionPoint) {
        int pos = list.pointToPosition((int) x, (int) y);
        if (pos == ListView.INVALID_POSITION) return insertionPoint ? list.getCount() : -1;
        if (!insertionPoint) return pos;
        int childIndex = pos - list.getFirstVisiblePosition();
        View child = childIndex >= 0 && childIndex < list.getChildCount() ? list.getChildAt(childIndex) : null;
        if (child != null && y > child.getBottom() - child.getHeight() / 2f) return pos + 1;
        return pos;
    }

    private void showSavePlaylistDialog() {
        if (engine == null || engine.getQueueSnapshot().isEmpty()) {
            Toast.makeText(this, "Red reprodukcije je prazan", Toast.LENGTH_SHORT).show();
            return;
        }
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Naziv playliste");
        input.setTextColor(ThemeSupport.text(this));
        input.setHintTextColor(ThemeSupport.text3(this));
        int pad = dp(18);
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(pad, dp(8), pad, 0);
        wrapper.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Spremi playlistu")
                .setView(wrapper)
                .setPositiveButton("Spremi", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) return;
                    PlaylistStore.save(this, name, engine.getQueueSnapshot());
                    Toast.makeText(this, "Spremljeno: " + name, Toast.LENGTH_SHORT).show();
                    if (section == Section.PLAYLISTS && detailParent == null) showPlaylists();
                })
                .setNegativeButton("Odustani", null)
                .create();
        showPremiumDialog(dialog);
    }

    private void confirmHideTrack(Track track) {
        if (track == null) return;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Ukloniti iz Sonorusa?")
                .setMessage(track.title + "\n\nPjesma će biti skrivena iz Sonorus kataloga. Originalna audio datoteka ostaje na uređaju.")
                .setNegativeButton("Odustani", null)
                .setPositiveButton("Ukloni", (d,w) -> {
                    HiddenTrackStore.hide(this, track.id);
                    if (engine != null) {
                        List<Track> q = engine.getQueueSnapshot();
                        for (int i = q.size() - 1; i >= 0; i--) if (q.get(i).id == track.id) engine.removeAt(i);
                    }
                    selectedCatalogTrackId = -1L;
                    scanLibrary();
                })
                .create();
        showPremiumDialog(dialog);
    }

    private void showPlaylistOptions(String name) {
        if (name == null || name.trim().isEmpty()) return;
        String[] items = {"Otvori", "Preimenuj", "Pomakni gore", "Pomakni dolje", "Obriši"};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(name)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        detailParent = Section.PLAYLISTS;
                        contextTitle.setText(name);
                        setBaseEntries(MediaLibrary.trackEntries(MediaLibrary.tracksFromIds(PlaylistStore.loadIds(this, name), libraryById)));
                    } else if (which == 1) showRenamePlaylistDialog(name);
                    else if (which == 2) { PlaylistStore.move(this, name, -1); showPlaylists(); }
                    else if (which == 3) { PlaylistStore.move(this, name, 1); showPlaylists(); }
                    else if (which == 4) confirmDeletePlaylist(name);
                }).create();
        showPremiumDialog(dialog);
    }

    private void showRenamePlaylistDialog(String oldName) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(oldName);
        input.setSelection(input.getText().length());
        input.setTextColor(ThemeSupport.text(this));
        input.setHintTextColor(ThemeSupport.text3(this));
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(dp(18), dp(8), dp(18), 0);
        wrapper.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Preimenuj playlistu")
                .setView(wrapper)
                .setNegativeButton("Odustani", null)
                .setPositiveButton("Spremi", (d,w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) return;
                    if (!PlaylistStore.rename(this, oldName, name)) {
                        Toast.makeText(this, "Naziv već postoji ili nije valjan", Toast.LENGTH_SHORT).show();
                    }
                    showPlaylists();
                }).create();
        showPremiumDialog(dialog);
    }

    private void confirmDeletePlaylist(String name) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Obrisati playlistu?")
                .setMessage(name + "\n\nGlazbene datoteke neće biti obrisane.")
                .setPositiveButton("Obriši", (d, w) -> {
                    PlaylistStore.delete(this, name);
                    showPlaylists();
                })
                .setNegativeButton("Odustani", null)
                .create();
        showPremiumDialog(dialog);
    }

    private void confirmClearQueue() {
        if (engine == null || engine.getQueueSnapshot().isEmpty()) return;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Očistiti Player?")
                .setMessage("Uklonit će se cijeli red reprodukcije iz Playera. Glazbene datoteke ostaju na uređaju.")
                .setPositiveButton("Očisti", (d, w) -> engine.clearQueue())
                .setNegativeButton("Odustani", null)
                .create();
        showPremiumDialog(dialog);
    }

    private void toggleRepeatList() {
        if (engine == null) return;
        engine.setRepeatMode(engine.getRepeatMode() == AudioEngine.REPEAT_ALL ? AudioEngine.REPEAT_OFF : AudioEngine.REPEAT_ALL);
    }

    private void toggleRepeatOne() {
        if (engine == null) return;
        engine.setRepeatMode(engine.getRepeatMode() == AudioEngine.REPEAT_ONE ? AudioEngine.REPEAT_OFF : AudioEngine.REPEAT_ONE);
    }

    private void setModeButton(Button b, boolean active) {
        if (b == null) return;
        b.setBackgroundResource(active ? R.drawable.bg_mode_active : R.drawable.bg_mode_idle);
        b.setTextColor(active ? ThemeSupport.text(this) : ThemeSupport.text2(this));
    }

    private void showCrossfadeDialog() {
        if (engine == null) return;
        int pad = dp(18);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, dp(8), pad, dp(4));
        Switch enabled = new Switch(this); enabled.setText("Crossfade uključen"); enabled.setTextColor(ThemeSupport.text(this)); enabled.setChecked(engine.isCrossfadeEnabled());
        box.addView(enabled, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        TextView label = new TextView(this); label.setText("Trajanje prijelaza"); label.setTextColor(ThemeSupport.text2(this)); label.setTextSize(12); label.setPadding(0,dp(10),0,dp(4)); box.addView(label);
        RadioGroup group = new RadioGroup(this); group.setOrientation(RadioGroup.HORIZONTAL);
        int[] vals={5,10,15};
        for(int v:vals){ RadioButton r=new RadioButton(this); r.setText(v+" s"); r.setTextColor(ThemeSupport.text(this)); r.setId(1000+v); r.setChecked(engine.getCrossfadeSeconds()==v); group.addView(r,new RadioGroup.LayoutParams(0,dp(46),1f)); }
        box.addView(group);
        Switch fade = new Switch(this); fade.setText("Fade In / Fade Out"); fade.setTextColor(ThemeSupport.text(this)); fade.setChecked(engine.isFadeInOutEnabled()); box.addView(fade,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48)));
        TextView modeLabel = new TextView(this); modeLabel.setText("Način prijelaza"); modeLabel.setTextColor(ThemeSupport.text2(this)); modeLabel.setTextSize(12); modeLabel.setPadding(0,dp(10),0,dp(4)); box.addView(modeLabel);
        RadioGroup modeGroup = new RadioGroup(this); modeGroup.setOrientation(RadioGroup.VERTICAL);
        String[] modeNames = {"Standardni", "Pametni", "Radio Mix"};
        for (int i=0;i<3;i++) { RadioButton r=new RadioButton(this); r.setId(2000+i); r.setText(modeNames[i]); r.setTextColor(ThemeSupport.text(this)); r.setChecked(engine.getCrossfadeMode()==i); modeGroup.addView(r,new RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(42))); }
        box.addView(modeGroup);
        TextView desc = new TextView(this); desc.setText("Pametni i Radio Mix analiziraju stvarni početak i završetak pjesama, pamte analizu lokalno, preskaču nepotrebnu tišinu i koriste equal-power miks. Radio Mix radi malo aktivnije, poput radijskog AutoDJ-a."); desc.setTextColor(ThemeSupport.text3(this)); desc.setTextSize(11); desc.setPadding(0,dp(6),0,0); box.addView(desc);
        Runnable state=()->{ group.setEnabled(enabled.isChecked()); fade.setEnabled(enabled.isChecked()); modeGroup.setEnabled(enabled.isChecked()); for(int i=0;i<group.getChildCount();i++) group.getChildAt(i).setEnabled(enabled.isChecked()); for(int i=0;i<modeGroup.getChildCount();i++) modeGroup.getChildAt(i).setEnabled(enabled.isChecked()); };
        enabled.setOnCheckedChangeListener((b,c)->state.run()); state.run();
        AlertDialog cfDialog = new AlertDialog.Builder(this).setTitle("Crossfade").setView(box).setPositiveButton("Spremi",(d,w)->{
            engine.setCrossfadeEnabled(enabled.isChecked());
            int checked=group.getCheckedRadioButtonId();
            engine.setCrossfadeSeconds(checked==1010?10:checked==1015?15:5);
            engine.setFadeInOutEnabled(fade.isChecked());
            int modeId=modeGroup.getCheckedRadioButtonId();
            engine.setCrossfadeMode(modeId==2002?AudioEngine.CROSSFADE_RADIO:modeId==2001?AudioEngine.CROSSFADE_SMART:AudioEngine.CROSSFADE_STANDARD);
        }).setNegativeButton("Odustani",null).create();
        showPremiumDialog(cfDialog);
    }

    private void ensureAudioPermissionAndScan() {
        if (hasAudioPermission()) {
            permissionPanel.setVisibility(View.GONE);
            scanLibrary();
            ensureNotificationPermission();
        } else {
            permissionPanel.setVisibility(View.VISIBLE);
            catalogGrid.setVisibility(View.GONE);
        }
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private boolean hasAudioPermission() {
        String p = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAudioPermission() {
        String p = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        requestPermissions(new String[]{p}, REQUEST_AUDIO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_COVER_IMAGE) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingCoverTrackId = -1L;
            return;
        }
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        applyPickedCover(uri);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                permissionPanel.setVisibility(View.GONE);
                catalogGrid.setVisibility(section == Section.SETTINGS ? View.GONE : View.VISIBLE);
                scanLibrary();
                ensureNotificationPermission();
            } else {
                permissionPanel.setVisibility(View.VISIBLE);
            }
        }
    }

    private void scanLibrary() {
        if (!hasAudioPermission()) {
            ensureAudioPermissionAndScan();
            return;
        }
        contextMeta.setText("Skeniram glazbu…");
        executor.execute(() -> {
            List<Track> rawTracks = MediaLibrary.queryTracks(this);
            ArrayList<Track> tracks = new ArrayList<>();
            for (Track track : rawTracks) if (!HiddenTrackStore.isHidden(this, track.id)) tracks.add(track);
            List<MediaLibrary.GenreInfo> foundGenres = MediaLibrary.queryGenres(this);
            runOnUiThread(() -> {
                library.clear();
                library.addAll(tracks);
                genres.clear();
                genres.addAll(foundGenres);
                libraryById.clear();
                libraryById.putAll(MediaLibrary.mapById(library));
                libraryLoaded = true;
                catalogAdapter.setLibrary(library);
                catalogAdapter.refreshFavorites();
                if (engine != null && !engine.getQueueSnapshot().isEmpty()) {
                    java.util.ArrayList<Long> queueIds = new java.util.ArrayList<>();
                    for (Track qTrack : engine.getQueueSnapshot()) queueIds.add(qTrack.id);
                    engine.setQueue(MediaLibrary.tracksFromIds(queueIds, libraryById), false);
                }
                restoreQueueIfPossible();
                selectSection(section);
                Toast.makeText(this, "Pronađeno " + library.size() + " pjesama", Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void restoreQueueIfPossible() {
        if (!libraryLoaded || engine == null || !engine.getQueueSnapshot().isEmpty()) return;
        List<Track> restored = MediaLibrary.tracksFromIds(IdStore.getLastQueueIds(this), libraryById);
        if (!restored.isEmpty()) engine.setQueue(restored, false);
    }

    private boolean preparePlayback() {
        startPlaybackService();
        return playbackService == null || playbackService.prepareForPlayback();
    }

    private void startPlaybackService() {
        try {
            // Reprodukciju pokrećemo iz vidljive Activity. Običan startService
            // izbjegava Androidov 5-sekundni foreground timeout prije nego MediaPlayer
            // stvarno prijeđe u PLAYING; servis sam poziva startForeground čim zvuk krene.
            startService(new Intent(this, PlaybackService.class));
        } catch (Exception ignored) {}
    }

    @Override public void onQueueChanged() {
        refreshQueueViews();
    }

    @Override public void onTrackChanged(Track track, int index) {
        refreshQueueViews();
        refreshPlayerViews();
        refreshFullscreenNowPlaying();
        scrollPlayerToCurrent(true);
    }

    @Override public void onPlaybackChanged(boolean playing) {
        playButton.setText(playing ? "❚❚" : "▶");
        if (mobileBottomPlayButton != null) mobileBottomPlayButton.setText(playing ? "❚❚" : "▶");
        if (mobileQueuePlayButton != null) mobileQueuePlayButton.setText(playing ? "❚❚" : "▶");
        heroPanel.setPlaying(playing);
        heroBars.setPlaying(playing);
        updateMobileMiniPlayerVisibility();
        updateQueueMeta(engine == null ? 0L : engine.getPosition(), playing);
        refreshFullscreenNowPlaying();
    }

    @Override public void onProgress(long positionMs, long durationMs) {
        if (activeCatalogPreviewTrackId >= 0L) return;
        long now = android.os.SystemClock.elapsedRealtime();
        boolean nearEnd = durationMs > 0L && durationMs - positionMs < 500L;
        if (!nearEnd && now - lastProgressUiMs < PROGRESS_UI_INTERVAL_MS) return;
        lastProgressUiMs = now;
        if (!userSeeking) {
            int p = durationMs > 0 ? (int) Math.min(1000L, positionMs * 1000L / durationMs) : 0;
            progressBar.setProgress(p);
            if (heroProgressBar != null) heroProgressBar.setProgress(p);
            if (mobileQueueProgress != null) mobileQueueProgress.setProgress(p);
        }
        String position = TimeFormat.format(positionMs);
        String duration = TimeFormat.format(durationMs);
        currentTime.setText(position);
        totalTime.setText(duration);
        if (heroCurrentTime != null) heroCurrentTime.setText(position);
        if (heroTotalTime != null) heroTotalTime.setText(duration);
        if (mobileQueueCurrentTime != null) mobileQueueCurrentTime.setText(position);
        if (mobileQueueTotalTime != null) mobileQueueTotalTime.setText(duration);
        updateQueueMeta(positionMs, engine != null && engine.isPlaying());
        updateFullscreenProgress(positionMs, durationMs);
    }

    @Override public void onModesChanged(boolean shuffle, int repeatMode, boolean crossfadeEnabled, int crossfadeSeconds, boolean fadeInOut, boolean smartCrossfade) {
        shuffleButton.setTextColor(shuffle ? ThemeSupport.accent(this) : ThemeSupport.text2(this));
        String repeatText = repeatMode == AudioEngine.REPEAT_ONE ? "↻1" : "↻";
        repeatButton.setText(repeatText);
        repeatButton.setTextColor(repeatMode == AudioEngine.REPEAT_OFF ? ThemeSupport.text2(this) : ThemeSupport.accent(this));
        if (mobileFullscreenShuffleButton != null) mobileFullscreenShuffleButton.setTextColor(shuffle ? ThemeSupport.accent(this) : ThemeSupport.text2(this));
        if (mobileFullscreenRepeatButton != null) {
            mobileFullscreenRepeatButton.setText(repeatText);
            mobileFullscreenRepeatButton.setTextColor(repeatMode == AudioEngine.REPEAT_OFF ? ThemeSupport.text2(this) : ThemeSupport.accent(this));
        }
        crossfadeButton.setText("Crossfade");
        mobileCrossfadeButton.setText("Crossfade");
        settingsCrossfadeButton.setText("Crossfade");
        setModeButton(repeatListModeButton, repeatMode == AudioEngine.REPEAT_ALL);
        setModeButton(mobileRepeatListModeButton, repeatMode == AudioEngine.REPEAT_ALL);
        setModeButton(randomModeButton, shuffle);
        setModeButton(mobileRandomModeButton, shuffle);
        setModeButton(repeatOneModeButton, repeatMode == AudioEngine.REPEAT_ONE);
        setModeButton(mobileRepeatOneModeButton, repeatMode == AudioEngine.REPEAT_ONE);
    }

    @Override public void onPlaybackError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void refreshQueueViews() {
        if (queueAdapter == null) return;
        List<Track> q = engine == null ? new ArrayList<>() : engine.getQueueSnapshot();
        int current = engine == null ? -1 : engine.getCurrentIndex();
        queueAdapter.setData(q, current);
        mobileQueueAdapter.setData(q, current);
        if (queueSearchAdapter != null) queueSearchAdapter.setQueue(q);
        if (mobileQueueSearchAdapter != null) mobileQueueSearchAdapter.setQueue(q);
        updateQueueMeta(engine == null ? 0L : engine.getPosition(), engine != null && engine.isPlaying());
    }

    private void updateQueueMeta(long positionMs, boolean includeRemaining) {
        if (queueMeta == null || mobileQueueMeta == null) return;
        List<Track> q = engine == null ? new ArrayList<>() : engine.getQueueSnapshot();
        long total = 0L;
        for (Track t : q) total += Math.max(0L, t.durationMs);
        String meta = q.size() + (q.size() == 1 ? " pjesma" : " pjesama") + " · ukupno " + TimeFormat.format(total);

        int current = engine == null ? -1 : engine.getCurrentIndex();
        if (includeRemaining && current >= 0 && current < q.size()) {
            long currentDuration = engine.getDuration();
            if (currentDuration <= 0L) currentDuration = Math.max(0L, q.get(current).durationMs);
            long remaining = Math.max(0L, currentDuration - Math.max(0L, positionMs));
            for (int i = current + 1; i < q.size(); i++) remaining += Math.max(0L, q.get(i).durationMs);
            meta += " · preostalo " + TimeFormat.format(remaining);
        }

        queueMeta.setText(meta);
        mobileQueueMeta.setText(meta);
        if (queueDurationTotal != null) queueDurationTotal.setText(TimeFormat.format(total));
    }

    private void scrollPlayerToCurrent(boolean respectUserInteraction) {
        if (engine == null || queueDragInProgress) return;
        int current = engine.getCurrentIndex();
        if (current < 0) return;
        if (respectUserInteraction && android.os.SystemClock.elapsedRealtime() - lastQueueTouchMs < 1400L) return;
        scrollListToCurrent(queueList, current);
        scrollListToCurrent(mobileQueueList, current);
    }

    private void scrollListToCurrent(ListView list, int position) {
        if (list == null || position < 0) return;
        list.post(() -> {
            if (position >= list.getCount() || queueDragInProgress) return;
            int offset = Math.max(0, list.getHeight() / 2 - dp(32));
            try { list.smoothScrollToPositionFromTop(position, offset, 220); }
            catch (Exception ignored) { list.setSelection(position); }
        });
    }

    private void refreshPlayerViews() {
        if (activeCatalogPreviewTrackId >= 0L) {
            Track previewTrack = libraryById.get(activeCatalogPreviewTrackId);
            if (previewTrack != null) {
                showCatalogPreviewNowPlaying(previewTrack);
                updateMobileMiniPlayerVisibility();
                return;
            }
        }
        Track t = engine == null ? null : engine.getCurrentTrack();
        boolean playing = engine != null && engine.isPlaying();
        heroPanel.setPlaying(playing);
        heroBars.setPlaying(playing);
        if (t == null) {
            nowTitle.setText("Ništa ne svira");
            nowArtist.setText("Sonorus");
            heroTitle.setText("Odaberi pjesmu iz kataloga");
            heroArtist.setText("Sonorus lokalna glazbena biblioteka");
            heroAlbum.setText("");
            heroTech.setText("AUDIO");
            artworkLoader.load(null, nowArt);
            artworkLoader.load(null, heroArt);
        } else {
            nowTitle.setText(t.title);
            nowArtist.setText(t.artist);
            heroTitle.setText(t.title);
            heroArtist.setText(t.artist);
            heroAlbum.setText("");
            updateHeroTechnicalInfo(t);
            artworkLoader.load(t, nowArt);
            artworkLoader.load(t, heroArt);
            if (SonorusSettings.onlineMetadata(this)) {
                final long id = t.id;
                onlineMetadata.resolve(t, (track, meta) -> {
                    Track current = engine == null ? null : engine.getCurrentTrack();
                    if (current == null || current.id != id || meta == null) return;
                    if (!meta.title.isEmpty()) { heroTitle.setText(meta.title); nowTitle.setText(meta.title); }
                    if (!meta.artist.isEmpty()) { heroArtist.setText(meta.artist); nowArtist.setText(meta.artist); }

                });
            }
        }
        if (engine != null) {
            playButton.setText(engine.isPlaying() ? "❚❚" : "▶");
            if (mobileBottomPlayButton != null) mobileBottomPlayButton.setText(engine.isPlaying() ? "❚❚" : "▶");
            if (mobileQueuePlayButton != null) mobileQueuePlayButton.setText(engine.isPlaying() ? "❚❚" : "▶");
            onModesChanged(engine.isShuffle(), engine.getRepeatMode(), engine.isCrossfadeEnabled(), engine.getCrossfadeSeconds(), engine.isFadeInOutEnabled(), engine.isSmartCrossfadeEnabled());
            onProgress(engine.getPosition(), engine.getDuration());
        } else {
            onProgress(0L, 0L);
        }
        updateMobileMiniPlayerVisibility();
    }

    private void updateHeroTechnicalInfo(Track track) {
        if (heroTech == null) return;
        if (track == null) {
            heroTech.setText("AUDIO");
            return;
        }
        String cached = technicalTextCache.get(track.id);
        if (cached != null && !cached.isEmpty()) {
            heroTech.setText(cached);
            return;
        }
        heroTech.setText(audioFormatLabel(track));
        if (technicalMetadataReader == null || technicalPending.contains(track.id)) return;
        technicalPending.add(track.id);
        technicalMetadataReader.read(track, (readTrack, info) -> {
            technicalPending.remove(readTrack.id);
            String text = technicalLabel(info, readTrack);
            technicalTextCache.put(readTrack.id, text);
            Track current = engine == null ? null : engine.getCurrentTrack();
            if (current != null && current.id == readTrack.id && heroTech != null) heroTech.setText(text);
            Track fullscreenCurrent = getFullscreenNowPlayingTrack();
            if (fullscreenCurrent != null && fullscreenCurrent.id == readTrack.id && fullscreenTech != null) fullscreenTech.setText(text);
        });
    }

    private String technicalLabel(AudioTechnicalInfo info, Track fallbackTrack) {
        ArrayList<String> parts = new ArrayList<>();
        String format = info == null ? audioFormatLabel(fallbackTrack) : info.format;
        if (format != null && !format.trim().isEmpty()) parts.add(format.trim());
        if (info != null && info.bitrateBps > 0) parts.add(Math.round(info.bitrateBps / 1000f) + " kbps");
        if (info != null && info.sampleRateHz > 0) parts.add(info.sampleRateLabel());
        if (info != null && info.bitDepth > 0) parts.add(info.bitDepth + "-bit");
        return parts.isEmpty() ? "AUDIO" : android.text.TextUtils.join(" · ", parts);
    }

    private String audioFormatLabel(Track t) {
        if (t == null) return "AUDIO";
        String mime = t.mimeType == null ? "" : t.mimeType.toLowerCase(Locale.ROOT);
        if (mime.contains("flac")) return "FLAC";
        if (mime.contains("mpeg")) return "MP3";
        if (mime.contains("wav")) return "WAV";
        if (mime.contains("aac")) return "AAC";
        if (mime.contains("mp4") || mime.contains("m4a")) return "M4A";
        if (mime.contains("opus")) return "OPUS";
        if (mime.contains("ogg")) return "OGG";
        if (mime.contains("wma")) return "WMA";
        return mime.startsWith("audio/") && mime.length() > 6 ? mime.substring(6).toUpperCase(Locale.ROOT) : "AUDIO";
    }

    private void applyResponsiveLayout() {
        float density = getResources().getDisplayMetrics().density;
        int widthDp = (int) (getResources().getDisplayMetrics().widthPixels / density);
        int heightDp = (int) (getResources().getDisplayMetrics().heightPixels / density);
        wideLayout = widthDp >= 1100;
        boolean mobileLandscape = !wideLayout
                && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
                && heightDp < 600;

        sideNav.setVisibility(wideLayout ? View.VISIBLE : View.GONE);
        mobileNav.setVisibility(wideLayout ? View.GONE : View.VISIBLE);
        if (oldSchoolRadioCard != null) oldSchoolRadioCard.setVisibility(wideLayout ? View.VISIBLE : View.GONE);
        if (mobileRadioCard != null) mobileRadioCard.setVisibility(wideLayout ? View.GONE : View.VISIBLE);
        queuePanel.setVisibility(wideLayout ? View.VISIBLE : View.GONE);
        openQueueButton.setVisibility(wideLayout ? View.GONE : View.VISIBLE);

        boolean topPlayerFits = widthDp >= 700 && !mobileLandscape;
        heroPanel.setVisibility((topPlayerFits && !mobileLandscape) ? View.VISIBLE : View.GONE);
        boolean topLevelPhoneAlbums = widthDp < 700 && section == Section.ALBUMS && detailParent == null;
        catalogGrid.setNumColumns(topLevelPhoneAlbums ? 2 : (widthDp >= 900 ? 2 : 1));
        catalogGrid.setHorizontalSpacing(dp(topLevelPhoneAlbums ? 6 : 2));
        catalogGrid.setVerticalSpacing(dp(topLevelPhoneAlbums ? 4 : 2));
        if (catalogAdapter != null) {
            catalogAdapter.setAlbumGridMode(topLevelPhoneAlbums);
            catalogAdapter.setDragEnabled(wideLayout);
        }

        // Kratki landscape na mobitelu mora ostaviti stvarnu visinu sadržaju.
        // Sve vrijednosti se vraćaju na original kada se uređaj vrati u portrait/tablet profil.
        int searchHeightDp = mobileLandscape ? 48 : 56;
        int navHeightDp = mobileLandscape ? 44 : 52;
        int radioHeightDp = mobileLandscape ? 54 : 76;
        int contextHeightDp = mobileLandscape ? 30 : 36;
        int playerHeightDp = mobileLandscape ? 58 : 66;
        setViewHeightDp((View) searchBox.getParent(), searchHeightDp);
        setViewHeightDp(mobileNav, navHeightDp);
        setViewHeightDp(mobileRadioCard, radioHeightDp);
        setViewHeightDp((View) contextTitle.getParent(), contextHeightDp);
        setViewHeightDp(playerBar, playerHeightDp);
        if (nowArt != null) {
            nowArt.setVisibility(View.VISIBLE);
            setViewSizeDp(nowArt, mobileLandscape ? 40 : 46, mobileLandscape ? 40 : 46);
        }
        crossfadeButton.setVisibility(View.GONE);
        mobileCrossfadeButton.setVisibility(View.GONE);
        shuffleButton.setVisibility(View.GONE);
        repeatButton.setVisibility(View.GONE);
        updateMobileMiniPlayerVisibility();
        if (widthDp < 430 || section == Section.SETTINGS || (section == Section.PLAYLISTS && detailParent == null)) sortSpinner.setVisibility(View.GONE);
        else sortSpinner.setVisibility(View.VISIBLE);
    }

    private void updateMobileMiniPlayerVisibility() {
        if (playerBar == null) return;
        float density = getResources().getDisplayMetrics().density;
        int widthDp = (int) (getResources().getDisplayMetrics().widthPixels / density);
        boolean phone = widthDp < 700;
        boolean fullscreenHidden = fullscreenNowPlayingOverlay == null || fullscreenNowPlayingOverlay.getVisibility() != View.VISIBLE;
        boolean previewActive = activeCatalogPreviewTrackId >= 0L;
        boolean localTrack = engine != null
                && engine.isPlaying()
                && engine.getCurrentTrack() != null
                && (playbackService == null || !playbackService.isOldSchoolRadioActive());
        playerBar.setVisibility(phone && fullscreenHidden && (previewActive || localTrack) ? View.VISIBLE : View.GONE);
    }

    private void setViewHeightDp(View view, int heightDp) {
        if (view == null) return;
        ViewGroup.LayoutParams params = view.getLayoutParams();
        if (params == null) return;
        int heightPx = dp(heightDp);
        if (params.height == heightPx) return;
        params.height = heightPx;
        view.setLayoutParams(params);
    }

    private void setViewSizeDp(View view, int widthDp, int heightDp) {
        if (view == null) return;
        ViewGroup.LayoutParams params = view.getLayoutParams();
        if (params == null) return;
        int widthPx = dp(widthDp);
        int heightPx = dp(heightDp);
        if (params.width == widthPx && params.height == heightPx) return;
        params.width = widthPx;
        params.height = heightPx;
        view.setLayoutParams(params);
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyResponsiveLayout();
        if (fullscreenNowPlayingOverlay != null && fullscreenNowPlayingOverlay.getVisibility() == View.VISIBLE) applyFullscreenNowPlayingLayout();
        if (playbackService != null) playbackService.addRadioListener(this);
        View root = findViewById(R.id.rootFrame);
        if (root != null) root.post(() -> { applyFullscreenMode(); applySystemBarInsets(); });
    }

    @Override public void onBackPressed() {
        if (fullscreenNowPlayingOverlay != null && fullscreenNowPlayingOverlay.getVisibility() == View.VISIBLE) { hideFullscreenNowPlaying(); return; }
        if (multiSelectMode) { exitMultiSelectMode(); return; }
        if (mobileQueueOverlay.getVisibility() == View.VISIBLE) {
            setMobileQueueSearchOpen(false, false);
            mobileQueueOverlay.setVisibility(View.GONE);
            return;
        }
        if (detailParent != null) {
            Section parent = detailParent;
            detailParent = null;
            selectSection(parent);
            return;
        }
        super.onBackPressed();
    }

    private void toggleOldSchoolRadio() {
        try {
            Intent intent = new Intent(this, PlaybackService.class).setAction(PlaybackService.ACTION_RADIO_TOGGLE);
            // Poziv dolazi iz vidljive Activity pa startService sigurno zadržava isti
            // servis i izvan lifecyclea ekrana; sam servis ulazi u foreground kad radio krene.
            startService(intent);
            if (oldSchoolRadioState != null) {
                oldSchoolRadioState.setVisibility(View.VISIBLE);
                oldSchoolRadioState.setText("SPAJANJE…");
            }
            if (oldSchoolLiveBadge != null) oldSchoolLiveBadge.setVisibility(View.GONE);
            if (mobileOldSchoolRadioState != null) mobileOldSchoolRadioState.setText("SPAJANJE…");
        } catch (Exception e) {
            Toast.makeText(this, "Radio se nije mogao pokrenuti", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onCatalogPreviewChanged(long trackId, boolean active) {
        runOnUiThread(() -> {
            activeCatalogPreviewTrackId = active ? trackId : -1L;
            if (!active) activeCatalogPreviewDurationMs = 0L;
            if (catalogAdapter != null) catalogAdapter.setPreviewTrackId(active ? trackId : -1L);
            if (active) {
                playButton.setText("■");
                Track track = libraryById.get(trackId);
                if (track != null) showCatalogPreviewNowPlaying(track);
                updateMobileMiniPlayerVisibility();
            } else {
                refreshPlayerViews();
            }
            refreshFullscreenNowPlaying();
        });
    }

    @Override public void onCatalogPreviewProgress(long trackId, long positionMs, long durationMs) {
        runOnUiThread(() -> {
            if (trackId == activeCatalogPreviewTrackId) {
                activeCatalogPreviewDurationMs = Math.max(0L, durationMs);
                updateCatalogPreviewNowPlayingProgress(positionMs, durationMs);
            }
        });
    }

    private void showCatalogPreviewNowPlaying(Track track) {
        if (track == null) return;
        heroPanel.setPlaying(true);
        heroBars.setPlaying(true);
        nowTitle.setText(track.title);
        nowArtist.setText(track.artist);
        heroTitle.setText(track.title);
        heroArtist.setText(track.artist);
        heroAlbum.setText("");
        updateHeroTechnicalInfo(track);
        activeCatalogPreviewDurationMs = Math.max(activeCatalogPreviewDurationMs, Math.max(0L, track.durationMs));
        artworkLoader.load(track, nowArt);
        artworkLoader.load(track, heroArt);
        updateCatalogPreviewNowPlayingProgress(0L, Math.max(0L, track.durationMs));
        if (SonorusSettings.onlineMetadata(this)) {
            final long id = track.id;
            onlineMetadata.resolve(track, (resolvedTrack, meta) -> {
                if (meta == null || activeCatalogPreviewTrackId != id) return;
                if (!meta.title.isEmpty()) { heroTitle.setText(meta.title); nowTitle.setText(meta.title); }
                if (!meta.artist.isEmpty()) { heroArtist.setText(meta.artist); nowArtist.setText(meta.artist); }
            });
        }
    }

    private void updateCatalogPreviewNowPlayingProgress(long positionMs, long durationMs) {
        long safeDuration = Math.max(0L, durationMs);
        long safePosition = Math.max(0L, safeDuration > 0L ? Math.min(positionMs, safeDuration) : positionMs);
        int progress = safeDuration > 0L ? (int)Math.min(1000L, (safePosition * 1000L) / safeDuration) : 0;
        if (!userSeeking) {
            progressBar.setProgress(progress);
            if (heroProgressBar != null) heroProgressBar.setProgress(progress);
        }
        String position = TimeFormat.format(safePosition);
        String duration = TimeFormat.format(safeDuration);
        currentTime.setText(position);
        totalTime.setText(duration);
        if (heroCurrentTime != null) heroCurrentTime.setText(position);
        if (heroTotalTime != null) heroTotalTime.setText(duration);
        updateFullscreenProgress(safePosition, safeDuration);
    }

    @Override public void onRadioStateChanged(boolean playing, boolean preparing, String nowPlaying, String statusText) {
        runOnUiThread(() -> {
            String button = (playing || preparing) ? "■" : "▶";
            String state = statusText == null || statusText.trim().isEmpty()
                    ? (preparing ? "SPAJANJE…" : (playing ? "UŽIVO" : "RADIO")) : statusText;
            String raw = nowPlaying == null ? "" : nowPlaying.trim();
            String title = "Old School Radio";
            String artist = "";
            if (!raw.isEmpty()) {
                String[] parsed = splitRadioMetadata(raw);
                artist = parsed[0];
                title = parsed[1];
            }
            String combined = artist.isEmpty() ? title : artist + " - " + title;
            if (oldSchoolRadioButton != null) oldSchoolRadioButton.setText(button);
            if (mobileOldSchoolRadioButton != null) mobileOldSchoolRadioButton.setText(button);
            if (oldSchoolRadioState != null) {
                oldSchoolRadioState.setText(state);
                oldSchoolRadioState.setVisibility(playing ? View.GONE : View.VISIBLE);
            }
            if (mobileOldSchoolRadioState != null) mobileOldSchoolRadioState.setText(state);
            if (oldSchoolLiveBadge != null) oldSchoolLiveBadge.setVisibility(playing ? View.VISIBLE : View.GONE);
            if (mobileOldSchoolLiveBadge != null) mobileOldSchoolLiveBadge.setVisibility(playing ? View.VISIBLE : View.GONE);
            if (oldSchoolRadioNowPlaying != null) oldSchoolRadioNowPlaying.setText(title);
            if (oldSchoolRadioArtist != null) {
                oldSchoolRadioArtist.setText(artist);
                oldSchoolRadioArtist.setVisibility(artist.isEmpty() ? View.GONE : View.VISIBLE);
            }
            if (mobileOldSchoolRadioNowPlaying != null) mobileOldSchoolRadioNowPlaying.setText(combined);
        });
    }

    private void updateLeftClock() {
        if (leftClockText == null || leftDateText == null) return;
        Date now = new Date();
        Locale hr = Locale.forLanguageTag("hr-HR");
        leftClockText.setText(new SimpleDateFormat("HH:mm", hr).format(now));
        String date = new SimpleDateFormat("EEEE, dd.MM.yyyy.", hr).format(now);
        if (!date.isEmpty()) date = date.substring(0, 1).toUpperCase(hr) + date.substring(1);
        leftDateText.setText(date);
    }

    private String[] splitRadioMetadata(String raw) {
        if (raw == null || raw.trim().isEmpty()) return new String[]{"", "Old School Radio"};
        String clean = raw.trim();
        String[] separators = {" - ", " – ", " — ", " | "};
        for (String separator : separators) {
            int split = clean.indexOf(separator);
            if (split > 0 && split + separator.length() < clean.length()) {
                String artist = clean.substring(0, split).trim();
                String title = clean.substring(split + separator.length()).trim();
                if (!artist.isEmpty() && !title.isEmpty()) return new String[]{artist, title};
            }
        }
        return new String[]{"", clean};
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override protected void onStop() {
        super.onStop();
        if (!isChangingConfigurations() && !SonorusSettings.backgroundPlayback(this)) {
            if (playbackService != null && playbackService.isOldSchoolRadioActive()) playbackService.stopOldSchoolRadio();
            if (engine != null && engine.isPlaying()) engine.pause();
        }
    }

    @Override protected void onDestroy() {
        clockHandler.removeCallbacks(clockTicker);
        if (playbackService != null) {
            playbackService.removeRadioListener(this);
            playbackService.removeCatalogPreviewListener(this);
        }
        if (engine != null) engine.removeListener(this);
        if (bound) {
            try { unbindService(connection); } catch (Exception ignored) {}
            bound = false;
        }
        if (artworkLoader != null) artworkLoader.shutdown();
        if (technicalMetadataReader != null) technicalMetadataReader.shutdown();
        if (lyricsRepository != null) lyricsRepository.shutdown();
        if (fullscreenVinylAnimator != null) fullscreenVinylAnimator.cancel();
        executor.shutdownNow();
        super.onDestroy();
    }
}
