package com.brane.sonora;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class CatalogAdapter extends BaseAdapter {
    public interface Callbacks {
        void onEntryClick(CatalogEntry entry);
        void onEntryLongPress(CatalogEntry entry, View source);
        void onEntryDragStart(CatalogEntry entry, View source);
        void onEntryAdd(CatalogEntry entry);
        void onEntryPreview(Track track);
        void onFavoriteToggle(Track track);
    }

    private final Context context;
    private final LayoutInflater inflater;
    private final ArtworkLoader artworkLoader;
    private final Callbacks callbacks;
    private final ArrayList<CatalogEntry> entries = new ArrayList<>();
    private final ArrayList<Track> library = new ArrayList<>();
    private Set<Long> favorites = new HashSet<>();
    private boolean dragEnabled = true;
    private long selectedTrackId = -1L;
    private long previewTrackId = -1L;
    private Set<Long> multiSelected = new HashSet<>();
    private boolean multiSelectMode;
    private boolean albumGridMode;

    public CatalogAdapter(Context context, ArtworkLoader artworkLoader, Callbacks callbacks) {
        this.context = context; this.inflater = LayoutInflater.from(context); this.artworkLoader = artworkLoader; this.callbacks = callbacks; refreshFavorites();
    }
    public void setLibrary(List<Track> tracks) { library.clear(); if (tracks != null) library.addAll(tracks); }
    public void setEntries(List<CatalogEntry> newEntries) { entries.clear(); if (newEntries != null) entries.addAll(newEntries); notifyDataSetChanged(); }
    public List<CatalogEntry> getEntriesSnapshot() { return new ArrayList<>(entries); }
    public void refreshFavorites() { favorites = IdStore.getFavorites(context); notifyDataSetChanged(); }
    public void setDragEnabled(boolean enabled) { dragEnabled = enabled; notifyDataSetChanged(); }
    public void setAlbumGridMode(boolean enabled) { if (albumGridMode == enabled) return; albumGridMode = enabled; notifyDataSetChanged(); }
    public void setSelectedTrackId(long trackId) { if (selectedTrackId == trackId) return; selectedTrackId = trackId; notifyDataSetChanged(); }
    public void setPreviewTrackId(long trackId) {
        if (previewTrackId == trackId) return;
        previewTrackId = trackId;
        notifyDataSetChanged();
    }
    public void setMultiSelection(boolean enabled, Set<Long> ids) {
        multiSelectMode = enabled;
        multiSelected = ids == null ? new HashSet<>() : new HashSet<>(ids);
        notifyDataSetChanged();
    }
    @Override public int getViewTypeCount() { return 2; }
    @Override public int getItemViewType(int position) {
        CatalogEntry e = getItem(position);
        return albumGridMode && e != null && e.kind == CatalogEntry.Kind.ALBUM ? 1 : 0;
    }
    @Override public int getCount() { return entries.size(); }
    @Override public CatalogEntry getItem(int position) { return entries.get(position); }
    @Override public long getItemId(int position) { CatalogEntry e = entries.get(position); return e.track != null ? e.track.id : position; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        CatalogEntry e = getItem(position);
        if (getItemViewType(position) == 1) return getAlbumGridView(e, convertView, parent);

        Holder h;
        if (convertView == null) { convertView = inflater.inflate(R.layout.catalog_item,parent,false); h = new Holder(convertView); convertView.setTag(h); }
        else h = (Holder) convertView.getTag();
        h.title.setText(e.title); h.subtitle.setText(e.subtitle); h.meta.setText(e.meta); h.root.setAlpha(1f);
        boolean previewing = e.kind == CatalogEntry.Kind.TRACK && e.track != null && e.track.id == previewTrackId;
        boolean selected = e.kind == CatalogEntry.Kind.TRACK && e.track != null && (e.track.id == selectedTrackId || (multiSelectMode && multiSelected.contains(e.track.id)));
        h.root.setBackgroundResource((selected || previewing) ? R.drawable.bg_catalog_selected : R.drawable.bg_catalog_idle);
        h.root.setPreviewPlaying(previewing);
        h.title.setTextColor(selected ? ThemeSupport.accent(context) : ThemeSupport.text(context));
        h.subtitle.setTextColor(selected ? ThemeSupport.text(context) : ThemeSupport.text2(context));
        h.meta.setTextColor(selected ? ThemeSupport.text2(context) : ThemeSupport.text3(context));
        Track rep = e.track != null ? e.track : representativeTrack(e);
        if (e.kind == CatalogEntry.Kind.ARTIST) artworkLoader.loadArtist(e.textKey, rep, h.art); else artworkLoader.load(rep,h.art);

        if (e.kind == CatalogEntry.Kind.TRACK) {
            h.badge.setText(multiSelectMode && multiSelected.contains(e.track.id) ? "✓" : "♪");
            h.preview.setVisibility(multiSelectMode ? View.GONE : View.VISIBLE);
            h.favorite.setVisibility(multiSelectMode ? View.GONE : View.VISIBLE);
            h.add.setVisibility(multiSelectMode ? View.GONE : View.VISIBLE);
            h.preview.setText(previewing ? "■" : "▶");
            h.preview.setTextColor(previewing ? ThemeSupport.accent(context) : ThemeSupport.text2(context));
            h.preview.setOnClickListener(multiSelectMode ? null : v -> callbacks.onEntryPreview(e.track));
            boolean fav = favorites.contains(e.track.id); h.favorite.setText(fav ? "♥" : "♡");
            h.favorite.setTextColor(fav ? ThemeSupport.accent(context) : ThemeSupport.text2(context));
            h.favorite.setOnClickListener(multiSelectMode ? null : v -> callbacks.onFavoriteToggle(e.track));
            h.add.setOnClickListener(multiSelectMode ? null : v -> callbacks.onEntryAdd(e));
        } else {
            switch (e.kind) {
                case ARTIST: h.badge.setText("●"); break;
                case ALBUM: h.badge.setText("◉"); break;
                case GENRE: h.badge.setText("▥"); break;
                case FOLDER: h.badge.setText("▰"); break;
                case PLAYLIST: h.badge.setText("☷"); break;
                default: h.badge.setText("♪");
            }
            h.preview.setVisibility(View.GONE);
            h.favorite.setVisibility(View.GONE);
            h.add.setVisibility(e.kind == CatalogEntry.Kind.FOLDER ? View.VISIBLE : View.GONE);
            h.preview.setOnClickListener(null);
            h.favorite.setOnClickListener(null);
            h.add.setOnClickListener(e.kind == CatalogEntry.Kind.FOLDER ? v -> callbacks.onEntryAdd(e) : null);
        }
        h.root.setOnClickListener(v -> callbacks.onEntryClick(e));
        h.root.setOnLongClickListener(v -> { callbacks.onEntryLongPress(e,v); return true; });
        return convertView;
    }

    private View getAlbumGridView(CatalogEntry e, View convertView, ViewGroup parent) {
        AlbumHolder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.catalog_album_grid_item, parent, false);
            h = new AlbumHolder(convertView);
            convertView.setTag(h);
        } else h = (AlbumHolder) convertView.getTag();
        h.title.setText(e.title);
        String artist = e.subtitle == null ? "" : e.subtitle.trim();
        String count = e.meta == null ? "" : e.meta.trim();
        h.subtitle.setText(artist.isEmpty() ? count : (count.isEmpty() ? artist : artist + " | " + count));
        h.title.setTextColor(ThemeSupport.text(context));
        h.subtitle.setTextColor(ThemeSupport.text2(context));
        artworkLoader.load(representativeTrack(e), h.art);
        h.root.setOnClickListener(v -> callbacks.onEntryClick(e));
        h.root.setOnLongClickListener(v -> { callbacks.onEntryLongPress(e, v); return true; });
        return convertView;
    }

    private Track representativeTrack(CatalogEntry e) {
        for (Track t : library) {
            switch (e.kind) {
                case ARTIST: if (t.artist.equals(e.textKey)) return t; break;
                case ALBUM: if (t.albumId == e.numericKey) return t; break;
                case FOLDER:
                    String p = t.relativePath == null || t.relativePath.isEmpty() ? "Interna memorija" : t.relativePath;
                    if (p.equals(e.textKey)) return t; break;
                case PLAYLIST:
                    List<Long> ids = PlaylistStore.loadIds(context,e.textKey);
                    if (!ids.isEmpty()) { long id=ids.get(0); for (Track c:library) if(c.id==id) return c; }
                    return null;
                default: break;
            }
        }
        return null;
    }

    private static final class Holder {
        final CatalogLiveBorderLayout root; final ImageView art; final TextView badge,title,subtitle,meta,preview,favorite,add;
        Holder(View v) { root=v.findViewById(R.id.catalogRoot); art=v.findViewById(R.id.catalogArt); badge=v.findViewById(R.id.catalogBadge); title=v.findViewById(R.id.catalogTitle); subtitle=v.findViewById(R.id.catalogSubtitle); meta=v.findViewById(R.id.catalogMeta); preview=v.findViewById(R.id.previewButton); favorite=v.findViewById(R.id.favoriteButton); add=v.findViewById(R.id.addButton); }
    }
    private static final class AlbumHolder {
        final View root; final ImageView art; final TextView title, subtitle;
        AlbumHolder(View v) { root=v.findViewById(R.id.catalogAlbumRoot); art=v.findViewById(R.id.catalogAlbumArt); title=v.findViewById(R.id.catalogAlbumTitle); subtitle=v.findViewById(R.id.catalogAlbumSubtitle); }
    }
}
