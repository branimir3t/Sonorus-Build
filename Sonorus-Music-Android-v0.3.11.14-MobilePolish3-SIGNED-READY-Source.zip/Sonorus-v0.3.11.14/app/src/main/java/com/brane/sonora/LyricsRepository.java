package com.brane.sonora;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class LyricsRepository {
    public enum Status { FOUND, NOT_FOUND, ERROR }
    public interface Callback { void onResult(Track track, Status status, String lyrics, String message); }

    private static final String GET_ENDPOINT = "https://lrclib.net/api/get";
    private static final String SEARCH_ENDPOINT = "https://lrclib.net/api/search";

    private final Context context;
    private final File cacheDir;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public LyricsRepository(Context context) {
        this.context = context.getApplicationContext();
        this.cacheDir = new File(this.context.getFilesDir(), "sonorus_lyrics");
        if (!cacheDir.exists()) cacheDir.mkdirs();
    }

    public String getCached(Track track) {
        if (track == null) return "";
        File file = cacheFile(track);
        if (!file.isFile() || file.length() <= 0L) return "";
        try (InputStream in = new FileInputStream(file)) {
            return readAll(in).trim();
        } catch (Exception ignored) {
            return "";
        }
    }

    public boolean saveLocal(Track track, String lyrics) {
        if (track == null || lyrics == null || lyrics.trim().isEmpty()) return false;
        if (!cacheDir.exists() && !cacheDir.mkdirs()) return false;
        File file = cacheFile(track);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(lyrics.trim().getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    public void fetchAndCache(Track track, Callback callback) {
        if (track == null || callback == null) return;
        executor.execute(() -> {
            Result result;
            try {
                result = fetchExact(track, true);
                if (result.status == Status.NOT_FOUND) result = fetchExact(track, false);
                if (result.status == Status.NOT_FOUND) result = fetchSearch(track);
                if (result.status == Status.FOUND && !result.lyrics.isEmpty()) writeCache(track, result.lyrics);
            } catch (Exception e) {
                result = new Result(Status.ERROR, "", "Nije moguće dohvatiti tekst");
            }
            Result delivered = result;
            main.post(() -> callback.onResult(track, delivered.status, delivered.lyrics, delivered.message));
        });
    }

    private Result fetchExact(Track track, boolean includeAlbum) throws Exception {
        StringBuilder query = new StringBuilder();
        append(query, "track_name", track.title);
        append(query, "artist_name", track.artist);
        if (includeAlbum && track.album != null && !track.album.trim().isEmpty() && !"Nepoznat album".equalsIgnoreCase(track.album.trim())) {
            append(query, "album_name", track.album);
        }
        if (track.durationMs > 0L) append(query, "duration", String.valueOf(Math.max(1L, Math.round(track.durationMs / 1000.0))));
        HttpResult http = request(GET_ENDPOINT + "?" + query);
        if (http.code == 404) return new Result(Status.NOT_FOUND, "", "Tekst nije pronađen");
        if (http.code < 200 || http.code >= 300) return new Result(Status.ERROR, "", "LRCLIB greška " + http.code);
        return resultFromObject(new JSONObject(http.body));
    }

    private Result fetchSearch(Track track) throws Exception {
        StringBuilder query = new StringBuilder();
        append(query, "track_name", track.title);
        append(query, "artist_name", track.artist);
        append(query, "q", track.artist + " " + track.title);
        HttpResult http = request(SEARCH_ENDPOINT + "?" + query);
        if (http.code == 404) return new Result(Status.NOT_FOUND, "", "Tekst nije pronađen");
        if (http.code < 200 || http.code >= 300) return new Result(Status.ERROR, "", "LRCLIB greška " + http.code);
        JSONArray array = new JSONArray(http.body);
        JSONObject best = chooseBest(array, track);
        return best == null ? new Result(Status.NOT_FOUND, "", "Tekst nije pronađen") : resultFromObject(best);
    }

    private JSONObject chooseBest(JSONArray array, Track track) {
        JSONObject best = null;
        int bestScore = Integer.MIN_VALUE;
        String wantedTitle = normalize(track.title);
        String wantedArtist = normalize(track.artist);
        long wantedDuration = Math.max(0L, Math.round(track.durationMs / 1000.0));
        for (int i = 0; i < array.length(); i++) {
            JSONObject item = array.optJSONObject(i);
            if (item == null) continue;
            int score = 0;
            if (wantedTitle.equals(normalize(item.optString("trackName")))) score += 8;
            if (wantedArtist.equals(normalize(item.optString("artistName")))) score += 6;
            long duration = Math.round(item.optDouble("duration", 0.0));
            if (wantedDuration > 0L && duration > 0L) {
                long diff = Math.abs(wantedDuration - duration);
                if (diff <= 2L) score += 5;
                else if (diff <= 6L) score += 2;
            }
            String lyrics = extractLyrics(item);
            if (!lyrics.isEmpty()) score += 3;
            if (score > bestScore && !lyrics.isEmpty()) { bestScore = score; best = item; }
        }
        return best;
    }

    private Result resultFromObject(JSONObject object) {
        if (object == null || object.optBoolean("instrumental", false)) return new Result(Status.NOT_FOUND, "", "Instrumental / bez teksta");
        String lyrics = extractLyrics(object);
        return lyrics.isEmpty()
                ? new Result(Status.NOT_FOUND, "", "Tekst nije pronađen")
                : new Result(Status.FOUND, lyrics, "Tekst je spremljen offline");
    }

    private String extractLyrics(JSONObject object) {
        String plainLyrics = object.optString("plainLyrics", "").trim();
        if (!plainLyrics.isEmpty() && !"null".equalsIgnoreCase(plainLyrics)) return plainLyrics;
        String syncedLyrics = object.optString("syncedLyrics", "").trim();
        if (syncedLyrics.isEmpty() || "null".equalsIgnoreCase(syncedLyrics)) return "";
        return syncedLyrics.replaceAll("(?m)^\\[\\d{2}:\\d{2}(?:\\.\\d+)?\\]\\s*", "").trim();
    }

    private HttpResult request(String address) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(7000);
            connection.setReadTimeout(10000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "Sonorus/0.3.11.7 Android Music Player");
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream();
            String body = stream == null ? "" : readAll(stream);
            return new HttpResult(code, body);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void append(StringBuilder query, String key, String value) throws Exception {
        if (query.length() > 0) query.append('&');
        query.append(URLEncoder.encode(key, StandardCharsets.UTF_8.name()));
        query.append('=');
        query.append(URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8.name()));
    }

    private String readAll(InputStream input) throws Exception {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (out.length() > 0) out.append('\n');
                out.append(line);
            }
        }
        return out.toString();
    }

    private void writeCache(Track track, String lyrics) {
        if (lyrics == null || lyrics.trim().isEmpty()) return;
        if (!cacheDir.exists()) cacheDir.mkdirs();
        File file = cacheFile(track);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(lyrics.trim().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }

    private File cacheFile(Track track) { return new File(cacheDir, sha256(cacheIdentity(track)) + ".txt"); }

    private String cacheIdentity(Track track) {
        return normalize(track.artist) + "|" + normalize(track.title) + "|" + normalize(track.album);
    }

    private String normalize(String value) {
        String s = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        return java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+", "").replaceAll("\\s+", " ");
    }

    private String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format(Locale.US, "%02x", b));
            return out.toString();
        } catch (Exception e) {
            return Integer.toHexString(value.hashCode());
        }
    }

    public void shutdown() { executor.shutdownNow(); }

    private static final class HttpResult {
        final int code;
        final String body;
        HttpResult(int code, String body) { this.code = code; this.body = body == null ? "" : body; }
    }

    private static final class Result {
        final Status status;
        final String lyrics;
        final String message;
        Result(Status status, String lyrics, String message) {
            this.status = status;
            this.lyrics = lyrics == null ? "" : lyrics;
            this.message = message == null ? "" : message;
        }
    }
}
