package com.brane.sonora;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Persistent per-track cover override selected from local device storage. */
public final class LocalArtworkStore {
    private static final String DIR = "cover_overrides";
    private static final int MAX_EDGE = 1600;

    private LocalArtworkStore() {}

    private static File directory(Context context) {
        File dir = new File(context.getApplicationContext().getFilesDir(), DIR);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private static File file(Context context, long trackId) {
        return new File(directory(context), "track_" + trackId + ".jpg");
    }

    public static boolean has(Context context, long trackId) {
        File f = file(context, trackId);
        return f.isFile() && f.length() > 0;
    }

    public static Bitmap load(Context context, long trackId) {
        try {
            File f = file(context, trackId);
            if (!f.isFile() || f.length() <= 0) return null;
            return BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Exception ignored) {
            return null;
        }
    }

    public static boolean save(Context context, long trackId, Uri uri) {
        if (context == null || uri == null || trackId < 0L) return false;
        File target = file(context, trackId);
        File temp = new File(target.getParentFile(), target.getName() + ".tmp");
        Bitmap bitmap = null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = context.getContentResolver().openInputStream(uri)) {
                if (in == null) return false;
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false;

            int sample = 1;
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            while (max / sample > MAX_EDGE) sample *= 2;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = Math.max(1, sample);
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            try (InputStream in = context.getContentResolver().openInputStream(uri)) {
                if (in == null) return false;
                bitmap = BitmapFactory.decodeStream(in, null, opts);
            }
            if (bitmap == null) return false;

            try (FileOutputStream out = new FileOutputStream(temp)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)) return false;
                out.flush();
            }
            if (target.exists() && !target.delete()) return false;
            if (!temp.renameTo(target)) return false;
            return target.isFile() && target.length() > 0;
        } catch (Exception ignored) {
            try { temp.delete(); } catch (Exception ignored2) {}
            return false;
        } finally {
            if (bitmap != null) bitmap.recycle();
        }
    }

    public static boolean remove(Context context, long trackId) {
        try {
            File f = file(context, trackId);
            return !f.exists() || f.delete();
        } catch (Exception ignored) {
            return false;
        }
    }
}
