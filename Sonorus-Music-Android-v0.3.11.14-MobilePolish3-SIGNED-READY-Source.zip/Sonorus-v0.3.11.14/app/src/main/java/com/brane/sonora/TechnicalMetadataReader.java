package com.brane.sonora;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class TechnicalMetadataReader {
    public interface Callback { void onResult(Track track, AudioTechnicalInfo info); }

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public TechnicalMetadataReader(Context context) { this.context = context.getApplicationContext(); }

    public void read(Track track, Callback cb) {
        if (track == null || cb == null) return;
        executor.execute(() -> {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); } catch (Exception ignored) {}
            AudioTechnicalInfo info = AudioTechnicalInfo.read(context, track);
            main.post(() -> cb.onResult(track, info));
        });
    }

    public void shutdown() { executor.shutdownNow(); }
}
