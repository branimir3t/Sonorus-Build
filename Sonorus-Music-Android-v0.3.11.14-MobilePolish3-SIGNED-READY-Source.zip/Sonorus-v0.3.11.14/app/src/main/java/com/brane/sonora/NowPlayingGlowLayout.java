package com.brane.sonora;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.view.animation.LinearInterpolator;

public final class NowPlayingGlowLayout extends LinearLayout {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private SweepGradient shader;
    private ValueAnimator animator;
    private float rotation;
    private boolean playing;
    private boolean effectsEnabled = true;

    public NowPlayingGlowLayout(Context c, AttributeSet a) {
        super(c,a);
        setWillNotDraw(false);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2f));
        setLayerType(LAYER_TYPE_SOFTWARE,null);
    }

    public void setPlaying(boolean v) { playing=v; updateAnimator(); invalidate(); }
    public void setEffectsEnabled(boolean v) { effectsEnabled=v; updateAnimator(); invalidate(); }

    private void updateAnimator() {
        if (playing && effectsEnabled) {
            if (animator == null) {
                animator = ValueAnimator.ofFloat(0f,360f);
                animator.setDuration(6500L);
                animator.setRepeatCount(ValueAnimator.INFINITE);
                animator.setInterpolator(new LinearInterpolator());
                animator.addUpdateListener(a -> { rotation=(float)a.getAnimatedValue(); invalidate(); });
            }
            if (!animator.isStarted()) animator.start();
        } else if (animator != null) {
            animator.cancel(); rotation=0f;
        }
    }

    @Override protected void onSizeChanged(int w,int h,int ow,int oh) {
        int a = ThemeSupport.accent(getContext());
        int b = ThemeSupport.accentAlt(getContext());
        shader = new SweepGradient(w/2f,h/2f,new int[]{a,b,0xFF4F7DFF,0xFF20C7D9,b,a},null);
        paint.setShader(shader);
    }

    @Override protected void dispatchDraw(Canvas c) {
        super.dispatchDraw(c);
        if (shader == null) return;
        matrix.setRotate(rotation,getWidth()/2f,getHeight()/2f);
        shader.setLocalMatrix(matrix);
        paint.setAlpha(effectsEnabled ? (playing ? 230 : 85) : 40);
        paint.setShadowLayer(effectsEnabled && playing ? dp(8) : dp(2),0,0,ThemeSupport.accent(getContext()));
        float i=dp(2.5f);
        c.drawRoundRect(i,i,getWidth()-i,getHeight()-i,dp(16),dp(16),paint);
    }

    @Override protected void onDetachedFromWindow() { if(animator!=null)animator.cancel(); super.onDetachedFromWindow(); }
    private float dp(float v){ return v*getResources().getDisplayMetrics().density; }
}
