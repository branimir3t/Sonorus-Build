package com.brane.sonora;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class IdStore {
    private static final String PREFS = "sonora_ids";
    private static final String FAVORITES = "favorites";
    private static final String LAST_QUEUE = "last_queue";

    private IdStore() {}

    public static Set<Long> getFavorites(Context context) {
        String raw = prefs(context).getString(FAVORITES, "");
        HashSet<Long> out = new HashSet<>();
        if (raw == null || raw.isEmpty()) return out;
        for (String part : raw.split(",")) {
            try { out.add(Long.parseLong(part)); } catch (NumberFormatException ignored) {}
        }
        return out;
    }

    public static boolean isFavorite(Context context, long id) {
        return getFavorites(context).contains(id);
    }

    public static boolean toggleFavorite(Context context, long id) {
        Set<Long> ids = getFavorites(context);
        boolean now;
        if (ids.contains(id)) { ids.remove(id); now = false; }
        else { ids.add(id); now = true; }
        saveSet(context, FAVORITES, ids);
        return now;
    }

    public static void saveLastQueue(Context context, List<Track> queue) {
        StringBuilder sb = new StringBuilder();
        for (Track t : queue) {
            if (sb.length() > 0) sb.append(',');
            sb.append(t.id);
        }
        prefs(context).edit().putString(LAST_QUEUE, sb.toString()).apply();
    }

    public static List<Long> getLastQueueIds(Context context) {
        String raw = prefs(context).getString(LAST_QUEUE, "");
        ArrayList<Long> out = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return out;
        for (String part : raw.split(",")) {
            try { out.add(Long.parseLong(part)); } catch (NumberFormatException ignored) {}
        }
        return out;
    }

    private static void saveSet(Context context, String key, Set<Long> ids) {
        StringBuilder sb = new StringBuilder();
        for (Long id : ids) {
            if (sb.length() > 0) sb.append(',');
            sb.append(id);
        }
        prefs(context).edit().putString(key, sb.toString()).apply();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
