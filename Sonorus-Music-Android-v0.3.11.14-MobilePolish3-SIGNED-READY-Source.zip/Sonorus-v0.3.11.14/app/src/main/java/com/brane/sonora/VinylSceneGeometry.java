package com.brane.sonora;

/** Coordinates in the original 970 x 866 photograph. Rotation precedes projection. */
public final class VinylSceneGeometry {
    public static final float WIDTH=970f, HEIGHT=866f;
    public static final float CX=524f, CY=480f, RX=322f, RY=92f, PERSPECTIVE=-0.13f;
    private VinylSceneGeometry() {}
    public static double[] projectRotated(double x,double y,double degrees) {
        double a=Math.toRadians(degrees), u=x*Math.cos(a)-y*Math.sin(a), v=x*Math.sin(a)+y*Math.cos(a);
        double d=1+PERSPECTIVE*v;
        return new double[]{CX+RX*u/d,CY+RY*v/d};
    }
    public static float fitScale(float width,float height) { return Math.min(width/WIDTH,height/HEIGHT); }
    public static float advance(float angle,long elapsed,boolean playing) {
        return playing ? (angle+elapsed*360f/1800f)%360f : angle;
    }
    public static float armLift(float degrees) { return 0.14f*(float)Math.sin(Math.toRadians(degrees)); }
}
