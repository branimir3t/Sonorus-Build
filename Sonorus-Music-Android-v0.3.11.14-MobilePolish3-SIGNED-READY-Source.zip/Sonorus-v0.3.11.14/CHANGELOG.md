# Sonorus v0.3.11.13 – Mobile Polish 2

- Mobile fullscreen: kartice **Omiljeno / Playlista / Tekst** su manje i transparentnije.
- Gornji **SPUSTI** i **PLAYER** gumbi koriste centrirane vector ikone unutar kružnih gumba.
- Mobile fullscreen progress/vremenska traka ima svjetliji neaktivni dio radi bolje vidljivosti na blur pozadini.
- Pokretanje pjesme iz kataloga odmah prikazuje zakačeni donji mini-player; mini-player se i dalje skriva samo dok je fullscreen otvoren.
- Tablet/wide fotografski gramofon i animacijska geometrija nisu mijenjani.
- Verzija: `versionCode 35`, `versionName 0.3.11.13-mobile-polish2`.

# Sonorus v0.3.11.10 – Menu Polish

- Kompaktniji long-press meni pjesme; uklonjena opcija “Reproduciraj sljedeće”.
- Naslov pjesme u long-press meniju koristi naglasak teme i tanki razdjelnik.
- “Uredi podatke” može spremiti lokalni cover kao trajni override po pjesmi.
- Svi AlertDialog meniji/prozori koriste kompaktniji, blago transparentan izgled u bojama aktivne teme.
- Full screen player ostaje otvoren dok ga korisnik ručno ne zatvori.
- Full-screen fotografska scena koristi se kao pozadina preko cijelog zaslona; lijevi gramofon i animacija nisu mijenjani.

## 0.3.11.8 — Photographic Vinyl

- Full-screen `Što svira` više ne koristi nacrtani Canvas gramofon kao glavni vizual; zamijenjen je high-fidelity fotografskim hi-fi scene slojem.
- Trenutni cover ostaje dinamičan i postavlja se iznad LP omota u fotografskoj sceni; ista slika se koristi i kao etiketa ploče.
- Etiketa ploče koristi linearnu rotaciju oko 33 1/3 RPM kao prirodni vizualni cue reprodukcije, uz očuvane stvarne fotografske utore/refleksije i ručku gramofona.
- Desni PLAYER panel je kompaktniji, a `Tekst pjesme` dobiva veći prostor s vlastitim vertikalnim scrollom bez izlaska iz ekrana.
- Pozadina koristi zaseban tamni blur lounge sloj radi dubine i kohezije, bez velikih praznih crnih površina.
- PlaybackService, AudioEngine, catalog preview, queue, radio i trajna spremišta nisu mijenjani.
- Verzija: `versionCode 30`, `versionName 0.3.11.8-photographic-vinyl`.

## 0.3.11.6 — Full-screen Now Playing

- Tap na cover u kartici `Što svira` otvara full-screen prikaz i za PLAYER i za Catalog Preview.
- Veliki cover, naslov/izvođač, album/godina, tehnički audio podaci, seek i transport kontrole.
- Gramofon + vinil animacija: ploča se vrti dok aktivni izvor svira, miruje na pauzi.
- Catalog Preview full-screen koristi postojeći preview seek/Stop i ne dodaje pjesmu u PLAYER; završetak/Stop vraća PLAYER prikaz bez automatskog pokretanja.
- Tekst pjesme se dohvaća samo na korisnikov `Preuzmi tekst`, preko LRCLIB HTTPS API-ja, te se sprema u privatni `sonorus_lyrics` cache za offline prikaz.
- Radio full-screen nije dio ove verzije; Internet Search v0.3.12 nije uključen.
- Verzija: `versionCode 28`, `versionName 0.3.11.6-fullscreen-now-playing`.

## 0.3.11.5 — Mobile Landscape Fix
- Mobile landscape više ne bira veliki 172dp hero player samo zato što je ekran širok.
- Responsive profil sada koristi širinu, visinu i orijentaciju; kratki landscape mobiteli dobivaju kompaktni player i niži chrome.
- Tražilica, horizontalni meni, Old School Radio kartica, kontekstni red i donji player vraćaju punu visinu nakon povratka u portrait/tablet prikaz.
- Katalog i Postavke ponovno dobivaju preostalu visinu i normalno reagiraju/skrolaju u landscapeu.
- Tablet landscape ostaje na postojećem wide layoutu.
- Verzija: `versionCode 27`, `versionName 0.3.11.5-mobile-landscape-fix`.

# Sonorus v0.3.11.3 Catalog Preview Seek + Live Border

- Glavna vremenska traka u „Trenutno svira” sada seeka catalog preview kad je on aktivan; kad preview nije aktivan, i dalje upravlja PLAYER-om kao prije.
- Tijekom povlačenja preview trake automatski progress ne vraća thumb unatrag.
- Pjesma koja stvarno svira iz kataloga koristi isti accent obrub kao označena pjesma, uz diskretan živi puls obruba samo dok preview svira.
- Stop/završetak previewa vraća prikaz PLAYER-a bez automatskog pokretanja PLAYER pjesme.
- Internet Search v0.3.12 nije uključen.
- Verzija: `versionCode 25`, `versionName 0.3.11.3-catalog-preview-seek-live-border`.

# Sonorus v0.3.11.1 Catalog Preview Timeline

- Nastavak je napravljen izravno iz v0.3.11 Catalog Preview baze; Internet Search v0.3.12 nije uključen.
- Aktivna preview pjesma u katalogu sada dobiva kompaktni red ispod kartice s tankom seek crtom i vremenom `prošlo / ukupno`.
- Vremenska crta prikazuje se samo na pjesmi koja se trenutno preslušava i nestaje čim preview završi ili se zaustavi.
- Crta je seekable: pomicanjem thumb-a može se preskočiti na željeno mjesto unutar catalog previewa bez dodavanja pjesme u PLAYER.
- Preview progress se osvježava svakih 500 ms kroz postojeći PlaybackService; PLAYER queue i ostali playback načini nisu mijenjani.
- Verzija: `versionCode 23`, `versionName 0.3.11.1-catalog-preview-timeline`.

# Sonorus v0.3.11 Catalog Preview

- Kataloške pjesme dobile su mali **▶ preview** gumb odmah prije srca i `+`; prikazuje se samo na pjesmama, ne na izvođačima/mapama/albumima.
- Preview svira pjesmu izravno iz kataloga bez dodavanja u PLAYER/red reprodukcije i bez promjene spremljenog queuea.
- Ako PLAYER već svira, preview ga samo pauzira, pamti aktivnu pjesmu i poziciju te ga nakon Stop/completiona vraća na isto mjesto.
- Aktivni preview gumb prelazi u **■**, pa se istim gumbom preview može odmah zaustaviti.
- Preview koristi isti PlaybackService/audio-focus put kao ostatak aplikacije, uključujući duck/focus handling i sigurno vraćanje lokalne glazbe ili radija.
- Verzija: `versionCode 22`, `versionName 0.3.11-catalog-preview`.

# Sonorus v0.3.10 Mobile Player Compact

- Mobile PLAYER zaglavlje dobilo je mali gumb **Traži** uz Spremi/Očisti; tražilica se otvara i zatvara kao kompaktni padajući panel s kratkom animacijom.
- Ispod zaglavlja dodane su niske, pregledne kontrole **Prethodna / Play-Pauza / Stop / Sljedeća** bez promjene desktop/tablet PLAYER-a.
- Dodan je zaseban tanki mobile seek bar s trenutačnim vremenom lijevo i ukupnim trajanjem desno.
- Stop u mobile PLAYER-u pauzira pjesmu i vraća je na početak, bez brisanja queuea ili spremljenih podataka.
- Dodirom liste ili odabirom rezultata padajuća tražilica se zatvara i vraća puni prostor playlisti.
- Donji mobile info-red s brojem pjesama / ukupnim / preostalim trajanjem smanjen je na 36dp i centriran.
- Očuvani su postojeći playback, radio, Android Auto, drag & drop, teme i trajni podaci.
- Verzija: `versionCode 21`, `versionName 0.3.10-mobile-player-compact`.

# Sonorus v0.3.9.1 Radio + Queue Pro

- Old School Radio metadata parser je ojačan: sada podržava JSON objekt, JSON niz, ugniježđene objekte/nizove i plain-text fallback, pa se `Trenutno slušate` pouzdanije vraća s nazivom pjesme koja stvarno svira.
- Radio više ne pada olako natrag na sam naziv postaje; zadnja dobra metadata ostaje prikazana dok ne stigne nova valjana pjesma.
- PLAYER drag & drop je profesionalnije zaglađen: više nema dodatne insertion crte, tijekom preslagivanja se prikazuje samo diskretni target highlight, aktivni red ostaje pod prstom i autoscroll je mirniji.
- `Ujednači glasnoću` je pojačan za live upotrebu: ciljna glasnoća je podignuta bliže snažnijem izlazu, tihi materijal se može glasnije podići, a peak headroom ostaje siguran za PA.
- Audio duck pri privremenom audio-fokusu za radio je blaži nego prije, pa Android Auto više ne zvuči nepotrebno prigušeno.
- Vinyl Gold tema sada koristi čišću premium tipografiju umjesto serifnog fonta, a pozadina dobiva diskretno animirani vinyl koji se lagano okreće bez teškog opterećenja UI-a.
- PLAYER drag vizual sada koristi cijeli red kao drag-shadow, target preview ostaje bez dodatne crte, a izlazak prsta iz liste više ne prekida samo drag stanje.
- Vinyl animacija je ograničena na oko 20 fps, dovoljno glatko za sporu ploču uz znatno manje UI opterećenje.
- LoudnessEnhancer boost limit usklađen je s novim analizatorom do 12 dB, uz peak/headroom zaštitu iz analize.
- Verzija: `versionCode 20`, `versionName 0.3.9.1-radio-queue-pro`.

# Sonorus v0.3.8 Live Release

- PLAYER drag & drop sada završava na stvarnoj DROP poziciji prsta i nakon puštanja više ne vraća viewport na aktivnu pjesmu.
- Katalog: obične pjesme nemaju okvir; samo trenutno označena pjesma dobiva theme-accent outline.
- Tablet lijevi stupac: ispod Old School Radija dodani su 24-satni sat i hrvatski datum; radio okvir koristi isti divider ton i debljinu kao neaktivne stavke menija.
- Dodane su dvije kompletne teme: **Obsidian 3D** i **Crimson 3D**, s fotografskim pozadinama, vlastitim paletama i premium 3D površinama. Fotografije se dohvaćaju na zasebnom background threadu i nakon prvog uspješnog učitavanja spremaju u privatni cache; bez mreže ostaje tamni theme fallback.
- Reprodukcija za nastupe: PlaybackService dobio je lagani periodični health check za lokalni audio i radio, radio recovery callbacki su deduplicirani/cancellable, a nepotrebno ponovno stvaranje MediaSession queuea pri svakoj promjeni pjesme je uklonjeno.
- UI progress je ograničen na ~5 Hz bez diranja 100 ms AudioEngine crossfade timera; artwork thumbnail decode smanjen je na 320 px i loader koristi 2 background workera radi manjeg memory/CPU pritiska.
- Audio izlaz za nastupe: `Ujednači glasnoću` je sada opt-in (default OFF ako korisnik nikad nije spremio tu postavku), pa lokalna glazba po defaultu ide neutralno na 100% digitalnog izlaza; nakon Android Auto/audio-focus duckinga lokalni audio i radio eksplicitno se vraćaju na punu razinu.
- Očuvani su `com.brane.sonora` i postojeći trajni storeovi: `sonorus_settings`, `sonora_player`, `sonora_ids`, `sonorus_track_overrides`, `sonora_playlists`.
- Verzija: `versionCode 18`, `versionName 0.3.8-live-release`.

# Sonorus v0.3.7 Radio + Catalog Polish

- Tablet Old School Radio je dodatno zbijen: manja radio ikona, `OLD SCHOOL RADIO` ostaje u jednom redu, naslov pjesme i izvođač su centrirani i čitljiviji.
- UŽIVO/status i Play/Stop ostaju potpuno vidljivi; uklonjeni su nepotrebni unutarnji divideri koji su mogli izgledati kao bijele/crtaste artefakte.
- Uklonjen je donji Sonorus logo ispod radija u lijevom stupcu kako radio više ne bi gubio vertikalni prostor.
- Katalog koristi 2dp horizontalni i 2dp vertikalni razmak između kartica.
- PLAYER drag & drop koristi samo jednu overlay insertion liniju; stari row-level drag indikatori su potpuno uklonjeni da se narančasta crta ne duplicira.
- Aktivna i odabrana pjesma više nemaju outline/stroke oko kartice; aktivna pjesma ostaje prepoznatljiva preko tamnog highlighta i accent teksta.
- Single-tap odabir pjesme sada se automatski odznači kada korisnik dodirne izvan odgovarajuće kartice; double-tap reprodukcija ostaje nepromijenjena.
- Podaci korisnika ostaju kompatibilni s prethodnim verzijama: `applicationId` i postojeći SharedPreferences namespaceovi za metadata overrideove, favorite, playliste i postavke nisu promijenjeni.

# Sonorus v0.3.4 Player Compact

- PLAYER je zbijen bez diranja queue logike: manji font naslova, izvođača, rednog broja, trajanja, meta reda, tražilice i kontrolnih gumba.
- Kartice pjesama u PLAYERU spuštene su s 58dp na 48dp kako bi na ekranu stalo osjetno više pjesama.
- Naslov i izvođač u PLAYERU koriste umjeren autosize kako bi ostali čitljivi i kod dužih naziva.
- Drag & drop ručica ≡ vizualno je manja i diskretnija, ali zadržava punu visinu kartice kao dodirnu zonu.
- Smanjeni su horizontalni prostor rednog broja, trajanja i gumba za uklanjanje kako bi naslov pjesme dobio više širine.
- Zaglavlje, interna tražilica i donje Repeat/Random kartice PLAYERA su malo kompaktniji; isto vrijedi i za mobilni PLAYER overlay.
- Katalog, Now Playing, radio, teme, Android Auto i playback core nisu mijenjani.

# Sonorus v0.3.3 Catalog Card Polish

- Kataloške kartice su kompaktnije i preglednije: manji razmaci između naslova, izvođača i trajanja.
- Naslov i izvođač imaju malo manji font i autosize kako bi stalo više teksta prije skraćivanja.
- Tehnički podaci (format/bitrate) uklonjeni su iz kataloških kartica; ostaje samo trajanje pjesme.
- Lijevi artwork/logo na kartici je smanjen kako bi tekst dobio više širine.
- Srce i + su približeni bez promjene njihove funkcije.
- Ručka ≡ je uklonjena iz kataloga jer je katalog sortiran; ručno preslagivanje ostaje samo u PLAYERU.
- PLAYER, Now Playing, radio, teme, Android Auto i playback core nisu mijenjani.

# Sonorus v0.3.2 Now Playing + Radio Polish

- Redizajniran tablet `TRENUTNO SVIRA`: više širine za naslov, uklonjen vertikalni razdjelnik, manji artwork i kompaktnije kontrole.
- Dugi nazivi pjesama koriste dva retka i automatsko smanjivanje fonta umjesto ranog rezanja.
- Tehnički podaci ostaju ispod izvođača, ali su diskretniji, jednoredni i manji: format · kbps · kHz · bit-depth.
- Seek/progress traka ostaje neposredno ispod Prev/Play/Next kontrola s vremenom lijevo/desno.
- Vizualizator je uklopljen u kontrolni blok kako ne bi oduzimao prostor naslovu.
- Tablet Old School Radio zaglavlje presloženo za usku lijevu traku: naziv postaje se više ne reže u bijele crtice, UŽIVO/status imaju vlastiti prostor, a nepotrebni horizontalni divider je uklonjen.
- UŽIVO badge više nema bijeli rub koji je mogao izgledati kao artefakt.
- Očuvani PLAYER, teme, Android Auto i playback core iz v0.3.1.

# Sonorus v0.3.1 Premium Themes + Player

- Premium teme potpuno redizajnirane: Midnight Stage, Copper Studio i Vinyl Gold koriste stvarne fotografske pozadine, prozirnije slojeve i izraženiji 3D/depth tretman kartica.
- Now Playing dobio seek/progress traku ispod Prev/Play/Next kontrola te diskretan tehnički red: format · kbps · kHz · bit-depth kada je podatak dostupan.
- Tablet Old School Radio kartica povećana i dobila jasnu UŽIVO oznaku te više prostora za metadata tekst.
- PLAYER dobio internu tražilicu s prijedlozima samo iz trenutačnog reda reprodukcije.
- PLAYER meta sada zadržava ukupan broj/trajanje i tijekom reprodukcije dodaje preostalo vrijeme reda.
- Očuvana Android Auto MediaBrowser/MediaSession integracija i postojeća queue/drag-drop logika.

# Changelog

## v0.3.0 Themes + Android Auto
- Dodane 3 nove kompletne teme uz postojeću: Midnight Stage, Copper Studio i Vinyl Gold.
- Tema mijenja globalnu paletu, kartice, nav/panel površine, tipografiju, aktivne elemente i apstraktnu pozadinu; izbor se sprema u Postavkama.
- Brzi dvostruki dodir na pjesmu u katalogu odmah pokreće tu pjesmu; običan dodir i dalje samo označava.
- Tablet Old School Radio kartica povećana i presložena tako da Trenutno svira ima dovoljno širine i do tri retka.
- Radio metadata se ponovno isporučuju tablet/wide UI-ju i nakon rotacije, reconnecta ili povratka u aplikaciju.
- PlaybackService proširen u MediaBrowserService za Android Auto uz postojeći MediaSession/foreground audio core.
- Android Auto browse: Lokalna glazba + Old School Radio; podržani play/pause/stop, prethodna/sljedeća, red reprodukcije, play-from-media-id i search.
- Android Auto dobiva metadata trenutne pjesme/radija i queue state kroz MediaSession.
- Skriveni Sonorus trackovi ne prikazuju se u Android Auto katalogu.


## v0.2.9 RadioFlowFix
- Old School Radio: RadioFlow primarni stream URL + RadioFlow metadata proxy.
- 8 s metadata refresh, 15 s prepare timeout, 3 reconnect pokušaja i 1800 ms recovery delay.
- Jednostavniji MediaPlayer stream setup bez ICY request headera koji je mogao blokirati SHOUTcast prepare.
- HTTPS metadata proxy prvi, direktni SHOUTcast current-song fallback drugi.
- Radio kartica malo viša; Sonorus logo ispod radija veći i spušten na dno lijeve trake.
- O aplikaciji zamijenjeno korisnikovim tekstom.
- Bez namjernih promjena postojećeg desnog PLAYER-a i lokalnog playback corea.

# Sonorus changelog

## v0.2.8 StableFlow
- Stabilna baza v0.2.6 PlaybackCore; fullscreen aktivan po zadanim postavkama.
- Old School Radio: HTTPS + ograničeni HTTP fallbackovi, Play/Stop, UŽIVO status i trenutna pjesma.
- Multi-select kataloga i grupno uređivanje zajedničkih metadata.
- PLAYER: upozorenje na duplikate, vidljiva drag/drop pozicija i autoscroll; brisanje aktivne pjesme više ne pokreće drugu.
- Spremljene playliste mogu se preimenovati, pomicati i brisati.
- Stavke se mogu ukloniti iz Sonorus kataloga bez brisanja datoteke i vratiti iz Postavki.
- Novi transparentni Sonorus launcher/fallback artwork i korisnikov logo ispod radio kartice.

# Sonorus — Changelog

## v0.2.6 PlaybackCore
- Kritični background-audio fix: AUDIOFOCUS_GAIN se drži kroz foreground media service, a izlazni miks se pouzdano vraća nakon focus gaina/duckinga bez gubitka fade/crossfade omjera.
- Dodan playback health-check dok svira: potvrđuje foreground servis, wake lock i stvarni izlazni volume mix bez restartanja pjesme.
- Dodana zaštita pri SCREEN_OFF / SCREEN_ON za uređaje s agresivnim power managementom.
- Automatski prijelaz na sljedeću pjesmu ojačan completion watchdogom ako codec/uređaj propusti MediaPlayer onCompletion callback.
- Preloaded prijelaz više ne može ostaviti engine u lažnom playing stanju bez zvuka; kod greške slijedi siguran normalni reopen sljedeće pjesme.
- Na širokom/tablet prikazu donji centralni player bar je uklonjen pa katalog ide do dna. Prethodna / Play-Pause / Sljedeća preseljeni su u Trenutno svira karticu s većim razmakom.
- Na uskom mobilnom prikazu zadržan je kompaktni donji kontrolni bar radi upotrebljivosti.
- Kartice pjesama u katalogu više ne prikazuju album; donja tehnička linija prikazuje trajanje · format · prosječni bitrate.
- Lijeva navigacija i desni PLAYER nisu redizajnirani u ovoj verziji.

## v0.2.5 PlaybackPro
- Pozadinska reprodukcija ojačana: AUDIOFOCUS_GAIN, foreground media service, partial wake lock i stabilniji transient/duck/gain povrat.
- Foreground service ostaje aktivan nakon micanja aplikacije iz recent apps dok svira i background playback je uključen.
- Donji Crossfade gumb maknut; Crossfade ostaje u Postavkama.
- Donji lijevi Now Playing/player info dobio je diskretan zaseban premium prozor.
- REPEAT LIST / RANDOM / REPEAT 1 su niže, kompaktnije i bez velikog zajedničkog okvira.
- Pjesme u Playeru su malo niže; veći razmak između rednog broja i naslova.
- Aktivna pjesma više ne prikazuje pause ikonu umjesto rednog broja.
- Detalji pjesme sada uključuju format, bitrate, sample rate, kanale, bit depth gdje je dostupan, veličinu i MIME.
- Ugrađen odabrani Sonorus vinyl/glazbeni vizual kao app/fallback identitet.


## v0.2.4 PlayerFlow
- Desni panel je sada PLAYER; sadržaj se dosljedno zove red reprodukcije.
- Vraćen i ojačan drag & drop preko ručke ≡; long-press na kartici ostaje kontekstni izbornik.
- Dodana drag ručka za pjesme i mape u katalogu na širokom/tablet prikazu.
- PLAYER automatski prati aktivnu pjesmu, osim dok korisnik upravo skrola ili preslaguje red.
- Now Playing panel povećan na 164dp; ispod izvođača ostaje samo format datoteke.
- Quick Share se čisti iz prikazanih naziva, izvođača, albuma i prikaza putanje.
- Online metadata se traže samo kad postoje pouzdan izvođač i naziv pjesme; stari nepouzdani cache se ne koristi.
- Dodano Ujednači glasnoću: lokalna višetočkasta RMS/peak analiza, siguran gain i Android LoudnessEnhancer gdje je dostupan, bez mijenjanja datoteka.
- Zadržana provjera duplikata za spremljene playliste i premium potvrda.

# Changelog

## v0.2.4 Alpha — Sonorus Upgrade
- Rebrand Sonora -> Sonorus + novi vector logo.
- Kompaktniji UI i manji Now Playing hero.
- Animirani spectrum/glow okvir i tehnički audio podaci.
- Mape/folder katalog + cijeli folder drag & drop u queue.
- Queue: single-tap selection, double-tap play, jači active-row highlight.
- Queue footer: Repeat List / Random / Repeat 1.
- Novi crossfade dialog: on/off, 5/10/15 s, fade in/out, Smart Crossfade.
- Equal-power crossfade + lokalna PCM analiza tišine/energije za Smart mode.
- Opcionalni online metadata/artwork/artist images + Wi-Fi only + cache.
- Poboljšana background reprodukcija, wake lock i sticky media service kada je omogućeno.


## v0.2.4 Premium Polish
- Premium 3D-like panel/card surfaces with orange accents.
- Now Playing panel enlarged vertically; only audio format shown below title/artist.
- Removed album/folder-source noise such as Quick Share from Now Playing.
- Filename parser recognizes `Artist - Song` (also en/em dash) when tags are missing.
- Duplicate protection when adding to saved playlists, with confirmation dialogs.
- Crossfade modes: Standard, Smart, Radio Mix. Smart analysis stays local and cached.


[v0.3.5] Player drag indicator polish, active queue styling refresh, compact catalog card polish, and redesigned tablet Old School Radio card.


## v0.3.6 UI Final Polish
- Tablet Old School Radio: premium centered layout, autosizing title/artist metadata and robust separator parsing.
- Now Playing: more width for long titles, smaller artwork/controls, preserved seek bar and technical data.
- Player: single overlay drag insertion line (no panel recolor, no duplicate/flicker), active track uses dark gradient + accent title without orange outline.
- Catalog: tighter grid spacing and title/artist typography matched to Player.

## 0.3.11.7 — Vinyl Lounge Full-screen polish
- Redizajniran samo full-screen `Što svira` ekran u premium hi-fi/vinyl lounge kompoziciju.
- Gramofon je sada nacrtan u tročetvrtinskoj perspektivi s fizičkom bazom, sjenom, platterom i zasebnom animiranom ručkom.
- Vinil je zaseban render s utorima i prirodnom brzinom ~33 1/3 RPM; cover ostaje pravi artwork pjesme i nije odrezan.
- Desni PLAYER panel je kompaktniji, a `Tekst pjesme` dobiva veći vlastiti scroll prostor koji nikad ne izlazi iz ekrana.
- PLAYER, catalog preview, radio, queue, trajna spremišta i ostali ekrani nisu mijenjani.
