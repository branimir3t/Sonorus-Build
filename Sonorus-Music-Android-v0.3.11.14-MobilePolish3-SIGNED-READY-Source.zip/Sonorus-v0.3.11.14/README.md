# Sonorus — v0.3.11.8 Photographic Vinyl

## Novo
- Full-screen `Što svira` koristi fotografsku hi-fi gramofonsku scenu umjesto nacrtanog 3D modela.
- Aktualni omot pjesme dinamički se uklapa u LP sleeve, a njegova labela rotira približno 33 1/3 RPM dok pjesma svira.
- Pozadina je atmosferski blur iste hi-fi scene; desni PLAYER je kompaktniji, lyrics panel veći i sa zasebnim scrollom.
- PLAYER i Catalog Preview zadržavaju postojeće playback putove; podaci, applicationId i spremljene postavke ostaju kompatibilni.

Ova isporuka je source ZIP priprema; APK build se u ovom okruženju ne pokreće.

# Sonorus — v0.3.11.7 Vinyl Lounge

## Novo
- Full-screen `Što svira` redizajniran je u premium hi-fi/vinyl lounge raspored bez plutajućih ili odrezanih elemenata.
- Gramofon je pravi nacrtani 3D/perspektivni objekt: baza je na podlozi, platter je u perspektivi, a ručka se prirodno pomiče prema ploči.
- Crna vinilna ploča ima utore, odsjaje i vrti se približno 33 1/3 RPM; na Pause staje na mjestu, na Play nastavlja.
- Omot je fizički integriran uz gramofon i ostaje cijeli vidljiv.
- Desni PLAYER panel je kompaktniji; `Tekst pjesme` dobiva veći vlastiti scroll panel koji ostaje unutar ekrana.
- PLAYER i Catalog Preview i dalje koriste iste postojeće playback putove; trajni podaci i applicationId nisu mijenjani.

Ova isporuka je source ZIP priprema; APK build se u ovom okruženju ne pokreće.

# Sonorus — v0.3.11 Catalog Preview

## Novo u v0.3.11
- ▶ preview gumb na svakoj kataloškoj pjesmi prije srca i `+`.
- Preview ne dodaje pjesmu u PLAYER niti mijenja red reprodukcije.
- Ako PLAYER svira, privremeno se pauzira i nakon previewa nastavlja s iste pjesme i iste pozicije.
- Aktivni preview gumb prelazi u ■ i služi kao Stop.

# Sonorus — v0.3.10 Mobile Player Compact

Native Android glazbeni player za mobitel, tablet i Android Auto. Package ID ostaje `com.brane.sonora` radi nadogradnje postojeće instalacije bez brisanja spremljenih podataka.

## Novo u v0.3.10

- Old School Radio metadata parser podržava JSON objekt/niz, ugniježđene formate i plain-text fallback; neuspjeli refresh ne briše zadnju dobru pjesmu.
- PLAYER drag & drop koristi cijeli red kao drag vizual, bez dodatnih crta i s mirnijim target/autoscroll ponašanjem.
- Loudness profil je snažniji za PA/live korištenje: oko -12 dB RMS cilj, ~-1 dB peak headroom i analyzer-approved boost do 12 dB.
- Vinyl Gold dobio je čistu premium sans-serif tipografiju i sporo rotirajući vinyl background efekt ograničen na oko 20 fps.
- Postojeći live stability, Android Auto, radio recovery, sat/datum, Obsidian/Crimson teme i upgrade-safe storage ostaju sačuvani.

## Novo u v0.3.3


### Kataloške kartice
- Kartice su kompaktnije: manji vertikalni razmak između naslova, izvođača i trajanja.
- Naslov i izvođač imaju malo manji font + autosize kako bi stalo više teksta.
- Tehnički podaci uklonjeni su iz kataloga; ostaje samo trajanje pjesme.
- Lijevi artwork je smanjen, a srce i + su približeni kako bi tekst dobio više prostora.
- Ručka `≡` uklonjena je iz kataloga; ručno preslagivanje ostaje samo u PLAYERU gdje stvarno mijenja red reprodukcije.

### Četiri kompletne teme
U **Postavke > Izgled > Tema aplikacije** može se odabrati:

- **Sonorus Original** — grafitno-crna hi-fi tema s narančastim naglascima.
- **Midnight Stage** — tamna stvarna koncertna fotografija, stage rasvjeta i plavo-cijan stakleni paneli.
- **Copper Studio** — stvarna fotografija studija/mikrofona, topli bakreno-jantarni 3D paneli.
- **Vinyl Gold** — tamno zelena/crna + zlatna tema sa stvarnom fotografijom vinila/gramofona, dubljim 3D karticama i elegantnijom tipografijom.

Promjena nije samo zamjena accent boje: svaka tema mijenja fotografsku pozadinu, panele, 3D kartice, divider-e, tipografiju, aktivna stanja, glow/visualizer naglaske i kontrole. Premium fotografske pozadine dohvaćaju se jednom s fiksnih Unsplash izvora i zatim ostaju spremljene u privatnom cacheu aplikacije za offline korištenje.

### Katalog i Player
- Jedan dodir pjesme u katalogu i dalje samo označava pjesmu.
- **Brzi dvostruki dodir na pjesmu u katalogu odmah pokreće reprodukciju.**
- Desni PLAYER zadržava postojeći red reprodukcije, drag & drop i zasebne mode kartice.
- Brisanje aktivne pjesme iz PLAYER-a zaustavlja je i ne pokreće automatski drugu.

### Old School Radio
- Koristi RadioFlow stream i metadata proxy.
- Tablet radio kartica je dodatno povećana po visini.
- `Trenutno svira` na tabletu dobiva zasebnu punu širinu kartice i ponovno se sinkronizira nakon povratka u aplikaciju, rotacije ili reconnecta.
- Metadata refresh je 8 s; radio i lokalna glazba ne mogu svirati istodobno.

### Android Auto
Sonorus izlaže Android Auto media pregled preko `MediaBrowserService` + `MediaSession`:

- **Lokalna glazba** — pregled i pokretanje pjesama s uređaja.
- **Old School Radio** — zasebna playable stavka.
- Play / Pause / Stop / Previous / Next / Seek i odabir stavke reda preko MediaSession kontrola.
- `PlayFromMediaId` i pretraživanje po naslovu/izvođaču.
- Voice/search upit za Old School Radio pokreće radio.
- Nakon odabira lokalne pjesme, next/previous prolaze kroz učitanu lokalnu biblioteku.
- Stavke koje je korisnik sakrio iz Sonorusa ne nude se u Android Auto katalogu.
- Android Auto i ekran aplikacije koriste isti PlaybackService, audio fokus, foreground reprodukciju i MediaSession, pa nema paralelnih playera.

## Reprodukcija i stabilnost

- Foreground `PlaybackService` i `MediaSession` vlasnici su reprodukcije.
- `AUDIOFOCUS_GAIN`, partial wake lock, transient duck/pause/resume i `AUDIO_BECOMING_NOISY` ostaju aktivni.
- Pozadinska reprodukcija nastavlja raditi kada se otvori druga aplikacija ili ugasi zaslon, osim kada sustav opravdano oduzme audio fokus (npr. poziv).
- Auto-next watchdog ostaje aktivan ako uređaj propusti `MediaPlayer.onCompletion`.
- Crossfade, loudness normalization i opcionalni online metadata sustavi ostaju odvojeni od osnovnog playbacka.

## Build

1. Instaliraj Android Studio i **Android SDK Platform 35**.
2. Projekt koristi Java 17, `minSdk 26`, `targetSdk/compileSdk 35`.
3. Pokreni `BUILD-WINDOWS.cmd` ili projekt otvori u Android Studiju.
4. Debug APK se kopira kao `Sonorus-v0.3.8-LiveRelease-debug.apk`.

Projekt i dalje nema AndroidX runtime dependencyje; Android Auto media browse koristi framework `MediaBrowserService`/`MediaSession` API.

## Napomena o provjeri

Izvorni kod i resursi mogu se statički provjeriti u ovom paketu. Za konačnu potvrdu Android Auto prikaza, stvarnog audio streama i ponašanja na konkretnom telefonu/tabletu potreban je Android uređaj ili emulator s odgovarajućim Android Auto okruženjem.

## v0.3.4 Player Compact
PLAYER queue kartice i tipografija dodatno su kompaktirani radi većeg broja vidljivih pjesama, uz očuvanu čitljivost i postojeći drag & drop.



[v0.3.5] Player drag indicator polish, active queue styling refresh, compact catalog card polish, and redesigned tablet Old School Radio card.


## v0.3.6 UI Final Polish
- Tablet Old School Radio: premium centered layout, autosizing title/artist metadata and robust separator parsing.
- Now Playing: more width for long titles, smaller artwork/controls, preserved seek bar and technical data.
- Player: single overlay drag insertion line (no panel recolor, no duplicate/flicker), active track uses dark gradient + accent title without orange outline.
- Catalog: tighter grid spacing and title/artist typography matched to Player.
