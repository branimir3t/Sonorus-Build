# Sonorus v0.3.11.8 Photographic Vinyl — QA

## Ciljane provjere
- full-screen layout koristi fotografske `sonorus_turntable_scene` i `sonorus_turntable_ambient` assete;
- stari `TurntableView/TonearmView/VinylRecordView` više nisu dio full-screen layouta;
- aktualni cover i labela ploče ostaju dinamički preko postojećeg ArtworkLoadera;
- labela ploče zadržava linearnu rotaciju ~33 1/3 RPM samo tijekom aktivne reprodukcije;
- lyrics panel ostaje unutar ekrana i koristi vlastiti vertikalni ScrollView;
- applicationId i persistent storeovi ostaju nepromijenjeni;
- cijeli `tools/test_*.py` paket mora proći prije pakiranja;
- APK/Gradle build se namjerno ne pokreće prema korisnikovoj uputi.

# Sonorus v0.3.11.7 Vinyl Lounge — QA

## Ciljane provjere
- gramofon koristi perspektivnu bazu, zaseban realistični vinil i animiranu ručku; elementi stagea ne clipaju djecu;
- vinil koristi linearnu rotaciju približno 33 1/3 RPM i zadržava 3D nagib;
- desni player je kompaktniji, a lyrics panel koristi vlastiti vertikalni ScrollView unutar dostupne visine;
- omot i gramofon ostaju unutar responzivne stage zone na tabletu, landscape mobitelu i portraitu;
- cover iz `Što svira` i kompaktnog playera otvara isti full-screen overlay; Back/close ga zatvaraju bez utjecaja na reprodukciju;
- PLAYER full-screen: previous/play-pause/stop/next + seek koriste postojeći AudioEngine;
- Catalog Preview full-screen: seek/stop koriste postojeći PlaybackService preview put i ne dodaju pjesmu u queue;
- završetak/Stop previewa vraća prikaz PLAYER pjesme bez auto-resumea;
- vinil se animira samo dok je full-screen vidljiv i izvor aktivno svira;
- tekst se ne dohvaća automatski; LRCLIB fetch kreće tek na `Preuzmi tekst`, a uspješan tekst se sprema pod `files/sonorus_lyrics`;
- `applicationId com.brane.sonora` i postojeći persistent storeovi ostaju nepromijenjeni;
- nema Internet Search v0.3.12 koda.

## Isporuka
Source ZIP only. APK/Gradle build se u ovom okruženju ne pokušava prema korisnikovoj uputi.

# Sonorus v0.3.10 Mobile Player Compact — QA

## Ciljane regresijske provjere
- radio metadata: JSON object/array/nesting + direct/proxy fallback i očuvanje zadnje dobre metadata vrijednosti;
- PLAYER drag/drop: stvarna DROP koordinata, cijeli red kao drag-shadow, bez overlay insertion crte, bez recentriranja nakon dropa;
- Vinyl Gold: čista sans-serif tipografija, vinyl motion prisutan i redraw ograničen na oko 20 fps;
- loudness live profil: cilj -12 dB RMS, do 12 dB boosta, ~-1 dB peak headroom, novi v2 cache;
- audio-focus recovery: lokalni audio i radio vraćaju puni output nakon gaina;
- upgrade safety: `com.brane.sonora` i postojeći storage namespaceovi ostaju isti.

## Svježa provjera izvora
- svi `tools/test_*.py` regresijski testovi prolaze;
- 39 XML datoteka uključujući manifest prolaze parser;
- 26 Java datoteka prolaze structural/bracket smoke provjeru;
- stvarni `./gradlew :app:assembleDebug --no-daemon` je pokrenut, ali završava prije Gradle faze jer okruženje ne može DNS-om dohvatiti `services.gradle.org` i nema lokalni Gradle/Android SDK.

Zbog toga APK compile-pass nije potvrđen u ovom containeru; source paket ostaje build-ready za Android Studio / SDK 35 okruženje.

# Sonorus v0.3.3 Catalog Card Polish — QA

## Ciljane izmjene
- Katalog: kartice su kompaktnije, artwork je manji, naslov/izvođač koriste manji autosize font, tehnički red je zamijenjen samo trajanjem.
- Katalog: `≡` drag ručka je uklonjena; preslagivanje ostaje isključivo u PLAYERU.
- Katalog: srce i + su približeni bez promjene funkcije.
- Katalog: single tap = odabir; double tap (~380 ms) = pokreni pjesmu.
- Tablet Old School Radio kartica povećana na 184dp; zaglavlje je presloženo za usku lijevu traku, bez rezanog naziva/“bijelih crtica”, a `Trenutno svira` ima do 3 retka.
- Tablet radio metadata stanje ponovno se šalje nakon resume/configuration change i nakon svakog uspješnog metadata refresha.
- Četiri kompletne teme: Original, Midnight Stage, Copper Studio, Vinyl Gold.
- Now Playing: šira zona naslova s 2 retka + autosize za duže nazive, diskretan jednoredni tehnički red (format · kbps · kHz · bit-depth) i seek traka ispod Prev/Play/Next.
- PLAYER: interna tražilica samo kroz trenutni red, ukupno trajanje uvijek ostaje, a tijekom reprodukcije dodaje se preostalo vrijeme.
- Theme-aware kartice, paneli, divideri, tekst, aktivna stanja, glow/playing-bars i stvarne fotografske pozadine s tamnim overlayem.
- Android Auto: `MediaBrowserService`, `MediaSession`, automotive descriptor, browse lokalne glazbe + Old School Radio, media-id/search playback i transport kontrole.
- Radio i lokalna glazba ostaju međusobno isključivi.

## Android Auto statička provjera
- manifest sadrži `com.google.android.gms.car.application` metadata i `@xml/automotive_app_desc`.
- `PlaybackService` je exportan i ima `android.media.browse.MediaBrowserService` intent-filter.
- MediaSession token predaje se MediaBrowserServiceu.
- root nudi `Lokalna glazba` i playable `Old School Radio`.
- lokalne pjesme imaju stabilni media ID temeljen na MediaStore ID-u.
- playback callback podržava play/pause/stop, next/previous, seek, queue item, media ID i search.

## Statičke provjere paketa
- svi XML resursi i AndroidManifest moraju proći XML parser
- nema dupliciranih `@+id` vrijednosti u glavnom layoutu
- Java `R.id`, `R.drawable`, `R.style`, `R.attr` i `R.xml` reference moraju imati odgovarajući app resurs
- Java izvor prolazi syntax-like provjeru; Android API resolve zahtijeva Android SDK
- ZIP mora proći `unzip -t`

## Ograničenje okruženja
Puni Gradle/Android build i stvarni runtime test Android Auto/telefona/tableta nisu mogući u ovom okruženju bez Android SDK-a i dostupne Gradle distribucije. Završnu runtime provjeru treba napraviti na stvarnom uređaju ili emulatoru.

## v0.3.4 Player Compact
- queue_item ostaje zajednički za tablet i mobilni PLAYER.
- Drag & drop ostaje vezan uz isti `dragHandle` ID i istu QueueAdapter logiku.
- Visina retka smanjena je samo vizualno; `dragHandle` i remove zona i dalje koriste punu visinu retka.
- PLAYER tipografija/spacing promjene ne mijenjaju playback, red reprodukcije, sort, double-tap ni search podatke.


[v0.3.5] Player drag indicator polish, active queue styling refresh, compact catalog card polish, and redesigned tablet Old School Radio card.


## v0.3.6 UI Final Polish
- Tablet Old School Radio: premium centered layout, autosizing title/artist metadata and robust separator parsing.
- Now Playing: more width for long titles, smaller artwork/controls, preserved seek bar and technical data.
- Player: single overlay drag insertion line (no panel recolor, no duplicate/flicker), active track uses dark gradient + accent title without orange outline.
- Catalog: tighter grid spacing and title/artist typography matched to Player.

## v0.3.7 Radio + Catalog Polish — QA
- `activity_main.xml`: tablet radio naslov je jednoredni, Play/Stop ostaje unutar fiksne radio kartice, `sideBrandLogo` više ne postoji.
- `catalogGrid`: `horizontalSpacing=2dp`, `verticalSpacing=2dp`.
- `queue_item.xml`: uklonjeni `queueDropTop` i `queueDropBottom`; jedini drag indikator je overlay iz `MainActivity`.
- `bg_queue_active` i `bg_queue_selected`: nema stroke/outline sloja.
- Single-tap selection clear provjerava stvarne granice vidljivih GridView/ListView child kartica i ne dira multi-select način.
- `applicationId=com.brane.sonora`, `sonorus_track_overrides`, `sonora_playlists`, `sonora_ids` i SonorusSettings storage ostaju nepromijenjeni.
- Svi XML resursi prolaze parser; app `R.*` reference prolaze statičku provjeru; Java source nema detektirane sintaksne greške u smoke provjeri.



## Mobile PLAYER v0.3.10
- Ciljani regresijski test: `tools/test_mobile_player_compact_controls.py`.
- Sve XML datoteke parsirane bez greške.
- Cijeli `tools/test_*.py` paket prolazi.
- Puni Gradle compile nije izvršiv u ovom okruženju jer Gradle 8.9 nije lokalno dostupan, a DNS prema services.gradle.org je blokiran.


## Catalog Preview v0.3.11
- [x] Preview gumb je prije favorita i `+` samo na pjesmama.
- [x] Preview ne koristi `AudioEngine.playTrackNow()` i ne dodaje pjesmu u queue.
- [x] PLAYER koji je svirao prije previewa pauzira se i vraća na spremljenu pjesmu/poziciju.
- [x] Završetak previewa i ručni ■ Stop vraćaju prethodni playback state.
- [x] Preview koristi PlaybackService audio focus i wake-lock put.
