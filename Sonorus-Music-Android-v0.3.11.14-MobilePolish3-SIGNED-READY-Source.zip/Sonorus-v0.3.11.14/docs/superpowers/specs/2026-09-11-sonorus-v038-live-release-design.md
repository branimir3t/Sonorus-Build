# Sonorus v0.3.8 Live Release Design

## Goal
Prepare Sonorus for reliable live-use playback on stage while finishing the requested tablet UI polish and adding two new premium photo themes.

## Approved requirements
- Fix queue drag-and-drop so a dropped song stays exactly at the intended insertion position and the list viewport does not jump afterward.
- In the catalog, ordinary cards have no visible border; only the selected track has a clear theme-accent border.
- Add a centered 24-hour clock and date below the Old School Radio card in the tablet left column.
- Make the Old School Radio card border match the normal left navigation card border color, weight, and visual strength.
- Add two complete premium 3D themes: Obsidian 3D (black/elegant) and Crimson 3D (dark red/elegant/sexy), with appropriate photographic backgrounds.
- Optimize the whole application for immediate, smooth operation, prioritizing uninterrupted local audio and radio playback during live-performance breaks.
- Include radio stream stability in the same reliability pass.
- Local playback defaults to neutral full-scale output: loudness normalization is opt-in, and audio-focus recovery must restore local/radio volume to 100% when ducking ends.
- Preserve all existing user data on upgrade, including edited metadata, favorites, playlists, queue, and settings.
- Keep the same applicationId/package identity and do not rename existing SharedPreferences stores/keys.

## Architecture
Playback reliability remains owned by the foreground PlaybackService and AudioEngine. UI work stays in MainActivity/adapters/resources and must not introduce synchronous disk/network/audio-analysis work on the main thread. Theme photos use the existing fixed-source async loader and private disk cache. Photo fetch/decode stays off the main thread and is never required for audio playback; cached photos remain available offline, with a themed dark fallback before cache is populated.

Queue reordering uses ACTION_DROP coordinates as the final source of truth and does not auto-recenter the list after drag completion. Catalog selection visuals use separate borderless and selected-border drawables so only the selected track gets an outline.

## Performance rules
- Theme image network I/O must run only on the dedicated background executor and must never gate audio playback or UI input.
- Decode static theme backdrops once per selected theme and keep drawing work simple/hardware-friendly.
- Artwork/metadata remain background-thread operations.
- Do not interrupt local playback when the Activity is recreated or backgrounded while background playback is enabled.
- Radio remains in the foreground service, owns audio focus and wake lock, and reconnects without blocking the main thread.
- Avoid extra MediaPlayer teardown/recreation caused only by UI actions.
- Queue persistence must remain asynchronous and not reset saved data.

## Verification
- Regression tests for drag/drop target and viewport preservation.
- Source/resource checks for catalog border behavior, clock/date IDs/update loop, new themes and local backdrops, unchanged applicationId and preference store names.
- XML parse validation and Java syntax-oriented checks.
- Attempt a Gradle debug build if the provided project tooling/environment permits it; report honestly if the environment cannot complete a real Android build.
