# Sonorus Full-screen Now Playing Design

## Scope
Add a full-screen Now Playing overlay opened by tapping the current artwork. It supports both the normal PLAYER source and Catalog Preview source. Old School Radio is explicitly out of scope for this version.

## Entry and exit
- Tapping `heroArt` or the compact `nowArt` opens the overlay when a local track is available.
- The overlay is rendered inside the existing `MainActivity`, above the existing app shell and queue overlay, so playback state remains owned by the current `PlaybackService`/`AudioEngine`.
- Close button and Android Back close the overlay without changing playback.

## Visual layout
- Premium dark full-screen overlay using existing theme colors.
- Large album cover, title, artist, album/year, technical audio label and duration.
- Turntable section with a drawn platter/tonearm and a vinyl group whose center label uses the current track artwork.
- The vinyl group rotates only while the currently displayed source is actually playing. It is stationary while PLAYER is paused or when no source is playing.
- Layout adapts: portrait stacks content vertically; wide/landscape places visual and information columns side by side.

## Playback controls
### PLAYER source
- Previous, Play/Pause, Stop, Next and seek are available.
- Stop pauses the PLAYER and seeks to 0 without clearing queue.
- Full-screen progress mirrors the existing engine progress.

### Catalog Preview source
- Full-screen displays the preview track without adding it to PLAYER.
- Only Stop and seek are active; Previous/Next and Play/Pause are hidden or disabled for preview.
- Stopping or natural completion returns the full-screen display to the last PLAYER track, but PLAYER remains paused and does not auto-resume.
- Preview progress and seek use the existing `PlaybackService.seekCatalogPreview(...)` path.

## Lyrics
- Lyrics are not downloaded automatically.
- If lyrics are already cached locally, they display immediately and remain available offline.
- If no cached lyrics exist, show a `Preuzmi tekst` action.
- User-initiated fetch uses LRCLIB over HTTPS. Exact lookup is attempted first using title, artist, album and duration; fallback omits album; final fallback uses search.
- Prefer `plainLyrics`. If only `syncedLyrics` exists, remove LRC timestamps for this first version.
- Successful lyrics are stored under app-internal `files/sonorus_lyrics/` keyed by normalized artist/title/album hash, so app upgrades do not remove them.
- Network/not-found errors are shown in the overlay without affecting playback or existing cached data.

## Data and regression constraints
- Preserve `applicationId com.brane.sonora`.
- Do not reset or rename existing SharedPreferences/stores.
- Do not alter PLAYER queue persistence, favorites, metadata overrides, radio, catalog preview semantics, themes or landscape navigation.
- Do not include Internet Search v0.3.12.
- Deliver source ZIP only; do not attempt APK build in this environment.
