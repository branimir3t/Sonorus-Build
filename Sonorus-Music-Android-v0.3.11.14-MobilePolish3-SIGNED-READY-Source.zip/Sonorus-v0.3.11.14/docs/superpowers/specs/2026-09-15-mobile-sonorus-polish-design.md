# Sonorus Mobile Player, Albums, Mini-player and System Sound Design

## Scope
Implement only the agreed mobile experience while preserving the existing tablet/wide fullscreen turntable scene and all persistent user data.

## Mobile fullscreen player
For phone layouts, use a cover-centric fullscreen player instead of the turntable composition. The whole screen is filled by the current cover as a darkened/blurred dynamic backdrop. The top area has Sonorus branding and controls but no “ŠTO SVIRA” label. A large square cover is centered, followed by title, artist, album, quick actions (queue, favorite, add to playlist, lyrics), seek bar with time and large transport controls. Lyrics open as a compact bottom sheet with download and local edit/input actions. Existing wide/tablet fullscreen remains untouched.

## Mobile Albums
Top-level Albums on phones use a two-column grid. Each card has a large square rounded cover, album title, and subdued “artist | N pjesama” text. Missing artwork uses the existing Sonorus placeholder. Album detail returns to the normal track list. Other catalog sections keep their current list presentation.

## Mobile mini-player
When a local track exists, show a compact sticky bar at the bottom of normal phone screens. It contains small cover, title, artist, previous, play/pause, next and queue buttons. It is hidden while fullscreen now-playing is visible, and restored when fullscreen closes while a track still exists. It must not cover catalog content.

## Track long-press menu
The song long-press menu is narrower and denser than ordinary dialogs, with a small contextual icon before every action. Keep the accent-colored track title and divider. Include compact actions for add to playlist, add to queue, edit metadata, “Postavi kao…”, **Podijeli**, details, multi-select and remove where applicable. “Podijeli” uses Android ACTION_SEND with the track MediaStore URI and read grant so installed apps such as Viber or WhatsApp can receive the audio file. “Postavi kao…” opens child options Melodija zvona, Alarm, and Zvuk obavijesti using Android RingtoneManager/MediaStore and Settings.System write permission flow. Never create a new signing key or alter app identity.

## Global constraints
- Keep `applicationId com.brane.sonora`.
- Preserve signing-ready configuration and persistent stores.
- Do not change `sonorus_turntable_scene.jpg`, `PhotographicVinylScene.java`, `VinylSceneGeometry.java`, `TonearmView.java`, `VinylRecordView.java`, or `TurntableView.java`.
- Existing wide/tablet fullscreen behavior stays functionally identical.
- Menus/dialogs stay compact, theme-aware and lightly translucent.
