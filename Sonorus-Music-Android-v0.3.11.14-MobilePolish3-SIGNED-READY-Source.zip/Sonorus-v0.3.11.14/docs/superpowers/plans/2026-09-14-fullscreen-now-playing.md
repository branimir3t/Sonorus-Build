# Full-screen Now Playing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add a full-screen Now Playing overlay for PLAYER and Catalog Preview with turntable animation, full controls/progress, useful metadata and user-initiated offline-cached lyrics.

**Architecture:** Keep playback ownership unchanged in `PlaybackService`/`AudioEngine`. Add a presentation overlay inside `MainActivity`, a small `TurntableView` for static gramophone drawing, and a focused `LyricsRepository` for LRCLIB fetch/cache. MainActivity routes progress/controls to the already-active source.

**Tech Stack:** Android Java 17, XML views, `ObjectAnimator`, `HttpURLConnection`, `org.json`, app-internal file cache.

**Spec:** `docs/superpowers/specs/2026-09-14-fullscreen-now-playing-design.md`

## Global Constraints
- Base: Sonorus v0.3.11.5 Mobile Landscape Fix.
- `applicationId` remains `com.brane.sonora`.
- Existing user data stores are preserved unchanged.
- Old School Radio full-screen is out of scope.
- Internet Search v0.3.12 is not included.
- Source ZIP only; no APK build attempt.

---

### Task 1: Full-screen overlay structure and entry/exit

**Files:**
- Create: `app/src/main/res/layout/view_fullscreen_now_playing.xml`
- Create: `app/src/main/java/com/brane/sonora/TurntableView.java`
- Modify: `app/src/main/res/layout/activity_main.xml`
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Test: `tools/test_fullscreen_now_playing_v03116.py`

**Interfaces:**
- Produces: `showFullscreenNowPlaying()`, `hideFullscreenNowPlaying()`, `refreshFullscreenNowPlaying()`, `fullscreenNowPlayingOverlay` and track display widgets.

- [x] Step 1: Add failing static regression assertions for overlay include, clickable current artwork, close/back behavior, adaptive body orientation and turntable view.
- [x] Step 2: Run `python3 tools/test_fullscreen_now_playing_v03116.py`; expect failure because overlay/layout/classes are missing.
- [x] Step 3: Implement overlay XML, `TurntableView`, view bindings, artwork click handlers, close/back handling and orientation adjustment.
- [x] Step 4: Re-run the focused test; expect PASS for structure/entry/exit assertions.

### Task 2: PLAYER and Catalog Preview synchronization

**Files:**
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Test: `tools/test_fullscreen_now_playing_v03116.py`

**Interfaces:**
- Consumes: existing `AudioEngine`, `PlaybackService`, `activeCatalogPreviewTrackId`, `activeCatalogPreviewDurationMs`.
- Produces: source-aware full-screen controls, progress and vinyl rotation state.

- [x] Step 1: Add failing assertions that full-screen seek routes to preview when active and engine otherwise; PLAYER controls use existing playback path; preview stop calls `stopCatalogPreview`; progress callbacks update full-screen controls; preview completion refreshes to paused PLAYER.
- [x] Step 2: Run focused test and verify expected failures.
- [x] Step 3: Implement source-aware controls/progress, `ObjectAnimator` vinyl rotation and refresh hooks in track/playback/preview callbacks.
- [x] Step 4: Re-run focused test; expect PASS.

### Task 3: Lyrics fetch and offline cache

**Files:**
- Create: `app/src/main/java/com/brane/sonora/LyricsRepository.java`
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Test: `tools/test_fullscreen_now_playing_v03116.py`

**Interfaces:**
- Produces: `LyricsRepository.getCached(Track)`, `LyricsRepository.fetchAndCache(Track, Callback)`, callback status `FOUND`, `NOT_FOUND`, `ERROR`.

- [x] Step 1: Add failing assertions for LRCLIB HTTPS endpoint, URL-encoded metadata, exact/fallback/search sequence, plain/synced parsing, internal `sonorus_lyrics` storage, and UI download button wiring.
- [x] Step 2: Run focused test and verify expected failures.
- [x] Step 3: Implement repository with background executor, main-thread callback, SHA-256 cache key and safe JSON parsing; wire cached display and user-initiated download into overlay.
- [x] Step 4: Re-run focused test; expect PASS.

### Task 4: Metadata, versioning and full regression

**Files:**
- Modify: `app/build.gradle`
- Modify: `CHANGELOG.md`
- Modify: `PROJECT-STATUS.md`
- Modify: `QA.md`
- Test: all `tools/test_*.py`

**Interfaces:**
- Produces: v0.3.11.6 source package.

- [x] Step 1: Extend focused test for `versionCode 28`, `versionName 0.3.11.6-fullscreen-now-playing`, preserved applicationId/store names and no Internet Search artifacts.
- [x] Step 2: Update version/docs only after focused functionality is green.
- [x] Step 3: Run every `tools/test_*.py` script and XML parse validation; fix only regressions caused by this feature.
- [x] Step 4: Compare file hashes against v0.3.11.5 and verify no playback/radio/store files changed except files explicitly required by the feature.
- [x] Step 5: Package `Sonorus-Music-Android-v0.3.11.6-FullscreenNowPlaying.zip`, create SHA-256 sidecar, unpack final ZIP and rerun focused/full static verification from packaged content.
