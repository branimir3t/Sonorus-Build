# Sonorus Mobile Polish Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add the approved mobile fullscreen player, album grid, sticky mini-player, and “Postavi kao…” system-sound action without altering the protected tablet turntable experience.

**Architecture:** Keep the existing wide fullscreen composition intact and add a separate phone-only fullscreen content layer wired to the same playback state. Extend `CatalogAdapter` with an album-grid view type only for top-level phone Albums. Reuse the existing bottom `playerBar` as the phone sticky mini-player and add a focused `SystemSoundSetter` helper for Android ringtone/alarm/notification changes.

**Tech Stack:** Android Java, XML layouts/drawables, MediaStore, RingtoneManager, Settings.System, existing Sonorus theme and persistence helpers.

**Spec:** `docs/superpowers/specs/2026-09-15-mobile-sonorus-polish-design.md`

## Global Constraints
- `applicationId` remains `com.brane.sonora`.
- Signing-ready Gradle configuration remains functional.
- Persistent user data stores are preserved.
- Protected turntable assets/classes remain byte-identical.
- No unrelated refactoring.

---

### Task 1: Mobile album grid
**Files:**
- Create: `app/src/main/res/layout/catalog_album_grid_item.xml`
- Modify: `app/src/main/java/com/brane/sonora/CatalogAdapter.java`
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Test: `tools/test_mobile_album_grid_v031112.py`

- [x] Write a failing static regression test for phone-only two-column album grid and adapter view type.
- [x] Run the test and confirm it fails for missing album-grid implementation.
- [x] Add album-grid view type and top-level Albums presentation mode.
- [x] Update responsive layout to use two columns only for top-level phone Albums.
- [x] Run the regression test and existing catalog tests.

### Task 2: Sticky phone mini-player
**Files:**
- Modify: `app/src/main/res/layout/activity_main.xml`
- Create: `app/src/main/res/drawable/bg_mobile_mini_player.xml`
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Test: `tools/test_mobile_sticky_player_v031112.py`

- [x] Write a failing test for compact cover/title/artist/prev/play/next/queue player and fullscreen-hide behavior.
- [x] Run the test and confirm failure.
- [x] Compact `playerBar`, add queue action, and hide unused progress controls visually.
- [x] Make visibility depend on phone layout + active track + fullscreen not visible.
- [x] Restore mini-player after fullscreen closes.
- [x] Run the new and existing mobile-player tests.

### Task 3: Phone fullscreen player and lyrics sheet
**Files:**
- Modify: `app/src/main/res/layout/view_fullscreen_now_playing.xml`
- Create: `app/src/main/res/drawable/bg_mobile_fullscreen_sheet.xml`
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Test: `tools/test_mobile_fullscreen_v031112.py`

- [x] Write a failing test for separate mobile fullscreen content, dynamic cover backdrop, no “ŠTO SVIRA” label in mobile content, quick actions and lyrics sheet.
- [x] Run the test and confirm failure.
- [x] Add phone-only cover-centric content and dynamic background/cover fields.
- [x] Wire transport, seek, favorite, playlist, queue, lyrics and edit/download actions.
- [x] Toggle mobile vs desktop fullscreen by phone width without modifying protected turntable classes/assets.
- [x] Run mobile fullscreen and all existing fullscreen tests.


### Task 4: Compact track menu with icons and sharing
**Files:**
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Create: `app/src/main/res/drawable/ic_menu_*.xml` compact menu icons
- Test: `tools/test_track_menu_share_icons_v031112.py`

- [x] Write a failing test for the narrower track menu, contextual icons and “Podijeli”.
- [x] Run the test and confirm it fails.
- [x] Add vector icons and icon-aware compact menu rows.
- [x] Add ACTION_SEND audio sharing with `FLAG_GRANT_READ_URI_PERMISSION` and `ClipData`.
- [x] Run the new compact-menu regression test and existing menu tests.

### Task 5: “Postavi kao…” system sounds
**Files:**
- Create: `app/src/main/java/com/brane/sonora/SystemSoundSetter.java`
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Modify: `app/src/main/AndroidManifest.xml`
- Test: `tools/test_set_as_system_sound_v031112.py`

- [x] Write a failing test for “Postavi kao…” and ringtone/alarm/notification choices plus WRITE_SETTINGS flow.
- [x] Run the test and confirm failure.
- [x] Implement helper using `RingtoneManager.setActualDefaultRingtoneUri` and best-effort MediaStore flags.
- [x] Add compact submenu and pending-permission retry on resume.
- [x] Run the new and existing compact-menu tests.

### Task 6: Release/version/signing preservation and final verification
**Files:**
- Modify: `app/build.gradle`
- Modify: `RELEASE-v0.3.11.12.txt`
- Test: all `tools/test_*.py` except Android-SDK-only resource-link test when SDK is unavailable.

- [x] Bump to versionCode 34 / versionName `0.3.11.12-mobile-polish`.
- [x] Verify signing-ready scripts/config remain present.
- [x] Run all available static regression tests.
- [x] Parse all XML resources.
- [x] Compare protected turntable files byte-for-byte against v0.3.11.11 baseline.
- [x] Package source ZIP and SHA-256.
