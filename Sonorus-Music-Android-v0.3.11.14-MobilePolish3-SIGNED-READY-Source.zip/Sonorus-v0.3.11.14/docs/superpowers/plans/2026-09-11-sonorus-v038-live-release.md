# Sonorus v0.3.8 Live Release Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver Sonorus v0.3.8 with correct drag/drop, requested tablet polish, two new photo-backed 3D themes, and a live-use playback/radio stability pass without deleting user data.

**Architecture:** Keep playback in the existing foreground PlaybackService/AudioEngine and isolate UI/theme work from audio. Keep theme photo fetch/decode on a dedicated background executor with private disk cache, keep expensive artwork/metadata analysis off the main thread, and preserve existing package/preferences identities.

**Tech Stack:** Android Java 17, Android SDK 35, MediaPlayer/MediaSession/MediaBrowserService, XML resources, SharedPreferences, Python regression/source tests.

**Spec:** `docs/superpowers/specs/2026-09-11-sonorus-v038-live-release-design.md`

## Global Constraints
- applicationId remains `com.brane.sonora`.
- Existing SharedPreferences store names and keys remain unchanged.
- Local playback and radio must remain foreground-service based and background-capable.
- Theme photographs are optional to playback: fixed-source fetch/decode runs off the main thread, then uses private disk cache; dark fallback works without network.
- No synchronous network or heavy bitmap decode work on the main thread.

---

### Task 1: Queue drag/drop correctness

**Files:**
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Test: `tools/test_queue_drop_regression.py`
- Test: `tools/test_queue_drag_viewport_regression.py`

**Interfaces:**
- Consumes: `rowAt(ListView,float,float,boolean)` and `AudioEngine.moveItem(int,int)`.
- Produces: ACTION_DROP-calculated final insertion index with no post-drag viewport recenter.

- [x] Run both existing regression tests and confirm viewport test fails on the baseline.
- [x] Remove `scrollPlayerToCurrent(false)` from queue `ACTION_DRAG_ENDED` so the user's dropped location remains visually stable.
- [x] Keep final target calculation inside `ACTION_DROP` using `rowAt(list, event.getX(), event.getY(), true)` and preserve downward-move index correction.
- [x] Run both regression tests; expected: both PASS.

### Task 2: Catalog selected-only border

**Files:**
- Create: `app/src/main/res/drawable/bg_catalog_idle.xml`
- Create: `app/src/main/res/drawable/bg_catalog_selected.xml`
- Modify: `app/src/main/java/com/brane/sonora/CatalogAdapter.java`
- Test: `tools/test_catalog_selection_border.py`

**Interfaces:**
- Consumes: `selectedTrackId`, multi-select state, theme color attributes.
- Produces: borderless idle cards and accent-bordered selected cards.

- [x] Write a failing source/resource regression test asserting idle uses `bg_catalog_idle`, selected uses `bg_catalog_selected`, idle drawable has no stroke, selected drawable has accent stroke.
- [x] Run test and confirm it fails.
- [x] Add the two drawables, using the same card depth/gradient but no idle outline and a 1.5dp `?attr/sonorusAccent` selected outline.
- [x] Update `CatalogAdapter` background selection without changing click/double-tap behavior.
- [x] Run the regression test; expected PASS.

### Task 3: Tablet radio frame + clock/date

**Files:**
- Modify: `app/src/main/res/drawable/bg_radio_premium.xml`
- Modify: `app/src/main/res/layout/activity_main.xml`
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Test: `tools/test_radio_clock_and_frame.py`

**Interfaces:**
- Produces: `leftClockText`, `leftDateText`, one lightweight minute-aligned UI ticker active only while Activity exists.

- [x] Write a failing regression test for nav-matching radio stroke (`sonorusDivider`, 1dp), clock/date views, and a clock update method.
- [x] Run test and confirm failure.
- [x] Change radio card stroke to the menu idle border styling.
- [x] Insert clock/date below radio before the weighted spacer; center aligned, no extra card border.
- [x] Bind/update clock/date with Croatian locale-friendly formatting and remove callbacks on destroy.
- [x] Run regression test; expected PASS.

### Task 4: Obsidian 3D and Crimson 3D cached photo themes

**Files:**
- Add: `app/src/main/res/drawable-nodpi/theme_midnight_stage.webp`
- Add: `app/src/main/res/drawable-nodpi/theme_copper_studio.webp`
- Add: `app/src/main/res/drawable-nodpi/theme_vinyl_gold.webp`
- Add: `app/src/main/res/drawable-nodpi/theme_obsidian_3d.webp`
- Add: `app/src/main/res/drawable-nodpi/theme_crimson_3d.webp`
- Modify: `app/src/main/java/com/brane/sonora/SonorusSettings.java`
- Modify: `app/src/main/java/com/brane/sonora/MainActivity.java`
- Modify: `app/src/main/java/com/brane/sonora/ThemeBackdropView.java`
- Modify: `app/src/main/res/values/styles.xml`
- Test: `tools/test_theme_regression.py`

**Interfaces:**
- Produces: `THEME_OBSIDIAN = 4`, `THEME_CRIMSON = 5`, style resources `AppThemeObsidian`, `AppThemeCrimson`, local drawable mapping in `ThemeBackdropView`.

- [x] Write failing regression test checking theme IDs 0..5, style mapping, picker labels, cached photo file names, background thread priority, and no forced software rendering in `ThemeBackdropView`.
- [x] Run test and confirm failure.
- [x] Add fixed photo sources for Obsidian/Crimson and reuse the existing background-only loader/cache path.
- [x] Extend settings range safely to 0..5; existing stored values 0..3 remain valid.
- [x] Add Obsidian/Crimson style palettes with 3D card/hero attributes.
- [x] Keep photo network/decode work on the dedicated background executor, cache successful downloads privately, and remove forced software rendering.
- [x] Update picker names/descriptions and theme style mapping.
- [x] Run regression test; expected PASS.

### Task 5: Live-use playback and radio stability pass

**Files:**
- Modify: `app/src/main/java/com/brane/sonora/PlaybackService.java`
- Modify: `app/src/main/java/com/brane/sonora/AudioEngine.java`
- Modify: `app/src/main/java/com/brane/sonora/ArtworkLoader.java`
- Test: `tools/test_live_playback_stability.py`

**Interfaces:**
- Keeps existing public playback/radio APIs unchanged.
- Produces: lightweight periodic playback health verification, radio reconnect scheduling that cannot stack across generations, bounded artwork executor/cache behavior, no theme/network work competing with audio.

- [x] Write failing source regression checks for a periodic service-side health ticker while playback/radio is active, cancellation on destroy/stop, and bounded background artwork threads.
- [x] Run test and confirm failure.
- [x] Add a low-frequency PlaybackService health ticker that reasserts local playback only when logically playing and checks radio player state/recovery without touching UI; generation guards prevent stale reconnects.
- [x] Ensure radio start/stop clears pending recovery/timeout callbacks for the old generation.
- [x] Keep metadata networking on its existing single background executor and never make it gate audio start.
- [x] Keep artwork loading on background threads and reduce decode target/cache pressure where safe for smooth scrolling.
- [x] Run stability regression test; expected PASS.

### Task 5b: Neutral full-scale output + Android Auto focus recovery

**Files:**
- Modify: `app/src/main/java/com/brane/sonora/SonorusSettings.java`
- Modify: `app/src/main/java/com/brane/sonora/PlaybackService.java`
- Test: `tools/test_full_scale_audio_output.py`

**Interfaces:**
- Keeps the existing loudness-normalization toggle and saved key unchanged.
- Produces neutral 100% output by default when the user has never explicitly enabled normalization, plus periodic radio full-volume reassertion after focus recovery.

- [x] Write a failing regression test for default-off normalization, MEDIA/MUSIC attributes, local/radio focus-gain restore, and radio health reassertion.
- [x] Run the test and confirm it fails on the old default.
- [x] Change only the missing default from `true` to `false`; an explicitly saved user value remains untouched.
- [x] Reassert radio volume at 1.0 from the health ticker only when focus is held and the stream is not ducked.
- [x] Run the regression test; expected PASS.

### Task 6: Upgrade/data preservation guard

**Files:**
- Modify: `app/build.gradle`
- Test: `tools/test_upgrade_preservation.py`

**Interfaces:**
- Produces versionCode 18 / versionName `0.3.8-live-release`; package and preference identifiers unchanged.

- [x] Write regression test asserting applicationId and known preference store constants stay unchanged while version increments.
- [x] Run test and confirm failure on old version.
- [x] Set versionCode/versionName only; do not rename package, stores, or keys.
- [x] Run regression test; expected PASS.

### Task 7: Full verification and release package

**Files:**
- Modify: `CHANGELOG.md`
- Modify: `QA.md`
- Modify: `PROJECT-STATUS.md`
- Create: release ZIP and SHA-256 in `/mnt/data`.

**Interfaces:**
- Produces: clean v0.3.8 source package suitable for APK build.

- [x] Run every `tools/test_*.py` regression test.
- [x] Parse all XML files with Python XML parser.
- [x] Run Java structural checks (balanced braces / referenced resource IDs where feasible).
- [x] Attempt `./gradlew assembleDebug`; if wrapper/toolchain is unavailable, record that limitation rather than claiming a build pass.
- [x] Update changelog/QA/status with only verified results.
- [x] Remove transient build/cache files from source package.
- [x] Create `Sonorus-Music-Android-v0.3.8-LiveRelease.zip` and matching `.sha256` and verify checksum.
